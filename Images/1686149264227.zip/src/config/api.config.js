import axios from "axios";
import { PathApi } from "./api.path.config";

let token = localStorage.getItem("token");
const headers = (params) => {
  return {
    headers: {
      "Access-Control-Allow-Origin": "*",
      Authorization: params.token ? "Bearer " + params.token : "",
      mobile: true,
      "Accept-Language": `${params.languageToShow}`,
    },
  };
};
// const headers = {
//   headers: {
//     "Access-Control-Allow-Origin": "*",
//     Authorization: token ? "Bearer " + token : "",
//     mobile: true,
//   },
// };
export const API = {
  get(path,params) {
    return axios.get(`${PathApi.BASE_URL}${path}`, headers(params));
  },
  post(path, postData, params) {
    return axios.post(`${PathApi.BASE_URL}${path}`, postData, headers(params));
  },
  delete(path) {
    return axios.delete(`${PathApi.BASE_URL}${path}`);
  },
  patch(path, params, contentType) {
    return axios.patch(`${PathApi.BASE_URL}${path}`, params, headers);
  },
};
