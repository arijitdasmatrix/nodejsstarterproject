// const BASE_URL_LOCAL = process.env.REACT_APP_BACKEND_API_ENDPOINT || '';
// const BASE_URL_LOCAL = "http://demoyourprojects.com:5083/api/v1";
var BASE_URL_LOCAL = process.env.REACT_APP_BACKEND_API_ENDPOINT;


export const PathApi = {
  BASE_URL: BASE_URL_LOCAL,
  languageList: "/language/get-all",
  socialLogin: "/user/social-login/",
  getAllBiding: "/biding-request/get-all",
  getFullHotelDetails: "/hotel/get-hotel/",
  getFullHotelDetails: "/hotel/get-hotel/",
  addFavouriteHotel: "/hotel/add-favourite/",
  removeFavouriteHotel: "/hotel/remove-favourite/",
  getAllFavouriteHotelList: "/hotel/get-all-favourite/",
  fileUpload: "/common/upload/",

};
