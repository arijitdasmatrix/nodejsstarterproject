import React, { useEffect, useState } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from 'react-bootstrap';
import TextField from "@mui/material/TextField";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";

const Test = () => {

    const [value, setValue] = useState(null);
    console.log(value);
    useEffect(() => {
        if (value != null) {
            handleOpen();
        }
    }, [value]);
    const [open, setOpen] = useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const style = {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: 400,
        bgcolor: "background.paper",
        border: "2px solid #000",
        boxShadow: 24,
        p: 4
    };

    return (
        <>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                                <DatePicker className="datepickercheck-in"
                                                                    label="Check-in"
                                                                    value={value}
                                                                    onChange={(newValue) => {
                                                                        setValue(newValue);
                                                                    }}
                                                                    renderInput={(params) => <TextField {...params} />}
                                                                />
                                                            </LocalizationProvider>
                                                            <Modal
                                                                open={open}
                                                                onClose={handleClose}
                                                                aria-labelledby="modal-modal-title"
                                                                aria-describedby="modal-modal-description"
                                                            >
                                                                <Box sx={style}>
                                                                    {/* <Typography id="modal-modal-title" variant="h6" component="h2">
                                                                        Text in a modal
                                                                    </Typography> */}
                                                                    <Typography id="modal-modal-description" sx={{ mt: 2 }} className="hourlybook">
                                                                        Book For
                                                                        <Form.Select aria-label="Default select example">
                                                                            <option>Hours</option>
                                                                            <option value="1">1 Hour</option>
                                                                            <option value="2">2 Hours</option>
                                                                            <option value="3">3 Hours</option>
                                                                        </Form.Select>
                                                                    </Typography>
                                                                </Box>
                                                            </Modal>

        </>
    )

}


export default Test;