import React, { useEffect  } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from 'react-bootstrap';
import { Link } from "react-router-dom"
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import { cmsGetDataStart } from "./../../redux/cms/cms.actions";
import { selectLanguage } from "./../../redux/language/language.actions";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { selectcmsData } from "./../../redux/cms/cms.selectors";
import { useLocation } from 'react-router-dom';

//import { selectCurrentUser,selectSignInError } from "../../redux/user/user.selectors";
const TermsAndConditionPage = ({cmsGetDataStart,selectLanguage,languageToShow,selectcmsData}) => {
const location = useLocation();
React.useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
useEffect(() => {
if(location.pathname == "/terms&conditions") {   
var data = {
language:languageToShow,
slug:"terms-and-conditions"    
} 
} else if(location.pathname == "/privacy-policy") { 
var data = {
language:languageToShow,
slug:"privacy-policy"    
}     
} else {
var data = {
language:languageToShow,
slug:"safety-and-security"    
}
}   


cmsGetDataStart(data);
},[languageToShow,location])



    return (
        <>
            {/* Header Section */}
            {/* <header>
                <div className="container">
                    <div className="row">
                        <div className="col-md-3">
                            <div className="logo">
                                <Link to="/"><img src='./img/logo.svg' alt="" /></Link>
                            </div>
                        </div>
                        <div className="col-md-9">
                            <div className="toprightsec">
                                <ul>
                                    <li><Link to="/login"><FiLogIn /> Login</Link></li>
                                    <li><Link to="#"><BiUserCircle /> Register</Link></li>
                                    <li>
                                        <Dropdown
                                       onSelect={handleSelect}
                                        >
                                            <Dropdown.Toggle variant="success" id="dropdown-basic">
                                              {languageToShow == "en" ? "English" :"العربية"}   <img src='./img/belowarrow.svg' alt="" />
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu>
                                                <Dropdown.Item eventKey="ar" >العربية</Dropdown.Item>
                                                <Dropdown.Item eventKey="en">English</Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </li>
                                    <li>
                                        <Dropdown>
                                            <Dropdown.Toggle variant="success" id="dropdown-basic">
                                                AED <img src='./img/belowarrow.svg' alt="" />
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu>
                                                <Dropdown.Item href="#/action-1">AED</Dropdown.Item>
                                                <Dropdown.Item href="#/action-1">INR</Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </li>
                                    <li>
                                        <Dropdown>
                                            <Dropdown.Toggle variant="success" id="dropdown-basic">
                                                <img src='./img/topnav.svg' alt="" />
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu>
                                                <Dropdown.Item href="/myaccount">My Account</Dropdown.Item>
                                                <Dropdown.Item href="#/action-2">Hotels </Dropdown.Item>
                                                <Dropdown.Item href="#/action-3">Rewards</Dropdown.Item>
                                                <Dropdown.Item href="#/action-1">Contact Us</Dropdown.Item>
                                                <Dropdown.Item href="#/action-2">Terms and Condition </Dropdown.Item>
                                                <Dropdown.Item href="#/action-3">Sign Out </Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </header> */}
           {/* //////////Common page Section/////////// */}
            <div className="commonpage">
                <div className="container">
                    <div className="row">
                        <div className="col-md-3">
                            <ul className="leftmenu">
                                <li className={ location.pathname == "/aboutus" ? "active" : "" }><Link to="/aboutus">About us</Link></li>
                                <li className={ location.pathname == "/safety-security" ? "active" : "" }><Link to="/safety-security">Safety and Security</Link></li>
                                <li className={ location.pathname == "/terms&conditions" ? "active" : "" }><Link to="/terms&conditions">Terms and Conditoins </Link></li>
                                <li className={location.pathname == "/privacy-policy" ? "active" : ""  }><Link to="/privacy-policy">Privacy Policy</Link></li>
                                <li className={location.pathname == "/contactus" ? "active" : ""  }><Link to="/contactus">Contact us</Link></li>
                                <li className={location.pathname == "/career" ? "active" : ""  } ><Link to="/career">Career</Link></li>
                                <li className={location.pathname == "/partnerswithwfrlee" ? "active" : ""  }><Link to="/partnerswithwfrlee">Partners with wfrlee</Link></li>
                                <li className={location.pathname == "/partnerswithwfrlee" ? "active" : ""  }><Link to="/faq">FAQ</Link></li>
                            </ul>
                        </div>
                        <div className="col-md-9">
                            <h1>{selectcmsData != null ? selectcmsData.page_title : null}</h1>
                            <div contentEditable='false' dangerouslySetInnerHTML={{ __html: `${selectcmsData != null ? selectcmsData.common_content : null}` }}></div>
                             
                            {/* <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit,</p>
                            <p>sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem.Nemo enim ipsam voluptatem quia voluptas sit aspernatur.</p>
                            <p>sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem.Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem.Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem.Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem.Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem.</p> */}
                        </div>
                    </div>
                </div>
            </div>

            {/* //////////Common page Section/////////// */}

            {/* //////////Get Special Section/////////// */}
            <div className="container">
                <div className="row">
                    <div className="col-sm-12">
                        <div className="getspecial">
                            <h3>
                                <span>Let’s Explore the World</span>
                                Get Special Offers in Your Inbox
                            </h3>
                            <Form>
                                <Form.Group className="getspecial-form" controlId="exampleForm.ControlInput1">
                                    <Form.Control type="email" placeholder="Submit your email" />
                                    <Button className="planeicon"><img src='./img/plane.svg' alt="" /></Button>
                                </Form.Group>
                            </Form>
                        </div>
                    </div>
                </div>
            </div>

            {/* //////////Footer Section/////////// */}

            {/* <footer>
                <div className="container">
                    <div className="row">
                        <div className="col-md-4">
                            <img src='./img/logo-white.svg' alt="" className="footerlogo" />
                            <ul className="footlocation">
                                <li><img src='./img/location.svg' alt="" />  123 address st. </li>
                                <li><img src='./img/call-calling.svg' alt="" />  <Link to="#">+971-589706050</Link> </li>
                                <li><img src='./img/send-2.svg' alt="" />  <Link to="#">wfrlee.com@gmail.com</Link>  </li>
                            </ul>
                        </div>
                        <div className="col-md-4">
                            <div className="footerpadding">
                                <h3>Company</h3>
                                <ul>
                                    <li><Link to="/"> Home</Link></li>
                                    <li><Link to="#">Register</Link></li>
                                    <li><Link to="/aboutus">About us</Link></li>
                                    <li><Link to="#">Careers</Link></li>
                                    <li><Link to="#">Contact us</Link></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="footerpadding">
                                <h3>Other Links</h3>
                                <ul>
                                    <li><Link to="#">Safety and Security</Link></li>
                                    <li><Link to="">Terms & Conditions</Link></li>
                                    <li><Link to="#">Privacy Policy</Link></li>
                                    <li><Link to="#">Referral Page</Link></li>
                                    <li><Link to="#">Partner with wfrlee.com</Link></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="whiteborder"></div>
                <div className="container">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="footer-socialarea">
                                <Link to="#"><GrFacebookOption /></Link>
                                <Link to="#"><GrTwitter /></Link>
                                <Link to="#"><GrLinkedinOption /></Link>
                                <Link to="#"><GrInstagram /></Link>
                                <Link to="#"><GrYoutube /></Link>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="copyright">Copyright @ Techit LLC. All Rights Reserved</div>
                        </div>
                    </div>
                </div>
            </footer> */}
        </>
    )

}

const mapStateToProps = createStructuredSelector({  
languageToShow:selectlanguageToShow,
selectcmsData:selectcmsData    
});
const mapDispatchToProps = dispatch => ({
    cmsGetDataStart: data => dispatch(cmsGetDataStart(data)),
    selectLanguage: data => dispatch(selectLanguage(data))

});


export default connect(mapStateToProps,mapDispatchToProps)(TermsAndConditionPage);
