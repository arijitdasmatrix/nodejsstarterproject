import React, { useEffect, useState } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { AiOutlineEyeInvisible } from "react-icons/ai";
import { AiOutlineEye } from "react-icons/ai";
import LoginForm from "./../../components/LoginForm/LoginForm";
import RegistrationForm from "./../../components/RegistrationForm/RegistrationForm";
import SocialLogin from "../../components/SocialLogin/SocialLogin";
import { useSelector } from "react-redux";
import profilePic from "../../assets/images/ProfilePic.png";
import Footer from "../../components/Layouts/Footer/Footer";
import { createStructuredSelector } from "reselect";
import { selectSocialLoginUser } from "./../../redux/user/user.selectors";
import { connect } from "react-redux";

const LoginPage = ({ userData, handleCloseLoginPopup, search_type }) => {
  const stateData = useSelector((state) => state.userReducer);
  const [currentTab, setCurrentTab] = useState("login");
  const currentLocation = useLocation();
  //console.log("currentLocation",currentLocation.pathname);
  const navigate = useNavigate();
  useEffect(() => {
    console.log(currentLocation.pathname);
    if (
      currentLocation.pathname == "/login" ||
      currentLocation.pathname == "/bidguestuser" ||
      currentLocation.pathname == "/hourlyguestuser"
    ) {
      setCurrentTab("login");
    } else {
      setCurrentTab("sign-up");
    }
  }, [currentLocation.pathname]);
  function handleSelect(key) {
    // alert('selected ' + key);
    //  this.setState({key});
    setCurrentTab(key);
  }
  console.log(currentTab);
  return (
    <>
      {/* Header Section sssss*/}

      <>{console.log("userData", userData)}</>
      {/* //////////loginSection/////////// */}
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="logtotal customform">
              <Tabs
                activeKey={currentTab}
                id="login-tab"
                className="logintab"
                onSelect={handleSelect}
              >
                <Tab eventKey="login" title="Login">
                  <LoginForm
                    handleCloseLoginPopup={handleCloseLoginPopup}
                    search_type={search_type}
                  />
                  <p className="text-center">
                    or <br />
                    Login with
                  </p>
                  <SocialLogin
                    handleCloseLoginPopup={handleCloseLoginPopup}
                    search_type={search_type}
                  />
                  <p className="text-center">
                    Don’t Have an Account?{" "}
                    <span
                      // to="/sign-up"
                      onClick={() => {
                        if (
                          currentLocation.pathname == "/bidguestuser" ||
                          currentLocation.pathname == "/hourlyguestuser"
                        ) {
                          setCurrentTab("sign-up");
                        } else {
                          navigate("/sign-up");
                        }
                      }}
                      className="login_link"
                    >
                      Signup
                    </span>
                  </p>
                  <p className="text-center pt-30">
                    Unable to Login <Link to="/contactus">Contact us</Link>
                  </p>
                </Tab>
                <Tab eventKey="sign-up" title="Signup">
                  <RegistrationForm
                    handleCloseLoginPopup={handleCloseLoginPopup}
                    search_type={search_type}
                  />
                  <p className="text-center">
                    or <br />
                    Login with
                  </p>
                  <SocialLogin
                    handleCloseLoginPopup={handleCloseLoginPopup}
                    search_type={search_type}
                  />
                  <p className="text-center">
                    Already Have an Account?{" "}
                    <span
                      // to="/login"
                      onClick={() => {
                        if (
                          currentLocation.pathname == "/bidguestuser" ||
                          currentLocation.pathname == "/hourlyguestuser"
                        ) {
                          setCurrentTab("login");
                        } else {
                          navigate("/login");
                        }
                      }}
                      className="login_link"
                    >
                      Signin
                    </span>
                  </p>
                </Tab>
              </Tabs>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Footer Section/////////// */}
      {/* <Footer /> */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  userData: selectSocialLoginUser,
});

export default connect(mapStateToProps)(LoginPage);
