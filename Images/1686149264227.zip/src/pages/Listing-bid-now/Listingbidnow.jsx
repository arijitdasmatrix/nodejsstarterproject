import React, { useEffect, useState, useRef } from "react";
import { Button, Dropdown, Form, Tabs, Tab, Pagination } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useSearchParams, useLocation } from "react-router-dom";
import { createStructuredSelector } from "reselect";
import { connect } from "react-redux";
import { selectlanguageToShow } from "../../redux/language/language.selectors";
import {
  selectHotelDataList,
  selectHotelAminityData,
  selectFavouriteHotelSearchData,
  handleSearchRequestData,
  searchFilterAddOrNot,
  selectHotelCity,
} from "./../../redux/hotels/hotel.selectors";
import {
  searchFilterDataSave,
  getHotelListRequest,
  getHotelAnimityStart,
  stateClearAfterAdd,
  hotelToggleAddOrNot,
  placeStateDataSave,
  hotelRouteStateHandler
} from "../../redux/hotels/hotel.actions";
import HotelList from "./../../components/Hotels/HotelList/hotellist";
import GoogleMaps from "./../../components/googleMaps/googleMaps";
import places from "./places.json"
import { CountryCodes } from "validator/lib/isISO31661Alpha2";
import HotelSearchForOthers from "./../../components/HeaderSearch/HeaderSearch";
import MultiRangeSlider, { ChangeResult } from "multi-range-slider-react";
import { selectCurrentUser } from "./../../redux/user/user.selectors";
import {
  selectFavouriteHotel,
  hotelListDataLoading,
  TotalHotelPageCount,
  selectHotelBidNowPageRouteData,
  selectHotelDetailsPageRouteData
} from "./../../redux/hotels/hotel.selectors";
import { searchDataRemove,hotelWheatherApiRequest,hotelRouteDetailsStateHandler } from "./../../redux/hotels/hotel.actions";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";

const ListingbidnowPage = ({
  selectFavouriteHotel,
  searchDataRemove,
  languageToShow,
  getHotelListRequest,
  selectHotelDataList,
  getHotelAnimityStart,
  slectAminityData,
  selectCurrentUser,
  stateClearAfterAdd,
  handleSearchRequestData,
  hotelListDataLoading,
  searchFilterDataSave,
  saveloadeddata,
  searchFilterAddOrNot,
  hotelToggleAddOrNot,
  TotalHotelPageCount,
  placeStateDataSave,
  selectHotelCity,
  hotelWheatherApiRequest,
  hotelRouteStateHandler,
  selectHotelBidNowPageRouteData,
  selectHotelDetailsPageRouteData,
  hotelRouteDetailsStateHandler
}) => {
  var listSlide = {
    arrows: true,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
  };

  const [searchParams] = useSearchParams();
  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedAminity, setSelectedAminity] = useState([]);
  const [selectStar, setSelectStar] = useState([]);
  const [hotelBookingPrice, setHotelBookingPrice] = useState(0);
  const [minValue, setMinValue] = useState(0);
  const [maxValue, setMaxValue] = useState(10000);
  const [minValue2, setMinValue2] = useState(0);
  const [maxValue2, setMaxValue2] = useState(10000);
  const [minValueIni1, set_minValueIni1] = useState(0);
  const [maxValueIni2, set_maxValueIni2] = useState(5000);
  const [shortBy, setShortBy] = useState("");
  const navigate = useNavigate();
  const location = useLocation();
  const listInnerRef = useRef();
  const [currPage, setCurrPage] = useState(1);
  const [prevPage, setPrevPage] = useState(0);
  const [userList, setUserList] = useState([]);
  const [lastList, setLastList] = useState(false);
  const [shortByArrow,setShortByArrow] = useState(false);
  useEffect(() => {
    const pagesavg = (TotalHotelPageCount + 4 - 1) / 4;
    const pagesRound = Math.round(pagesavg);
    setTotalPages(pagesRound);
  }, [TotalHotelPageCount]);

  ///  console.log(searchParams.get('search_type'), searchParams.get('city'), searchParams.get('check_in_date'),
  //   searchParams.get('check_out_date'), searchParams.get('adults'), searchParams.get('children'), searchParams.get('rooms')
  // );

  //console.log("language",languageToShow,selectHotelDataList)
  // console.log("aminity data", slectAminityData)
  useEffect(() => {
    const data = {
      language: languageToShow,
      search_type: searchParams.get("search_type"),
      city: searchParams.get("city"),
      book_for: searchParams.get("book_for"),
      check_in_date: searchParams.get("check_in_date"),
      check_out_date: searchParams.get("check_out_date"),
      adults: searchParams.get("adults"),
      children: searchParams.get("children"),
      rooms: searchParams.get("rooms"),
    };

    //getHotelListRequest(data);
    hotelWheatherApiRequest(searchParams?.get("city"));

    if (languageToShow != "undefined") {
      getHotelAnimityStart(data);
    }
  }, []);

  const changeAminityselectaminity = (id) => {
    //  console.log(selectedAminity);
    const selectedCheckboxes = selectedAminity;

    const findIdx = selectedCheckboxes.indexOf(id);
    if (findIdx > -1) {
      setSelectedAminity((prev) => prev.filter((fruit) => fruit !== id));
      //   selectedCheckboxes.splice(findIdx, 1);
    } else {
      //  selectedCheckboxes.push(id);
      setSelectedAminity((prev) => [...prev, id]);
    }
    // setSelectedAminity(selectedCheckboxes);
  };
  const handlePrice = (e) => {
    console.log(e.target.value);
    setHotelBookingPrice(e.target.value);
  };
  const handlestar = (star) => {
    // console.log("star", star);
    const selectedCheckboxes = selectStar;
    const findIdx = selectedCheckboxes.indexOf(star);
    if (findIdx > -1) {
      // selectedCheckboxes.splice(findIdx, 1);
      setSelectStar((prev) => prev.filter((fruit) => fruit !== star));
    } else {
      // selectedCheckboxes.push(star);
      // console.log(selectedCheckboxes);
      // setSelectStar(selectedCheckboxes);
      setSelectStar((prev) => [...prev, star]);
    }
  };

  ///   console.log("WWWEEE", selectedAminity,selectStar,maxValueIni2);

  useEffect(() => {
    const filters = {
      shortby: shortBy,
      price: [parseInt(minValueIni1), parseInt(maxValueIni2)],
      amenity: selectedAminity,
      star: selectStar,
    };
    searchFilterDataSave(filters);
    const data = {
      filter: searchFilterAddOrNot,
      language: languageToShow,
      search_type: searchParams.get("search_type"),
      city: searchParams.get("city"),
      book_for: searchParams.get("book_for"),
      check_in_date: searchParams.get("check_in_date"),
      check_out_date: searchParams.get("check_out_date"),
      adults: searchParams.get("adults"),
      children: searchParams.get("children"),
      rooms: searchParams.get("rooms"),
      sort_by: shortBy,
      filters: encodeURIComponent(JSON.stringify(filters)),
    };
    placeStateDataSave(searchParams.get("city"));
    getHotelListRequest(data);
  }, []);
  const handleResetEvent = () => {
    setSelectedAminity([]);
    set_minValueIni1(0);
    set_maxValueIni2(5000);
    setSelectStar([]);
    hotelToggleAddOrNot(false);
  };

  const handleApplyEvent = () => {
    const filters = {
      price: [parseInt(minValueIni1), parseInt(maxValueIni2)],
      amenity: selectedAminity,
      star: selectStar,
    };
    const data = {
      filter: true,
      language: languageToShow,
      search_type: searchParams.get("search_type"),
      city: searchParams.get("city"),
      book_for: searchParams.get("book_for"),
      check_in_date: searchParams.get("check_in_date"),
      check_out_date: searchParams.get("check_out_date"),
      adults: searchParams.get("adults"),
      children: searchParams.get("children"),
      rooms: searchParams.get("rooms"),
      sort_by: shortBy,
      filters: encodeURIComponent(JSON.stringify(filters)),
    };
    placeStateDataSave(searchParams.get("city"));
    getHotelListRequest(data);
    hotelToggleAddOrNot(true);
  };

  useEffect(() => {
    if (
      selectFavouriteHotel != null &&
      (selectFavouriteHotel.message == "Hotel added to favourite." ||
        selectFavouriteHotel.message == "Hotel removed from favourite.")
    ) {
      const filters = {
        price: [parseInt(minValueIni1), parseInt(maxValueIni2)],
        amenity: selectedAminity,
        star: selectStar,
      };
      const data = {
        filter: searchFilterAddOrNot,
        language: languageToShow,
        search_type: searchParams.get("search_type"),
        city: searchParams.get("city"),
        book_for: searchParams.get("book_for"),
        check_in_date: searchParams.get("check_in_date"),
        check_out_date: searchParams.get("check_out_date"),
        adults: searchParams.get("adults"),
        children: searchParams.get("children"),
        rooms: searchParams.get("rooms"),
        sort_by: "recommended",
        filters: encodeURIComponent(JSON.stringify(filters)),
      };
      placeStateDataSave(searchParams.get("city"));
      getHotelListRequest(data);
      stateClearAfterAdd();
    }
  }, [selectFavouriteHotel]);

  useEffect(() => {
    const filters = {
      shortby: shortBy,
      price: [parseInt(minValueIni1), parseInt(maxValueIni2)],
      amenity: selectedAminity,
      star: selectStar,
    };
    searchFilterDataSave(filters);
  }, [
    parseInt(minValueIni1),
    parseInt(maxValueIni2),
    selectedAminity,
    shortBy,
    selectStar,
  ]);

  window.onpopstate = () => {
    // alert("2");
    //navigate("/");
    //  console.log("DDDDDDD")
    // navigate(-1)
  };

  useEffect(() => {
    return () => {
      searchDataRemove();
    };
  });
  const nearToTop = () => {
    window.scroll(0, 0);
  };
  const radioChangeHandler = (e) => {
    setShortBy(e.target.value);
  };
  const handlePagination = (pages) => {
    console.log(totalPages <= pages);
    if (pages <= totalPages) {
      // console.log("pagess",pages);
      setCurrentPage(pages);
    }
  };

  window.onscroll = function (ev) {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight) {
    }
  };
  const handleshortby = () => {
    setShortByArrow(!shortByArrow);
  }

  useEffect(() => {

    setTimeout(()=>{
      hotelRouteDetailsStateHandler(null)    
    }, 3000)

  }, [])
  console.log("Hello-world-Route_state",selectHotelBidNowPageRouteData,selectHotelDetailsPageRouteData);
  return (
    <>
      {/* inner banner start */}

      <div className="inner-banner">
        <div className="container">
          {/* search hotel start */}
          <div className="row">
            <div className="col-lg-12">
              <div className="search-hotel">
                <HotelSearchForOthers />
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* inner banner end */}

      {/* listing page start */}

      <div className="listing-wrapper">
        <div className="container">
          <div className="row">
            <div className="col-lg-3">
              {/* sort by start */}
              <div className="sort-by">
                <Dropdown>
                  <Dropdown.Toggle variant="" id="sort" >
                    <label  style={{ paddingTop: "5px" }}>Sort By</label>{" "}
                     { shortByArrow ? <img src="./img/up-arrow.svg" alt="arrow up down" onClick={handleshortby}  /> : <img src="./img/down-arrow.svg" alt="arrow up down" onClick={handleshortby}  /> }
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Form>
                      {["radio"].map((type) => (
                        <div key={`inline-${type}`}>
                          <Form.Check
                            label="Recommended"
                            name="group1"
                            type={type}
                            value="recommended"
                            id={`inline-${type}-1`}
                            onChange={radioChangeHandler}
                            checked={shortBy == "recommended"}
                          />
                          {/* <Form.Check
                            label="Near city centre"
                            name="group1"
                            type={type}
                            id={`inline-${type}-2`}
                          /> */}

                          <Form.Check
                            label="Price : Low to High"
                            value="price_low_to_high"
                            name="group1"
                            type={type}
                            id={`inline-${type}-3`}
                            onChange={radioChangeHandler}
                            checked={shortBy == "price_low_to_high"}
                          />

                          <Form.Check
                            label="Price : High to Low"
                            value="price_high_to_low"
                            name="group1"
                            type={type}
                            id={`inline-${type}-4`}
                            onChange={radioChangeHandler}
                            checked={shortBy == "price_high_to_low"}
                          />
                        </div>
                      ))}
                    </Form>
                  </Dropdown.Menu>
                </Dropdown>
              </div>
              {/* sort by end */}

              {/* Price Range start */}
              <div className="content-box">
                <div className="title">Select Price Range</div>
                <div className="price-range">
                  <MultiRangeSlider
                    min={0}
                    max={10000}
                    minValue={minValueIni1}
                    maxValue={maxValueIni2}
                    onChange={(e) => {
                      set_minValueIni1(e.minValue);
                      set_maxValueIni2(e.maxValue);
                    }}
                    step={5}
                    label={false}
                    ruler={false}
                    style={{
                      border: "none",
                      boxShadow: "none",
                      padding: "40px 15px 20px 15px",
                    }}
                    barLeftColor="#000000"
                    barInnerColor="#3488CD"
                    barRightColor="#000000"
                    thumbLeftColor="lime"
                    thumbRightColor="lime"
                  />
                </div>
              </div>
              {/* Price Range end */}

              {/* Filter by start */}
              <div className="content-box">
                <div className="title">Filter By</div>
                <div className="title-sm">Amenities</div>
                <div className="item-box forscroll">
                  <Form>
                    {slectAminityData.length > 0
                      ? slectAminityData.map((aminity) => (
                          <>
                            <Form.Group controlId="formBasicCheckbox">
                              <Form.Check
                                type="checkbox"
                                label={aminity.amenity_name}
                                onChange={() =>
                                  changeAminityselectaminity(aminity.id)
                                }
                                selected={selectedAminity.includes(aminity.id)}
                                checked={selectedAminity.includes(aminity.id)}
                              />
                            </Form.Group>
                          </>
                        ))
                      : null}

                    {/* <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Wifi" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Baggages" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Pool And Spa" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Breverages" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Beach View" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Breakfast" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Restaurant" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Meeting Room" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Gym" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Hot Water" />
                                        </Form.Group>

                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Dry Cleaning" />
                                        </Form.Group>
                                        <Form.Group controlId="formBasicCheckbox">
                                            <Form.Check type="checkbox" label="Accept Cash" />
                                        </Form.Group> */}
                  </Form>
                </div>
              </div>
              {/* Filter by start */}

              {/* Star Rating start */}
              <div className="content-box">
                <div className="title">Star Rating</div>

                <div className="item-box">
                  <Form>
                    <Form.Group controlId="formBasicCheckbox">
                      <Form.Check
                        type="checkbox"
                        label="5 star"
                        onChange={() => handlestar(5)}
                        checked={selectStar.includes(5)}
                      />
                    </Form.Group>
                    <Form.Group controlId="formBasicCheckbox">
                      <Form.Check
                        type="checkbox"
                        label="4 star"
                        onChange={() => handlestar(4)}
                        checked={selectStar.includes(4)}
                      />
                    </Form.Group>
                    <Form.Group controlId="formBasicCheckbox">
                      <Form.Check
                        type="checkbox"
                        label="3 star"
                        onChange={() => handlestar(3)}
                        checked={selectStar.includes(3)}
                      />
                    </Form.Group>
                    <Form.Group controlId="formBasicCheckbox">
                      <Form.Check
                        type="checkbox"
                        label="2 star"
                        onChange={() => handlestar(2)}
                        checked={selectStar.includes(2)}
                      />
                    </Form.Group>
                    <Form.Group controlId="formBasicCheckbox">
                      <Form.Check
                        type="checkbox"
                        label="1 star"
                        onChange={() => handlestar(1)}
                        checked={selectStar.includes(1)}
                      />
                    </Form.Group>
                  </Form>
                </div>
              </div>
              <button className="reset-now" onClick={handleApplyEvent}>
                Apply
              </button>
              <br />
              <button className="reset-now" onClick={handleResetEvent}>
                Reset
              </button>
            {/* Star Rating end */}
            </div>
            <div className="col-lg-9">
              {/* listing header start */}
              <div className="listing-header" id="backtotop">
                <div className="header-left">
                  <h3>
                    {selectHotelDataList != null
                      ? selectHotelDataList.length
                      : null}{" "}
                    {saveloadeddata != null
                      ? saveloadeddata.searchButtonShow == "bid"
                        ? "Bid"
                        : "Hourly"
                      : ""}{" "}
                    Hotels in {saveloadeddata != null ? selectHotelCity : ""}
                  </h3>
                </div>
                <div className="header-right">
                  <div className="map">
                    {selectHotelDataList != undefined ? (
                      <GoogleMaps  center={{ lat: 40.6451594, lng: -74.0850826 }}
                      zoom={10}
                      places={places} />
                    ) : null}
                  </div>
                </div>
              </div>

              {/* listing header end */}
              {/* listing box start */}

              {hotelListDataLoading ? (
                <Skeleton count={10} />
              ) : selectHotelDataList != null ? (
                selectHotelDataList.length == 0 ? (
                  <>
                    <div className="datanotfound">
                      <img src="./img/searc.png" alt="" />
                      <h2>
                        Sorry <span>No data found</span>
                      </h2>
                    </div>
                  </>
                ) : (
                  selectHotelDataList.hotels.map((hotelList, index) => (
                    <HotelList key={index} hotelList={hotelList} />
                  ))
                )
              ) : (
                <div className="datanotfound">
                  <img src="./img/searc.png" alt="" />
                  <h2>
                    Sorry <span>No data found</span>
                  </h2>
                </div>
              )}
              {/* <div className="datanotfound">
                                <img src='./img/searc.png' alt="" />
                                <h2>Sorry <span>No data found</span></h2>
                            </div> */}

              {/* listing box end */}

              {/* listing box start */}
              {/* listing box end */}

              <div className="list-pagination">
                {/* <div className="left">
                                    <Pagination>
                                    { totalPages > 3 ?
                                         <Pagination.Prev />
                                         : null
                                        }
                                        { currentPage > 1 ?  
                                         <Pagination.Item onClick={() => { handlePagination(currentPage - 1)}} >{currentPage - 1}</Pagination.Item>
                                        : 
                                         null
                                        }
                                       
                                        <Pagination.Item onClick={() => { handlePagination(currentPage)}} active>{currentPage }</Pagination.Item>
                                        {  totalPages == currentPage ? null :  
                                            <Pagination.Item onClick={() => { handlePagination(currentPage + 1) }}>{currentPage + 1}</Pagination.Item>
                                        }
                                       
                                        
                                        { totalPages > 3 ?
                                         <Pagination.Ellipsis /> 
                                         : null
                                        }
                                       
                                        { totalPages > 3 ?
                                         <Pagination.Item>{totalPages}</Pagination.Item>
                                         : null
                                        }
                                        
                                        { totalPages > 3 ?
                                         <Pagination.Next />   
                                         : null
                                        }
                                       

                                    </Pagination>
                                </div> */}
                {/* <div className="right">Showing 1 - 25</div> */}
              </div>

              <Button className="back-to-top" onClick={nearToTop}>
                BACK TO TOP
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* listing page end */}

      {/* //////////Footer Section/////////// */}

      {/* <footer>
                <div className="container">
                    <div className="row">
                        <div className="col-md-4">
                            <img src='./img/logo-white.svg' alt="" className="footerlogo" />
                            <ul className="footlocation">
                                <li><img src='./img/location.svg' alt="" />  123 address st. </li>
                                <li><img src='./img/call-calling.svg' alt="" />  <Link to="#">+971-589706050</Link> </li>
                                <li><img src='./img/send-2.svg' alt="" />  <Link to="#">wfrlee.com@gmail.com</Link>  </li>
                            </ul>
                        </div>
                        <div className="col-md-4">
                            <div className="footerpadding">
                                <h3>Company</h3>
                                <ul>
                                    <li><Link to="/"> Home</Link></li>
                                    <li><Link to="#">Register</Link></li>
                                    <li><Link to="/aboutus">About us</Link></li>
                                    <li><Link to="#">Careers</Link></li>
                                    <li><Link to="#">Contact us</Link></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="footerpadding">
                                <h3>Other Links</h3>
                                <ul>
                                    <li><Link to="#">Safety and Security</Link></li>
                                    <li><Link to="#">Terms & Conditions</Link></li>
                                    <li><Link to="#">Privacy Policy</Link></li>
                                    <li><Link to="#">Referral Page</Link></li>
                                    <li><Link to="#">Partner with wfrlee.com</Link></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="whiteborder"></div>
                <div className="container">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="footer-socialarea">
                                <Link to="#"><GrFacebookOption /></Link>
                                <Link to="#"><GrTwitter /></Link>
                                <Link to="#"><GrLinkedinOption /></Link>
                                <Link to="#"><GrInstagram /></Link>
                                <Link to="#"><GrYoutube /></Link>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="copyright">Copyright @ Techit LLC. All Rights Reserved</div>
                        </div>
                    </div>
                </div>
            </footer> */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  selectHotelDataList: selectHotelDataList,
  slectAminityData: selectHotelAminityData,
  selectCurrentUser: selectCurrentUser,
  selectFavouriteHotel: selectFavouriteHotel,
  handleSearchRequestData: handleSearchRequestData,
  hotelListDataLoading: hotelListDataLoading,
  saveloadeddata: selectFavouriteHotelSearchData,
  searchFilterAddOrNot: searchFilterAddOrNot,
  TotalHotelPageCount: TotalHotelPageCount,
  selectHotelCity: selectHotelCity,
  selectHotelBidNowPageRouteData:selectHotelBidNowPageRouteData,
  selectHotelDetailsPageRouteData:selectHotelDetailsPageRouteData
});
const mapDispatchToProps = (dispatch) => ({
  getHotelListRequest: (data) => dispatch(getHotelListRequest(data)),
  getHotelAnimityStart: (data) => dispatch(getHotelAnimityStart(data)),
  stateClearAfterAdd: () => dispatch(stateClearAfterAdd()),
  searchDataRemove: () => dispatch(searchDataRemove()),
  searchFilterDataSave: (data) => dispatch(searchFilterDataSave(data)),
  hotelToggleAddOrNot: (data) => dispatch(hotelToggleAddOrNot(data)),
  placeStateDataSave: (data) => dispatch(placeStateDataSave(data)),
  hotelWheatherApiRequest: (data) => dispatch(hotelWheatherApiRequest(data)),
  hotelRouteStateHandler: (data) => dispatch(hotelRouteStateHandler(data)),
  hotelRouteDetailsStateHandler:(data) => dispatch(hotelRouteDetailsStateHandler(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(ListingbidnowPage);
