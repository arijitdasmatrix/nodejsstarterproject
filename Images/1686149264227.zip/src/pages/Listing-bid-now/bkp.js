{/* <div className="listing-box">
<div className="slide-box">
    <Slider {...listSlide}>
        <div className="slide-item">
            <img src='./img/list-slide-2.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-1.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-3.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>

    </Slider>
</div>
<div className="right">
    <div className="top-bar">
        <div className="left-txt">
            <div className="title">Mansard Riyadh</div>
            <div className="star-rating">
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
            </div>
        </div>

        <div className="rating-content">
            <div className="comment">
                <div className="feedback">Very Good</div>
                <div className="reviews">292 Guest Reviews</div>
            </div>
            <div className="rating-txt">8.9</div>
        </div>
    </div>
    <div className="address">
        <div className="icon"><img src="./img/icon-address.svg" alt="" /></div>
        22nd St, PO Box 39 39 71, Dubai,<br></br>Dubai PO Box 39
    </div>
    <div className="amenities">
        <div className="amenities-item">
            <ul>
                <li><span className="icon"><img src="./img/icon-cash.svg" alt="" /></span>Accepts Cash</li>
                <li><span className="icon"><img src="./img/icon-air-conditioning.svg" alt="" /></span>Air Conditioning</li>
                <li><span className="icon"><img src="./img/icon-baggage.svg" alt="" /></span>Baggage Storage</li>
                <li><span className="icon"><img src="./img/icon-parking.svg" alt="" /></span>Free Car Parking</li>
                <li><span className="icon"><img src="./img/icon-pool.svg" alt="" /></span>Pool and Spa</li>
                <li><span className="icon"><img src="./img/icon-dry-cleaning.svg" alt="" /></span>Dry Cleaning</li>
                <li><span className="icon"><img src="./img/icon-food.svg" alt="" /></span>Food and Breveges</li>
                <li><span className="icon"><img src="./img/icon-beach.svg" alt="" /></span>Beach View</li>

            </ul>
            <Link to="#" className="link-more">see more amenities</Link>
        </div>
        <div className="price-content">
            <ul>
                <li>
                    <span className="hrs">3 hrs</span>
                    <span className="rates">aed 150</span>
                </li>
                <li>
                    <span className="hrs">6 hrs</span>
                    <span className="rates">aed 250</span>
                </li>
                <li>
                    <span className="hrs">12 hrs</span>
                    <span className="rates">aed 350</span>
                </li>
            </ul>
            <Link to="#" className="bid-now">BID now</Link>
        </div>
    </div>
</div>
</div>
{/* listing box end */}

{/* listing box start */}
<div className="listing-box">
<div className="slide-box">
    <Slider {...listSlide}>
        <div className="slide-item">
            <img src='./img/list-slide-3.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-2.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-1.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>

    </Slider>
</div>
<div className="right">
    <div className="top-bar">
        <div className="left-txt">
            <div className="title">Mansard Riyadh</div>
            <div className="star-rating">
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
            </div>
        </div>

        <div className="rating-content">
            <div className="comment">
                <div className="feedback">Very Good</div>
                <div className="reviews">292 Guest Reviews</div>
            </div>
            <div className="rating-txt">8.9</div>
        </div>
    </div>
    <div className="address">
        <div className="icon"><img src="./img/icon-address.svg" alt="" /></div>
        22nd St, PO Box 39 39 71, Dubai,<br></br>Dubai PO Box 39
    </div>
    <div className="amenities">
        <div className="amenities-item">
            <ul>
                <li><span className="icon"><img src="./img/icon-cash.svg" alt="" /></span>Accepts Cash</li>
                <li><span className="icon"><img src="./img/icon-air-conditioning.svg" alt="" /></span>Air Conditioning</li>
                <li><span className="icon"><img src="./img/icon-baggage.svg" alt="" /></span>Baggage Storage</li>
                <li><span className="icon"><img src="./img/icon-parking.svg" alt="" /></span>Free Car Parking</li>
                <li><span className="icon"><img src="./img/icon-pool.svg" alt="" /></span>Pool and Spa</li>
                <li><span className="icon"><img src="./img/icon-dry-cleaning.svg" alt="" /></span>Dry Cleaning</li>
                <li><span className="icon"><img src="./img/icon-food.svg" alt="" /></span>Food and Breveges</li>
                <li><span className="icon"><img src="./img/icon-beach.svg" alt="" /></span>Beach View</li>

            </ul>
            <Link to="#" className="link-more">see more amenities</Link>
        </div>
        <div className="price-content">
            <ul>
                <li>
                    <span className="hrs">3 hrs</span>
                    <span className="rates">aed 150</span>
                </li>
                <li>
                    <span className="hrs">6 hrs</span>
                    <span className="rates">aed 250</span>
                </li>
                <li>
                    <span className="hrs">12 hrs</span>
                    <span className="rates">aed 350</span>
                </li>
                <Link to="#" className="bid-now">BID now</Link>
            </ul>

        </div>
    </div>
</div>
</div>
{/* listing box end */}

{/* listing box start */}
<div className="listing-box">
<div className="slide-box">
    <Slider {...listSlide}>
        <div className="slide-item">
            <img src='./img/list-slide-4.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-2.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-3.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>

    </Slider>
</div>
<div className="right">
    <div className="top-bar">
        <div className="left-txt">
            <div className="title">Mansard Riyadh</div>
            <div className="star-rating">
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
            </div>
        </div>

        <div className="rating-content">
            <div className="comment">
                <div className="feedback">Very Good</div>
                <div className="reviews">292 Guest Reviews</div>
            </div>
            <div className="rating-txt">8.9</div>
        </div>
    </div>
    <div className="address">
        <div className="icon"><img src="./img/icon-address.svg" alt="" /></div>
        22nd St, PO Box 39 39 71, Dubai,<br></br>Dubai PO Box 39
    </div>
    <div className="amenities">
        <div className="amenities-item">
            <ul>
                <li><span className="icon"><img src="./img/icon-cash.svg" alt="" /></span>Accepts Cash</li>
                <li><span className="icon"><img src="./img/icon-air-conditioning.svg" alt="" /></span>Air Conditioning</li>
                <li><span className="icon"><img src="./img/icon-baggage.svg" alt="" /></span>Baggage Storage</li>
                <li><span className="icon"><img src="./img/icon-parking.svg" alt="" /></span>Free Car Parking</li>
                <li><span className="icon"><img src="./img/icon-pool.svg" alt="" /></span>Pool and Spa</li>
                <li><span className="icon"><img src="./img/icon-dry-cleaning.svg" alt="" /></span>Dry Cleaning</li>
                <li><span className="icon"><img src="./img/icon-food.svg" alt="" /></span>Food and Breveges</li>
                <li><span className="icon"><img src="./img/icon-beach.svg" alt="" /></span>Beach View</li>

            </ul>
            <Link to="#" className="link-more">see more amenities</Link>
        </div>
        <div className="price-content">
            <ul>
                <li>
                    <span className="hrs">3 hrs</span>
                    <span className="rates">aed 150</span>
                </li>
                <li>
                    <span className="hrs">6 hrs</span>
                    <span className="rates">aed 250</span>
                </li>
                <li>
                    <span className="hrs">12 hrs</span>
                    <span className="rates">aed 350</span>
                </li>
                <Link to="#" className="bid-now">BID now</Link>
            </ul>

        </div>
    </div>
</div>
</div>
{/* listing box end */}

{/* listing box start */}
<div className="listing-box">
<div className="slide-box">
    <Slider {...listSlide}>
        <div className="slide-item">
            <img src='./img/list-slide-5.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-2.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-3.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>

    </Slider>
</div>
<div className="right">
    <div className="top-bar">
        <div className="left-txt">
            <div className="title">Mansard Riyadh</div>
            <div className="star-rating">
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
            </div>
        </div>

        <div className="rating-content">
            <div className="comment">
                <div className="feedback">Very Good</div>
                <div className="reviews">292 Guest Reviews</div>
            </div>
            <div className="rating-txt">8.9</div>
        </div>
    </div>
    <div className="address">
        <div className="icon"><img src="./img/icon-address.svg" alt="" /></div>
        22nd St, PO Box 39 39 71, Dubai,<br></br>Dubai PO Box 39
    </div>
    <div className="amenities">
        <div className="amenities-item">
            <ul>
                <li><span className="icon"><img src="./img/icon-cash.svg" alt="" /></span>Accepts Cash</li>
                <li><span className="icon"><img src="./img/icon-air-conditioning.svg" alt="" /></span>Air Conditioning</li>
                <li><span className="icon"><img src="./img/icon-baggage.svg" alt="" /></span>Baggage Storage</li>
                <li><span className="icon"><img src="./img/icon-parking.svg" alt="" /></span>Free Car Parking</li>
                <li><span className="icon"><img src="./img/icon-pool.svg" alt="" /></span>Pool and Spa</li>
                <li><span className="icon"><img src="./img/icon-dry-cleaning.svg" alt="" /></span>Dry Cleaning</li>
                <li><span className="icon"><img src="./img/icon-food.svg" alt="" /></span>Food and Breveges</li>
                <li><span className="icon"><img src="./img/icon-beach.svg" alt="" /></span>Beach View</li>

            </ul>
            <Link to="#" className="link-more">see more amenities</Link>
        </div>
        <div className="price-content">
            <ul>
                <li>
                    <span className="hrs">3 hrs</span>
                    <span className="rates">aed 150</span>
                </li>
                <li>
                    <span className="hrs">6 hrs</span>
                    <span className="rates">aed 250</span>
                </li>
                <li>
                    <span className="hrs">12 hrs</span>
                    <span className="rates">aed 350</span>
                </li>
                <Link to="#" className="bid-now">BID now</Link>
            </ul>

        </div>
    </div>
</div>
</div>
{/* listing box end */}

{/* listing box start */}
<div className="listing-box">
<div className="slide-box">
    <Slider {...listSlide}>
        <div className="slide-item">
            <img src='./img/list-slide-6.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-2.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-3.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>

    </Slider>
</div>
<div className="right">
    <div className="top-bar">
        <div className="left-txt">
            <div className="title">Mansard Riyadh</div>
            <div className="star-rating">
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
            </div>
        </div>

        <div className="rating-content">
            <div className="comment">
                <div className="feedback">Very Good</div>
                <div className="reviews">292 Guest Reviews</div>
            </div>
            <div className="rating-txt">8.9</div>
        </div>
    </div>
    <div className="address">
        <div className="icon"><img src="./img/icon-address.svg" alt="" /></div>
        22nd St, PO Box 39 39 71, Dubai,<br></br>Dubai PO Box 39
    </div>
    <div className="amenities">
        <div className="amenities-item">
            <ul>
                <li><span className="icon"><img src="./img/icon-cash.svg" alt="" /></span>Accepts Cash</li>
                <li><span className="icon"><img src="./img/icon-air-conditioning.svg" alt="" /></span>Air Conditioning</li>
                <li><span className="icon"><img src="./img/icon-baggage.svg" alt="" /></span>Baggage Storage</li>
                <li><span className="icon"><img src="./img/icon-parking.svg" alt="" /></span>Free Car Parking</li>
                <li><span className="icon"><img src="./img/icon-pool.svg" alt="" /></span>Pool and Spa</li>
                <li><span className="icon"><img src="./img/icon-dry-cleaning.svg" alt="" /></span>Dry Cleaning</li>
                <li><span className="icon"><img src="./img/icon-food.svg" alt="" /></span>Food and Breveges</li>
                <li><span className="icon"><img src="./img/icon-beach.svg" alt="" /></span>Beach View</li>

            </ul>
            <Link to="#" className="link-more">see more amenities</Link>
        </div>
        <div className="price-content">
            <ul>
                <li>
                    <span className="hrs">3 hrs</span>
                    <span className="rates">aed 150</span>
                </li>
                <li>
                    <span className="hrs">6 hrs</span>
                    <span className="rates">aed 250</span>
                </li>
                <li>
                    <span className="hrs">12 hrs</span>
                    <span className="rates">aed 350</span>
                </li>
                <Link to="#" className="bid-now">BID now</Link>
            </ul>

        </div>
    </div>
</div>
</div>
{/* listing box end */}

{/* listing box start */}
<div className="listing-box">
<div className="slide-box">
    <Slider {...listSlide}>
        <div className="slide-item">
            <img src='./img/list-slide-7.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-2.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>
        <div className="slide-item">
            <img src='./img/list-slide-3.jpg' alt="" />
            <span className="favourite"><img src='./img/icon-favourite.svg' alt="" /></span>
        </div>

    </Slider>
</div>
<div className="right">
    <div className="top-bar">
        <div className="left-txt">
            <div className="title">Mansard Riyadh</div>
            <div className="star-rating">
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
                <img src="./img/icon-review-star.svg" alt="" />
            </div>
        </div>

        <div className="rating-content">
            <div className="comment">
                <div className="feedback">Very Good</div>
                <div className="reviews">292 Guest Reviews</div>
            </div>
            <div className="rating-txt">8.9</div>
        </div>
    </div>
    <div className="address">
        <div className="icon"><img src="./img/icon-address.svg" alt="" /></div>
        22nd St, PO Box 39 39 71, Dubai,<br></br>Dubai PO Box 39
    </div>
    <div className="amenities">
        <div className="amenities-item">
            <ul>
                <li><span className="icon"><img src="./img/icon-cash.svg" alt="" /></span>Accepts Cash</li>
                <li><span className="icon"><img src="./img/icon-air-conditioning.svg" alt="" /></span>Air Conditioning</li>
                <li><span className="icon"><img src="./img/icon-baggage.svg" alt="" /></span>Baggage Storage</li>
                <li><span className="icon"><img src="./img/icon-parking.svg" alt="" /></span>Free Car Parking</li>
                <li><span className="icon"><img src="./img/icon-pool.svg" alt="" /></span>Pool and Spa</li>
                <li><span className="icon"><img src="./img/icon-dry-cleaning.svg" alt="" /></span>Dry Cleaning</li>
                <li><span className="icon"><img src="./img/icon-food.svg" alt="" /></span>Food and Breveges</li>
                <li><span className="icon"><img src="./img/icon-beach.svg" alt="" /></span>Beach View</li>

            </ul>
            <Link to="#" className="link-more">see more amenities</Link>
        </div>
        <div className="price-content">
            <ul>
                <li>
                    <span className="hrs">3 hrs</span>
                    <span className="rates">aed 150</span>
                </li>
                <li>
                    <span className="hrs">6 hrs</span>
                    <span className="rates">aed 250</span>
                </li>
                <li>
                    <span className="hrs">12 hrs</span>
                    <span className="rates">aed 350</span>
                </li>
                <Link to="#" className="bid-now">BID now</Link>
            </ul>



        </div>
    </div>
</div>
</div> 
