import React from "react";
import { Button, Dropdown, Accordion } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { useLocation } from "react-router-dom";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { faqGetDataLoad } from "./../../redux/faq/faq.actions";
import { selectfaqData } from "./../../redux/faq/faq.selectors";
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';

const FaqPage = ({selectfaqData,languageToShow,faqGetDataLoad}) => {
  const location = useLocation();

  React.useEffect(() => {
    var data = {
    language:languageToShow,    
    } 
    faqGetDataLoad(data);
    },[languageToShow])
    console.log("selectfaqData-->",selectfaqData)

  return (
    <>
      {/* //////////Common page Section/////////// */}
      <div className="commonpage">
        <div className="container">
          <div className="row">
            <div className="col-md-3">
              <ul className="leftmenu">
                <li className={location.pathname == "/aboutus" ? "active" : ""}>
                  <Link to="/aboutus">About us</Link>
                </li>
                <li
                  className={
                    location.pathname == "/safety-security" ? "active" : ""
                  }
                >
                  <Link to="/safety-security">Safety and Security</Link>
                </li>
                <li
                  className={
                    location.pathname == "/terms&conditions" ? "active" : ""
                  }
                >
                  <Link to="/terms&conditions">Terms and Conditoins </Link>
                </li>
                <li
                  className={
                    location.pathname == "/privacy-policy" ? "active" : ""
                  }
                >
                  <Link to="/privacy-policy">Privacy Policy</Link>
                </li>
                <li
                  className={location.pathname == "/contactus" ? "active" : ""}
                >
                  <Link to="/contactus">Contact us</Link>
                </li>
                <li className={location.pathname == "/career" ? "active" : ""}>
                  <Link to="/career">Career</Link>
                </li>
                <li
                  className={
                    location.pathname == "/partnerswithwfrlee" ? "active" : ""
                  }
                >
                  <Link to="/partnerswithwfrlee">Partners with wfrlee</Link>
                </li>
                <li className={location.pathname == "/faq" ? "active" : ""}>
                  <Link to="/faq">FAQ</Link>
                </li>
              </ul>
            </div>
            <div className="col-md-9">
              <div className="faq-rightsection">
                <h1>Frequently Asked Questions</h1>
                <Accordion defaultActiveKey="1" className="customaccordian">
                {selectfaqData?selectfaqData.map((eachFaq, index) => {
                  return (
                    <Accordion.Item eventKey={index}>
                      <Accordion.Header>
                        {eachFaq.question}
                      </Accordion.Header>
                      <Accordion.Body>
                        {eachFaq.answer}
                      </Accordion.Body>
                    </Accordion.Item>
                  );
                }):""}
                </Accordion>
                {/* <Link to="#" className="gen-btn">
                  Explore more FAQ
                </Link> */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Common page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({  
  languageToShow:selectlanguageToShow,
  selectfaqData:selectfaqData    
  });

const mapDispatchToProps = dispatch => ({
      faqGetDataLoad: data => dispatch(faqGetDataLoad(data)),
      // selectLanguage: data => dispatch(selectLanguage(data))
  
  });
  
  
export default connect(mapStateToProps,mapDispatchToProps)(FaqPage);

