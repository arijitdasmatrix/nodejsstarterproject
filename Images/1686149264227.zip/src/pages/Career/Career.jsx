import React from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import CareerForm from "../../components/CareerForm/CareerForm";

const CareerPage = () => {
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <>
      {/* //////////Common page Section/////////// */}
      <div className="commonpage">
        <div className="container">
          <div className="row">
            <div className="col-md-3">
              <ul className="leftmenu">
                <li>
                  <Link to="/aboutus">About us</Link>
                </li>
                <li>
                  <Link to="/safety-security">Safety and Security</Link>
                </li>
                <li>
                  <Link to="/terms&conditions">Terms and Conditoins </Link>
                </li>
                <li>
                  <Link to="/privacy-policy">Privacy Policy</Link>
                </li>
                <li>
                  <Link to="/contactus">Contact us</Link>
                </li>
                <li className="active">
                  <Link to="/career">Career</Link>
                </li>
                <li>
                  <Link to="/partnerswithwfrlee">Partners with wfrlee</Link>
                </li>
                <li>
                  <Link to="/faq">FAQ</Link>
                </li>
              </ul>
            </div>
            <div className="col-md-9">
              <div className="WL_contactmwrp customform rightFormWidth">
                <h1>Career</h1>
                <p>
                  Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut
                  odit aut fugit, sed quia ratione voluptatem sequi nesciunt.
                  Neque porro quisquam est, qui dolorem. Nemo enim ipsam
                  voluptatem quia voluptas sit aspernatur aut odit aut fugit,
                </p>
                <CareerForm />
                {/* <Form>
                  <div className="form50">
                    <Form.Group controlId="formCareerFirstname">
                      <Form.Label>Name</Form.Label>
                      <Form.Control type="text" placeholder="First Name" />
                    </Form.Group>
                    <Form.Group
                      className="lastname"
                      controlId="formCareerLastname"
                    >
                      <Form.Label>Last Name</Form.Label>
                      <Form.Control type="text" placeholder="Last Name" />
                    </Form.Group>
                  </div>
                  <Form.Group controlId="formCareerEmail">
                    <Form.Label>E-mail</Form.Label>
                    <Form.Control type="email" placeholder="E-mail address" />
                  </Form.Group>
                  <Form.Group controlId="formCareerPhone">
                    <Form.Label>Mobile Number</Form.Label>
                    <Form.Control type="Number" placeholder="Mobile Number" />
                  </Form.Group>
                  <Form.Group controlId="formCareerSubject">
                    <Form.Label>Subject</Form.Label>
                    <Form.Select>
                      <option>Position Appy for</option>
                      <option>General Instruction</option>
                    </Form.Select>
                  </Form.Group>

                  <Form.Group controlId="formCareerMessage">
                    <Form.Label>Message</Form.Label>
                    <Form.Control as="textarea" placeholder="Your message" />
                  </Form.Group>

                  <Form.Group
                    controlId="formCareerattachment"
                    className="WL-fileuplaod"
                  >
                    <Form.Label>Attachment</Form.Label>
                    <Form.Control type="file" aria-label="Attachment" />
                  </Form.Group>

                  <Button variant="" type="submit" className="formsubmit">
                    Send
                  </Button>
                </Form> */}

                {/* //////////call text Section start /////////// */}
                <div className="WL_contacttextwrp">
                  <div className="WL_innercontacttext">
                    <p className="WL_innercontacttextinner">
                      Call Us at
                      <span>
                        <Link to="tel:+971 589-706-050">+971 589-706-050</Link>
                      </span>
                    </p>
                  </div>

                  <div className="WL_innercontacttext">
                    <p className="WL_innercontacttextinner">
                      Text Us at
                      <span>
                        <Link to="mailto:info@wfrlee.com">
                          info@wfrlee.com
                        </Link>
                      </span>
                    </p>
                  </div>
                </div>
                {/* //////////call text Section end /////////// */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Common page Section/////////// */}
    </>
  );
};

export default CareerPage;
