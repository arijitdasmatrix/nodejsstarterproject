import React, {useEffect} from "react";
import { useParams } from 'react-router-dom';
import { createStructuredSelector } from 'reselect';
import { connect } from 'react-redux';
import { useNavigate } from "react-router-dom";
import { emailVerificationStart , stateClearAfterTask } from "./../../redux/user/user.actions";
import { selectEmailVerificationMessage } from "./../../redux/user/user.selectors";
const EmailVerification = ({emailVerification,selectEmailVerificationMessage,stateClearAfterTask}) => {
const params = useParams();
const navigate = useNavigate();
console.log(params,selectEmailVerificationMessage);
useEffect(() => {
emailVerification(params);
},[params]);
useEffect(() => {
if(selectEmailVerificationMessage != null)  {   
if(selectEmailVerificationMessage.success) {
stateClearAfterTask();    
navigate("/login");
}
}
},[selectEmailVerificationMessage])
return (
<>
<h2>Email Verification</h2>
</>
)

}

const mapStateToProps = createStructuredSelector({  
selectEmailVerificationMessage:selectEmailVerificationMessage
});
const mapDispatchToProps = dispatch => ({
emailVerification: data => dispatch(emailVerificationStart(data)),
stateClearAfterTask: () => dispatch(stateClearAfterTask())
});
    


export default connect(mapStateToProps,mapDispatchToProps)(EmailVerification);