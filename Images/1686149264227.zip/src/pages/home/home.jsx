
import React, { useEffect, useState, useRef } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link, useNavigate, createSearchParams } from "react-router-dom";
import useOnclickOutside from "react-cool-onclickoutside";
import ListGroup from 'react-bootstrap/ListGroup';
import usePlacesAutocomplete from "use-places-autocomplete";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { BsPlusCircle } from "react-icons/bs";
import { AiOutlineMinusCircle } from "react-icons/ai";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import TextField from "@mui/material/TextField";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import moment from "moment";
import { MobileDatePicker } from "@mui/x-date-pickers/MobileDatePicker";
import Autocomplete from "react-google-autocomplete";
import { hotelWheatherApiRequest } from "./../../redux/hotels/hotel.actions";
import { errorToast } from "../../utils/toastHelper";
import { getOfferPromotionsPartnersPreferenceRequest , getPerferenceDataList} from "./../../redux/home/home.actions"
import { connect } from "react-redux";
import { createStructuredSelector } from 'reselect';
import { selectlanguageToShow } from "../../redux/language/language.selectors";
import { selectofferspromotionsdestinationData ,selectofferLoading } from "../../redux/home/home.selectors";
import AOS from 'aos';
import 'aos/dist/aos.css';
import {
  Combobox,
  ComboboxInput,
  ComboboxPopover,
  ComboboxList,
  ComboboxOption,
  ComboboxOptionText,
} from "@reach/combobox";
import "@reach/combobox/styles.css";
const HomePage = ({getPerferenceDataList, hotelWheatherApiRequest,getOfferPromotionsPartnersPreferenceRequest,languageToShow,offersPromotionsDestinations, selectofferLoading }) => {
  const scrollCounter = document.querySelector('.js-scroll-counter');

window.addEventListener('scroll', function() {
  //scrollCounter.innerHTML = window.pageYOffset;
});

// AOS.init()

AOS.init({
  offset: 200,
  duration: 800,
  easing: 'ease-in-out-sine',
  delay: 200,
  mirror: true
});
  let dateObj = new Date();
  let nextobj = new Date();
  let month = dateObj.getUTCMonth() + 1; //months from 1-12
  const day = dateObj.getUTCDate() + 1;
  const year = dateObj.getUTCFullYear();
  const nextdate = nextobj.getUTCDate() + 2;
  const navigate = useNavigate();
  const firstRender = useRef(true);
  const [open, setOpen] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [checkoutTime, setCheckoutTime] = useState(false);
  const [getHours, setGetHours] = useState(3);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const {
    ready,
    value,
    suggestions: { status, data },
    setValue,
    clearSuggestions
  } = usePlacesAutocomplete({ callbackName: "initMap" });


  const [guestRomsPopup, setGuestRoomsPopup] = useState(false);
  const [guestRomsPopupsecond, setGuestRoomsPopupsecond] = useState(false);
  const [destinationsData,setDestinationsData] = useState(null);
  const [guestRoomData, setGuestRoomData] = useState({
    rooms: 1,
    child: 0,
    adults: 1,
  });

  const [place, setPlace] = useState("Dubai");
  const [longaddress, setLongaddress] = useState("Dubai");
  const [placeSearchError, setPlaceSearchError] = useState("");
  const [checkIn, setCheckIn] = useState(false);
  const [checkInOutValue, setCheckInOutValue] = useState({
    checkInTime:`${year}-${month}-${day}`,
    checkOutTime:`${year}-${month}-${nextdate}`
  });

  const ref = useRef(null);
  const ref1 = useRef(null);
  var preference = {
    autoplay:true,
    autoplaySpeed:1500,
    arrows: true,
    dots: false,
    slidesToShow: 5,
    slidesToScroll: 1,

    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  var partner = {
    autoplay:true,
    autoplaySpeed:1800,
    arrows: true,
    dots: false,
    slidesToShow: 5,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  var offerPromotion = {
    autoplay:true,
    autoplaySpeed:2000,
    arrows: true,
    dots: false,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
        },
      },
      {
        breakpoint: 700,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const handleInput = (e) => {
    setValue(e.target.value);
  };

  const handleSelect = (val)=> {
    setValue(val, false);
  };
  const reference = useOnclickOutside(() => {
    // When user clicks outside of the component, call it to clear and reset the suggestions data
    clearSuggestions()
  });
  const renderSuggestions = () => {
    const suggestions = data.map(({ place_id, description }) => (
      <ComboboxOption key={place_id} value={description} />
    ));

    return (
      <>
       <div ref={reference}>
        {suggestions}
        <li className="logo">
          <img
            src="https://developers.google.com/maps/documentation/images/powered_by_google_on_white.png"
            alt="Powered by Google"
          />
        </li>
        </div>
      </>
    );
  };
  const populartoleasting = (citynamedetails) => {
    console.log("Destinations", citynamedetails);
    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    let day = dateObj.getUTCDate();
    let year = dateObj.getUTCFullYear();
    window.scroll(0, 0);
    navigate(
      {
        pathname: "listingbidnow",
        search: createSearchParams({
          search_type: "bid",
          city: citynamedetails,
          check_in_date: "" + year + "-" + month + "-" + day + "",
          check_out_date: "" + year + "-" + month + "-" + (day + 1) + "",
          adults: "1",
          children: "0",
          rooms: "1",
        }).toString(),
      },
      {
        state: {
          search_type: "bid",
          city: citynamedetails,
          check_in_date: "" + year + "-" + month + "-" + day + "",
          check_out_date: "" + year + "-" + month + "-" + (day + 1) + "",
          adults: "1",
          children: "0",
          rooms: "1",
        },
      }
    );
  };


  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
    } else {
    if (checkInOutValue.checkInTime != null && isOpen == false  ) {
      handleOpen();
    }
  }
  }, [checkInOutValue.checkInTime, isOpen]);
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
  };
  // DatePicker

  const guestAndRoom = () => {
    setGuestRoomsPopup(!guestRomsPopup);
  };
  const guestAndRoomsecond = () => {
    setGuestRoomsPopupsecond(!guestRomsPopupsecond);
  };
  console.log("Wordlsss", guestRomsPopupsecond);
  const handleClickOutside = (event) => {
    if (ref.current && !ref.current.contains(event.target)) {
      setGuestRoomsPopup(false);
    }
    if (ref1.current && !ref1.current.contains(event.target)) {
      setGuestRoomsPopupsecond(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
    document.removeEventListener("click", handleClickOutside, true);
    };
  }, []);

  const handleHourscollect = (e) => {
    console.log("hours", e.target.value);
    setGetHours(e.target.value);
    handleClose();
  };
  useEffect(() => {
  if(offersPromotionsDestinations !=null)  { 
    setDestinationsData(offersPromotionsDestinations.destinations);
  }  
  },[offersPromotionsDestinations]);


//   setInterval(function () {
//   if(destinationsData != null ) {
//        var data = destinationsData;
//         for (var i = destinationsData.length - 1; i > 0; i--) {
//           var j = Math.floor(Math.random() * (i + 1));
//           var temp = destinationsData[i];
//           destinationsData[i] = destinationsData[j];
//           destinationsData[j] = temp;
//         }
//   setDestinationsData(destinationsData);  
//     }  
//  }, 
//   100000);
// Shauffling data
  // useEffect(() => {
  //   const interval = setInterval(() => {
  //     if(destinationsData != null ) {
  //       var data = [...destinationsData];
  //        for (var i = data.length - 1; i > 0; i--) {
  //          var j = Math.floor(Math.random() * (i + 1));
  //          var temp = data[i];
  //          data[i] = data[j];
  //          data[j] = temp;
  //        }
  //        console.log("DDDD",data);
  //  setDestinationsData(data);  
  //    }  
     
  //   }, 5000);

  //   return () => clearInterval(interval);
  // }, [destinationsData]);

  const handleIncrease = (type) => {
    console.log(type);
    if (type == "room") {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        rooms: guestRoomData.rooms + 1,
      }));
    } else if (type == "adult") {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        adults: guestRoomData.adults + 1,
      }));
    } else {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        child: guestRoomData.child + 1,
      }));
    }
  };

  const handleDecrease = (type) => {
    console.log(type);
    if (type == "room" && guestRoomData.rooms >= 1) {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        rooms: guestRoomData.rooms - 1,
      }));
    } else if (type == "adult" && guestRoomData.adults >= 1) {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        adults: guestRoomData.adults - 1,
      }));
    } else if (type == "children" && guestRoomData.child >= 1) {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        child: guestRoomData.child - 1,
      }));
    } else {
    }
  };

  const searchsubmit = (event) => {
    //    place.address_components[0].long_name
    event.preventDefault();
   // hotelWheatherApiRequest(place);
    //  console.log("get Hours",checkInOutValue.checkInTime);
    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    let day = dateObj.getUTCDate();
    let year = dateObj.getUTCFullYear();
    if (longaddress == "") {
      setPlaceSearchError("Please Enter The Place Your want to search");
      return;
    } else if (value == "") {
      setPlaceSearchError("Please Enter The Place Your want to search");
      return;
    } else {
    }

    navigate(
      {
        pathname: "listingbidnow",
        search: createSearchParams({
          search_type: "hour",
          city: value != "" ? value : "",
          book_for: getHours == 0 ? 3 : getHours,
          check_in_date:
            checkInOutValue.checkInTime == null
              ? "" + year + "-" + month + "-" + day + ""
              : moment(checkInOutValue.checkInTime.toString()).format(
                  "DD/MM/YYYY"
                ),
          adults: guestRoomData.adults,
          children: guestRoomData.child,
          rooms: guestRoomData.rooms,
        }).toString(),
      },

      {
        state: {
          search_type: "hour",
          city: value != "" ? value : "",
          book_for: getHours,
          check_in_date:
            checkInOutValue.checkInTime == null
              ? "" + year + "-" + month + "-" + day + ""
              : moment(checkInOutValue.checkInTime.toString()).format(
                  "DD/MM/YYYY"
                ),
          adults: guestRoomData.adults,
          children: guestRoomData.child,
          rooms: guestRoomData.rooms,
        },
      }
    );
  };

  const bidsearchnow = (event) => {
    event.preventDefault();
    console.log("get Hours", checkInOutValue.checkInTime);
    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    let day = dateObj.getUTCDate();
    let nextday = dateObj.getUTCDate() + 1;
    let year = dateObj.getUTCFullYear();

    var startDate = new Date(checkInOutValue.checkInTime);
    var endDate = new Date(checkInOutValue.checkOutTime);

    if (place == "") {
      setPlaceSearchError("Please Enter The Place Your want to search");

      return;
    }
    if (endDate.getTime() <= startDate.getTime()) {
      errorToast("The check out date must be bigger than the check in date");
      return;
    }

   // hotelWheatherApiRequest(place);
    navigate(
      {
        pathname: "listingbidnow",
        search: createSearchParams({
          search_type: "bid",
          city: value != "" ? value : "",
          check_in_date: `${moment(
            checkInOutValue.checkInTime != null
              ? checkInOutValue.checkInTime.toString()
              : "" + year + "-" + month + "-" + day + ""
          ).format("DD/MM/YYYY")}`,
          check_out_date: `${moment(
            checkInOutValue.checkInTime != null
              ? checkInOutValue.checkOutTime.toString()
              : "" + year + "-" + month + "-" + nextday + ""
          ).format("DD/MM/YYYY")}`,
          adults: guestRoomData.adults,
          children: guestRoomData.child,
          rooms: guestRoomData.rooms,
        }).toString(),
      },
      {
        state: {
          search_type: "bid",
          city: value != "" ? value : "",
          check_in_date: `${moment(
            checkInOutValue.checkInTime != null
              ? checkInOutValue.checkInTime.toString()
              : "" + year + "-" + month + "-" + day + ""
          ).format("DD/MM/YYYY")}`,
          check_out_date: `${moment(
            checkInOutValue.checkInTime != null
              ? checkInOutValue.checkOutTime.toString()
              : "" + year + "-" + month + "-" + nextday + ""
          ).format("DD/MM/YYYY")}`,
          adults: guestRoomData.adults,
          children: guestRoomData.child,
          rooms: guestRoomData.rooms,
        },
      }
    );
  };
 
  useEffect(() => {
  getOfferPromotionsPartnersPreferenceRequest(languageToShow);
  },[])

  useEffect(() => {
  setValue("Riyad", false)
  navigator.geolocation.getCurrentPosition(function (position) {
  console.log("position",position);
  fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${position.coords.latitude},${position.coords.longitude}&key=AIzaSyAzkHClnEq24zAa3xZBHjTTub9UhvmNC7A`)
  .then((response) => response.json())
  .then((data) => setValue((data.results[data.results.length-2].formatted_address.split(",")[0]),false))
  });
  },[]);
 

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  // console.log("hello",place.address_components[0].long_name);
  //console.log("getHours", typeof getHours, open);
  console.log("RRRRRRR",value);
  const handleChange = (newValue) => {};
  return (
    <>
      {/* Header Section */}
      {/* <header>
                <div className="container">
                    <div className="row">
                        <div className="col-md-3">
                            <div className="logo">
                                <Link to="/"><img src='./img/logo.svg' alt="" /></Link>
                            </div>
                        </div>
                        <div className="col-md-9">
                            <div className="toprightsec">
                                <ul>
                                    <li><Link to="/login"><FiLogIn /> Login</Link></li>
                                    <li><Link to="#"><BiUserCircle /> Register</Link></li>
                                    <li>
                                        <Dropdown>
                                            <Dropdown.Toggle variant="success" id="dropdown-basic">
                                                العربية <img src='./img/belowarrow.svg' alt="" />
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu>
                                                <Dropdown.Item><Link to="#">العربية</Link></Dropdown.Item>
                                                <Dropdown.Item><Link to="#">Chinese</Link></Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </li>
                                    <li>
                                        <Dropdown>
                                            <Dropdown.Toggle variant="success" id="dropdown-basic">
                                                AED <img src='./img/belowarrow.svg' alt="" />
                                            </Dropdown.Toggle>

                                            <Dropdown.Menu>
                                                <Dropdown.Item><Link to="#">AED</Link></Dropdown.Item>
                                                <Dropdown.Item><Link to="#">INR</Link></Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </li>
                                    <li>
                                        <Dropdown>
                                            <Dropdown.Toggle variant="success" id="dropdown-basic">
                                                <img src='./img/topnav.svg' alt="" />
                                            </Dropdown.Toggle>
                                        <Dropdown.Menu>
                                                <Dropdown.Item><Link to="/myaccount">My Account</Link></Dropdown.Item>
                                                <Dropdown.Item><Link to="#">Hotels </Link></Dropdown.Item>
                                                <Dropdown.Item><Link to="#">Rewards</Link></Dropdown.Item>
                                                <Dropdown.Item><Link to="#">Contact Us</Link></Dropdown.Item>
                                                <Dropdown.Item><Link to="#">Terms and Condition </Link></Dropdown.Item>
                                                <Dropdown.Item><Link to="#">Sign Out</Link> </Dropdown.Item>
                                            </Dropdown.Menu>
                                        </Dropdown>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </header> */}

      {/* banner start */}

      <div className="home-banner">
        <div className="container">
          {/* search hotel start */}
          <div className="row">
            <div className="col-lg-12">
              <div className="search-hotel">
                <Tabs defaultActiveKey="second">
                  <Tab eventKey="first" title="Hourly Stay">
                    {/* <LocalizationProvider dateAdapter={AdapterDayjs}>                        
                                       <MobileDatePicker
                                       label="Dateaaa mobile"
                                       inputFormat="MM/DD/YYYY"
                                       value={value}
                                       onChange={handleChange}
                                       renderInput={(params) => <TextField {...params} />}
                                       />
                                     </LocalizationProvider> */}
                    <div className="tab-container hourly-stay">
                      <form onSubmit={searchsubmit}>
                        <div className="form-content">
                          <div className="left">
                            <Form.Label>WHERE?</Form.Label>
                            <Form.Group className="form-box">
                              {/* <Autocomplete
                                defaultValue={place}
                                className="location form-control"
                                apiKey={process.env.REACT_APP_GoogleAPIKEY}
                                onPlaceSelected={(place) => {
                                  setPlaceSearchError();
                                  setLongaddress(place.formatted_address);
                                  setPlace(
                                    !!place.address_components
                                      ? place.address_components[0].long_name
                                      : place.name
                                  );
                                }}
                                onChange={(e) => setLongaddress(e.target.value)}
                                value={longaddress}
                              /> */}
        <Combobox onSelect={handleSelect} aria-labelledby="demo">
        <ComboboxInput
        defaultChecked={"Riyad"}
          // style={{ width: 300, maxWidth: "90%" }}
          value={value}
          onChange={handleInput}
          disabled={!ready}
          className="location form-control"
        />
        <ComboboxPopover>
          <ComboboxList>{status === "OK" && renderSuggestions()}</ComboboxList>
        </ComboboxPopover>
      </Combobox>

                            </Form.Group>
                            <Form.Group className="form-box checkin">
                              {/* <Form.Control type="text" className="check-in" placeholder="Check-in" /> */}
                              <LocalizationProvider dateAdapter={AdapterDayjs}>
                                <DatePicker
                                  className="datepickercheck-in"
                                  style={{ cursor: "pointer" }}
                                  label="Check-in"
                                  value={checkInOutValue.checkInTime}
                                  onChange={(newValue) => {
                                    setCheckInOutValue((checkInOutValue) => ({
                                      ...checkInOutValue,
                                      checkInTime: newValue,
                                    }));
                                  }}
                                  disablePast
                                  renderInput={(params) => (
                                    <TextField {...params} />
                                  )}
                                  onClose={() => setIsOpen(false)}
                                  KeyboardButtonProps={{
                                    onClick: (e) => {
                                      setIsOpen(true);
                                    },
                                  }}
                                  InputProps={{
                                    onClick: () => {
                                      setIsOpen(true);
                                    },
                                  }}
                                  o
                                  open={isOpen}
                                  inputFormat="DD MMM YYYY"
                                />
                              </LocalizationProvider>
                              <div
                                className="pophours"
                                style={
                                  open
                                    ? { display: "block" }
                                    : { display: "none" }
                                }
                              >
                                <Box sx={style}>
                                  {/* <Typography id="modal-modal-title" variant="h6" component="h2">
                                                                        Text in a modal
                                                                    </Typography> */}
                                  <Typography
                                    id="modal-modal-description"
                                    sx={{ mt: 2 }}
                                    className="hourlybook"
                                    onChange={handleHourscollect}
                                  >
                                    Book For
                                    <Form.Select aria-label="Default select example">
                                      <option>Hours</option>
                                      <option value="3">3 Hour</option>
                                      <option value="6">6 Hours</option>
                                      <option value="12">12 Hours</option>
                                    </Form.Select>
                                  </Typography>
                                </Box>
                              </div>
                              {/* <Modal className="newmodal"
                                                                open={open}
                                                                onClose={handleClose}
                                                                aria-labelledby="modal-modal-title"
                                                                aria-describedby="modal-modal-description"
                                                            >
                                                                <Box sx={style}>
                                                                    <Typography id="modal-modal-title" variant="h6" component="h2">
                                                                        Text in a modal
                                                                    </Typography>
                                                                    <Typography id="modal-modal-description" sx={{ mt: 2 }} className="hourlybook" onChange={handleHourscollect}  >
                                                                     Book For
                                                                    <Form.Select aria-label="Default select example">
                                                                            <option>Hours</option>
                                                                            <option value="3">3 Hour</option>
                                                                            <option value="6">6 Hours</option>
                                                                            <option value="12">12 Hours</option>
                                                                    </Form.Select>
                                                                    </Typography>
                                                                </Box>
                                                            </Modal>  */}
                              {getHours != null && getHours > 0 ? (
                                <span className="hourlable">
                                  {getHours} Hours
                                </span>
                              ) : null}
                            </Form.Group>
                            <Form.Group className="form-box pop-form">
                              <Form.Control
                                type="text"
                                className="room"
                                placeholder={`${
                                  guestRoomData.adults + guestRoomData.child
                                } ${
                                  guestRoomData.adults + guestRoomData.child > 1
                                    ? "Guests"
                                    : "Guest"
                                }  / ${guestRoomData.rooms} ${guestRoomData.rooms>1?"Rooms":"Room"}`}
                                onClick={guestAndRoom}
                              />
                              <div
                                className="guestpop"
                                ref={ref}
                                style={
                                  guestRomsPopup
                                    ? { display: "block" }
                                    : { display: "none" }
                                }
                              >
                                <h3>Add Guest(s) And Room(s)</h3>
                                <ul>
                                  <li key={24}>
                                    <h4>Room (s)</h4>
                                    <div className="counting">
                                      <Button
                                        type="button"
                                        onClick={() => {
                                          handleDecrease("room");
                                        }}
                                      >
                                        <AiOutlineMinusCircle />
                                      </Button>
                                      {guestRoomData.rooms}
                                      <Button
                                        type="button"
                                        onClick={() => {
                                          handleIncrease("room");
                                        }}
                                      >
                                        <BsPlusCircle />
                                      </Button>
                                    </div>
                                  </li>
                                  <li key={25}>
                                    <h4>Adult (s) </h4>
                                    <div className="counting">
                                      <Button
                                        onClick={() => {
                                          handleDecrease("adult");
                                        }}
                                      >
                                        <AiOutlineMinusCircle />
                                      </Button>
                                      {guestRoomData.adults}
                                      <Button
                                        onClick={() => {
                                          handleIncrease("adult");
                                        }}
                                      >
                                        <BsPlusCircle />
                                      </Button>
                                    </div>
                                  </li>
                                  <li key={26}>
                                    <h4>
                                      Children (s) <span>Max 11 years</span>
                                    </h4>
                                    <div className="counting">
                                      <Button
                                        onClick={() => {
                                          handleDecrease("children");
                                        }}
                                      >
                                        <AiOutlineMinusCircle />
                                      </Button>
                                      {guestRoomData.child}
                                      <Button
                                        onClick={() => {
                                          handleIncrease("children");
                                        }}
                                      >
                                        <BsPlusCircle />
                                      </Button>
                                    </div>
                                  </li>
                                </ul>
                              </div>
                              {/* <Dialog
                                                             open={true}
                                                             onClose={handleClose}
                                                             aria-labelledby="alert-dialog-title"
                                                             aria-describedby="alert-dialog-description"
                                                             PaperProps={{
                                                             sx: {
                                                             width: "30%",
                                                             height: "50%",
                                                             position: "absolute",
                                                             top: 10,
                                                             left: 10,
                                                             m: 0
                                                             }
                                                             }}
                                                             ></Dialog> */}
                            </Form.Group>
                          </div>
                          <div className="right">
                            <Button type="submit" value="submit">
                              Search hotel
                            </Button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </Tab>
                  <Tab eventKey="second" title="Bid Now">
                    <div className="tab-container bid-now">
                      <form onSubmit={bidsearchnow}>
                        <div className="form-content">
                          <div className="left">
                            <Form.Label>WHERE?</Form.Label>
                            <Form.Group className="form-box">
                              {/* <Autocomplete
                                className="location form-control"
                                apiKey={process.env.REACT_APP_GoogleAPIKEY}
                                onPlaceSelected={(place) => {
                                  setPlaceSearchError();
                                  setLongaddress(place.formatted_address);
                                  setPlace(
                                    !!place.address_components
                                      ? place.address_components[0].long_name
                                      : place.name
                                  );
                                }}
                                onChange={(e) => setLongaddress(e.target.value)}
                                value={longaddress}
                              /> */}
                                <Combobox onSelect={handleSelect} aria-labelledby="demo">
        <ComboboxInput
        defaultChecked={"Riyad"}
          // style={{ width: 300, maxWidth: "90%" }}
          value={value}
          onChange={handleInput}
          disabled={!ready}
          className="location form-control"
        />
        <ComboboxPopover>
          <ComboboxList>{status === "OK" && renderSuggestions()}</ComboboxList>
        </ComboboxPopover>
      </Combobox>    

                            </Form.Group>
                            <div className="bidchecking">
                              <Form.Group className="form-box">
                                <LocalizationProvider
                                  dateAdapter={AdapterDayjs}
                                >
                                  <DatePicker
                                    className="datepickercheck-in check-in"
                                    label="Check-in"
                                    value={checkInOutValue.checkInTime}
                                    onChange={(newValue) => {
                                      // setValue();
                                      moment(newValue).format(
                                        "YYYY-MM-DD HH:mm:ss"
                                      );
                                      setCheckInOutValue((checkInOutValue) => ({
                                        ...checkInOutValue,
                                        checkInTime: newValue,
                                      }));
                                    }}
                                    disablePast
                                    renderInput={(params) => (
                                      <TextField {...params} />
                                    )}
                                    onClose={() => setCheckIn(false)}
                                    KeyboardButtonProps={{
                                      onClick: (e) => {
                                        setCheckIn(true);
                                      },
                                    }}
                                    InputProps={{
                                      onClick: () => {
                                        setCheckIn(true);
                                      },
                                    }}
                                    open={checkIn}
                                    inputFormat="DD MMM YYYY"
                                  />
                                </LocalizationProvider>
                              </Form.Group>
                              <Form.Group className="form-box check-out">
                                <LocalizationProvider
                                  dateAdapter={AdapterDayjs}
                                >
                                  <DatePicker
                                    className="datepickercheck-in"
                                    label="Check-out"
                                    value={checkInOutValue.checkOutTime}
                                    onChange={(newValue) => {
                                      //setValue(moment(newValue).format("DD/MM/YYYY"));
                                      setCheckInOutValue((checkInOutValue) => ({
                                        ...checkInOutValue,
                                        checkOutTime: newValue,
                                      }));
                                    }}
                                    renderInput={(params) => (
                                      <TextField {...params} />
                                    )}
                                    onClose={() => setCheckoutTime(false)}
                                    KeyboardButtonProps={{
                                      onClick: (e) => {
                                        setCheckoutTime(true);
                                      },
                                    }}
                                    minDate={new Date(
                                      checkInOutValue.checkInTime
                                    ).setDate(
                                      new Date(
                                        checkInOutValue.checkInTime
                                      ).getDate() + 1
                                    )}
                                    disablePast
                                    InputProps={{
                                      onClick: () => {
                                        setCheckoutTime(true);
                                      },
                                    }}
                                    open={checkoutTime}
                                    inputFormat="DD MMM YYYY"
                                  />
                                </LocalizationProvider>
                              </Form.Group>
                            </div>
                            <Form.Group className="form-box pop-form">
                              <Form.Control
                                type="text"
                                className="room"
                                placeholder={`${
                                  guestRoomData.adults + guestRoomData.child
                                } ${
                                  guestRoomData.adults + guestRoomData.child > 1
                                    ? "Guests"
                                    : "Guest"
                                } / ${guestRoomData.rooms} ${guestRoomData.rooms>1?"Rooms":"Room"}`}
                                onClick={guestAndRoomsecond}
                              />
                              <div
                                className="guestpop"
                                ref={ref1}
                                style={
                                  guestRomsPopupsecond
                                    ? { display: "block" }
                                    : { display: "none" }
                                }
                              >
                                <h3>Add Guest(s) And Room(s)</h3>
                                <ul>
                                  <li>
                                    <h4>Room (s)</h4>
                                    <div className="counting">
                                      <div>
                                        <Button
                                          onClick={() => {
                                            handleDecrease("room");
                                          }}
                                        >
                                          <AiOutlineMinusCircle />
                                        </Button>
                                      </div>
                                      {guestRoomData.rooms}
                                      <div>
                                        <Button
                                          onClick={() => {
                                            handleIncrease("room");
                                          }}
                                        >
                                          <BsPlusCircle />
                                        </Button>
                                      </div>
                                    </div>
                                  </li>
                                  <li>
                                    <h4>Adult (s) </h4>
                                    <div className="counting">
                                      <Button
                                        onClick={() => {
                                          handleDecrease("adult");
                                        }}
                                      >
                                        <AiOutlineMinusCircle />
                                      </Button>
                                      {guestRoomData.adults}
                                      <Button
                                        onClick={() => {
                                          handleIncrease("adult");
                                        }}
                                      >
                                        <BsPlusCircle />
                                      </Button>
                                    </div>
                                  </li>
                                  <li>
                                    <h4>
                                      Children (s) <span>Max 11 years</span>
                                    </h4>
                                    <div className="counting">
                                      <Button
                                        onClick={() => {
                                          handleDecrease("children");
                                        }}
                                      >
                                        <AiOutlineMinusCircle />
                                      </Button>
                                      {guestRoomData.child}
                                      <Button
                                        onClick={() => {
                                          handleIncrease("children");
                                        }}
                                      >
                                        <BsPlusCircle />
                                      </Button>
                                    </div>
                                  </li>
                                </ul>
                              </div>
                            </Form.Group>
                          </div>
                          <div className="right">
                            <button type="submit" value="submit">
                              Search hotel
                            </button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </Tab>
                </Tabs>
                <div className="errorformmessage errormessagesearch">
                  {placeSearchError}
                </div>
              </div>
            </div>
          </div>
          {/* search hotel start */}

          {/* banner item start */}
          <div className="row">
            <div className="col-lg-12">
              <ul className="banner-item-list">
                <li>
                  <span className="icon">
                    <img src="img/icon-stay.svg" alt="Flexible Stay" />
                  </span>
                  <span className="title">Flexible Stay</span>
                  <p>
                    feel free to choose your own<br></br>check-in, check-out
                    time
                  </p>
                </li>

                <li>
                  <span className="icon">
                    <img src="img/icon-hotels.svg" alt="Best Hotels" />
                  </span>
                  <span className="title">Best Hotels</span>
                  <p>
                    Check-in & Check-out of our<br></br>hotels at your
                    convenience
                  </p>
                </li>

                <li>
                  <span className="icon">
                    <img
                      src="img/icon-price-discount.svg"
                      alt="Up to -75% off"
                    />
                  </span>
                  <span className="title">Up to -75% off</span>
                  <p>
                    get discounts for your stay<br></br>your stay, our discounts
                  </p>
                </li>

                <li>
                  <span className="icon">
                    <img
                      src="img/icon-bid-price.svg"
                      alt="Bid your Own Price"
                    />
                  </span>
                  <span className="title">Bid your Own Price</span>
                  <p>
                    Bid a price and win best<br></br>rates to stay with us.
                  </p>
                </li>
              </ul>
            </div>
          </div>
          {/* banner item end */}
        </div>
      </div>

      {/* banner end */}

      {/* //////////offer and promotions carousel/////////// */}
      <div className="carousel_st ofer_mwrp">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h2>Offers and Promotions</h2>
                 <Slider {...offerPromotion}> 
                { offersPromotionsDestinations != null ?
                 offersPromotionsDestinations.offers.length > 0 ? 
                 offersPromotionsDestinations.offers.map((offers) => {
                return ( 
                <div className="inner_mbox">
                  <div className="inner_offerbox">
                    <img src="./img/offer_pmom_img1.png" alt="" />
                    <h4 dangerouslySetInnerHTML={{__html: offers.rules}} />
                  </div>
                </div>
                )
                }) : "Loading" 
                : <div className="inner_mbox">
                  <div className="inner_offerbox">
                    
                    <h4>Loading</h4>
                  </div>
                </div>
                }
              </Slider>
               
            
            </div>
          </div>
        </div>
      </div>

      {/* //////////partner carousel/////////// */}
      <div className="carousel_st partner_mwrp">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h2>Our Partners</h2>
              <Slider {...partner}>
              { offersPromotionsDestinations != null ?
                 offersPromotionsDestinations.partners.length > 0 ? 
                 offersPromotionsDestinations.partners.map((partners) => {
                return ( 
                <div className="partner_innerbox_mwrp">
                  <div className="partner_innerbox">
                    <img src={partners.image} alt="" />
                  </div>
                </div>
                )  }) : "Loading" 
                : <div className="inner_mbox">
                  <div className="inner_offerbox">
                    
                    <h4>Loading</h4>
                  </div>
                </div>
                }
                <div className="partner_innerbox_mwrp">
                  <div className="partner_innerbox">
                    <img src="./img/partner_img1.png" alt="" />
                  </div>
                </div>
                <div className="partner_innerbox_mwrp">
                  <div className="partner_innerbox">
                    <img src="./img/partner_img2.png" alt="" />
                  </div>
                </div>
                <div className="partner_innerbox_mwrp">
                  <div className="partner_innerbox">
                    <img src="./img/partner_img3.png" alt="" />
                  </div>
                </div>
                <div className="partner_innerbox_mwrp">
                  <div className="partner_innerbox">
                    <img src="./img/partner_img4.png" alt="" />
                  </div>
                </div>
                <div className="partner_innerbox_mwrp">
                  <div className="partner_innerbox">
                    <img src="./img/partner_img5.png" alt="" />
                  </div>
                </div>
                <div className="partner_innerbox_mwrp">
                  <div className="partner_innerbox">
                    <img src="./img/partner_img1.png" alt="" />
                  </div>
                </div>
              </Slider>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Preference carousel/////////// */}
      <div className="preference_mwrap carousel_st">
        <div className="container">
          <div className="row">
            <div className="col-sm-12">
              <h2>Select your preference</h2>
              <Slider {...preference}>
            { offersPromotionsDestinations != null ?
                 offersPromotionsDestinations.preferences.length > 0 ? 
                 offersPromotionsDestinations.preferences.map((preferences) => {
                return ( 
                       <div className="pref_innerbox">
                  <div className="pref_imgbox">
                    <img  style={{cursor:"pointer"}}    onClick={() => {
                        getPerferenceDataList(preferences._id.toString());
                        populartoleasting(value.toString() != '' ? value.toString() : "Riyad");
                      }}  src={preferences.image} alt="" />
                  </div>
                  <h5>{preferences.name}</h5>
                </div>
                )  }) : "Loading" 
                : <div className="inner_mbox">
                  <div className="inner_offerbox">
                    
                    <h4>Loading</h4>
                  </div>
                </div>
                }
                <div className="pref_innerbox">
                  <div className="pref_imgbox">
                    <img src="./img/prefrnce_img1.png" alt="" />
                  </div>
                  <h5>Day Room</h5>
                </div>
                <div className="pref_innerbox">
                  <div className="pref_imgbox">
                    <img src="./img/prefrnce_img2.png" alt="" />
                  </div>
                  <h5>Workplace </h5>
                </div>
                <div className="pref_innerbox">
                  <div className="pref_imgbox">
                    <img src="./img/prefrnce_img3.png" alt="" />
                  </div>
                  <h5>Meeting Room</h5>
                </div>
                <div className="pref_innerbox">
                  <div className="pref_imgbox">
                    <img src="./img/prefrnce_img4.png" alt="" />
                  </div>
                  <h5>Pool and Spa</h5>
                </div>
                <div className="pref_innerbox">
                  <div className="pref_imgbox">
                    <img src="./img/prefrnce_img5.png" alt="" />
                  </div>
                  <h5>Breveges</h5>
                </div>
                <div className="pref_innerbox">
                  <div className="pref_imgbox">
                    <img src="./img/prefrnce_img1.png" alt="" />
                  </div>
                  <h5>Day Room</h5>
                </div>
              </Slider>
            </div>
          </div>
        </div>
      </div>

      {/* popular destinations start */}
      <div className="popular-destinations">
        <div className="container">
          <div className="row popular-destinations-header">
            <div className="col-md-7">
              <h2>Popular Destinations</h2>
            </div>
            <div className="col-md-5">
              {/* <Link to="#" className="gen-btn">
                view more cities
              </Link> */}
            </div>
          </div>
          <div className="row">
            <div className="col-lg-12">
              <ul className="destinations-list">
                 { destinationsData != null ?
                 destinationsData.length > 0 ? 
                 destinationsData.map((destinations) => {
                return ( 
                      <li>
                  <div className="destinations-box">
                    <img
                      onClick={() => {
                        populartoleasting(destinations.city_name.toString());
                      }}
                      style={{ cursor: "pointer" }}
                      src={destinations.image}
                      alt="popular destinations"
                    />
                    <div className="caption">
                      <div className="title">{destinations.city_name}</div>
                      <div className="price">Starting at $67...</div>
                    </div>
                  </div>
                </li>
                
                )  }) : "Loading" 
                : <div className="inner_mbox">
                  <div className="inner_offerbox">
                    
                    <h4>Loading</h4>
                  </div>
                </div>
                }

                {/* <li>
                  <div className="destinations-box">
                    <img
                      onClick={() => {
                        populartoleasting("Riyadh");
                      }}
                      style={{ cursor: "pointer" }}
                      src="img/popular-destinations-1.jpg"
                      alt="popular destinations"
                    />
                    <div className="caption">
                      <div className="title">RiyadhRiyadh</div>
                      <div className="price">Starting at $67...</div>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="destinations-box">
                    <img
                      onClick={() => {
                        populartoleasting("Kuwait");
                      }}
                      style={{ cursor: "pointer" }}
                      src="img/popular-destinations-2.jpg"
                      alt="popular destinations"
                    />
                    <div className="caption">
                      <div className="title">Kuwait</div>
                      <div className="price">Starting at $67...</div>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="destinations-box">
                    <img
                      onClick={() => {
                        populartoleasting("United Arab Emirates");
                      }}
                      style={{ cursor: "pointer" }}
                      src="img/popular-destinations-3.jpg"
                      alt="popular destinations"
                    />
                    <div className="caption">
                      <div className="title">United Arab Emirates</div>
                      <div className="price">Starting at $67...</div>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="destinations-box">
                    <img
                      onClick={() => {
                        populartoleasting("Doha");
                      }}
                      style={{ cursor: "pointer" }}
                      src="img/popular-destinations-4.jpg"
                      alt="popular destinations"
                    />
                    <div className="caption">
                      <div className="title">Doha</div>
                      <div className="price">Starting at $67...</div>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="destinations-box">
                    <img
                      onClick={() => {
                        populartoleasting("Abu Dhabi");
                      }}
                      style={{ cursor: "pointer" }}
                      src="img/popular-destinations-5.jpg"
                      alt="popular destinations"
                    />
                    <div className="caption">
                      <div className="title">Abu Dhabi</div>
                      <div className="price">Starting at $67...</div>
                    </div>
                  </div>
                </li>
                <li>
                  <div className="destinations-box">
                    <img
                      onClick={() => {
                        populartoleasting("Dubai");
                      }}
                      style={{ cursor: "pointer" }}
                      src="img/popular-destinations-6.jpg"
                      alt="popular destinations"
                    />
                    <div className="caption">
                      <div className="title">Dubai</div>
                      <div className="price">Starting at $67...</div>
                    </div>
                  </div>
                </li> */}
              </ul>
            </div>

          </div>
        </div>
      </div>
      {/* popular destinations end */}

      {/* app wrapper start */}
      <div className="app-wrapper">
        <div className="container">
          <div className="row">
            <div className="col-lg-5 app-pic">
              <img src="img/app-screen.png" alt="app-screen" />
            </div>
            <div className="col-lg-7 app-txt">
              <h2>An App To Fill Your Needs</h2>
              <p>
                Get our iOS or Android App to get aseamless experience on hourly
                hotel booking.
              </p>
              <ul className="app-icon">
                <li>
                  <img src="img/apple-store.png" alt="apple-store" />
                </li>
                <li>
                  <img src="img/google-play.png" alt="google-play" />
                </li>
                <li>
                  <img src="img/barcode.png" alt="barcode" />
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* app wrapper end */}

      {/* What Our Guests Say */}
      <div className="guests-review">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <div className="reviewcontent">
                <h2>What Our Guests Say</h2>
                <div className="totalstararea">
                  <div className="reviewstar">
                    <img src="./img/star.svg" alt="" />
                    <img src="./img/star.svg" alt="" />
                    <img src="./img/star.svg" alt="" />
                    <img src="./img/star.svg" alt="" />
                    <img src="./img/star2.svg" alt="" />
                  </div>
                  <p>Out of thousands of reviews</p>
                  <Link to="#" className="gen-btn">
                    See all Reviews
                  </Link>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div data-aos="fade-left"
    data-aos-offset="9"
    data-aos-delay="20"
    data-aos-duration="500"
    data-aos-easing="ease-in-out"
    data-aos-mirror="true"
    data-aos-once="false"
    data-aos-anchor-placement="top-center" className="reviewbox maincolor">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.{" "}
                </p>
                <div className="reviewstar">
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                </div>
                <div className="authorname">Abdullah</div>
              </div>
              <div data-aos="fade-up"
    data-aos-offset="9"
    data-aos-delay="20"
    data-aos-duration="500"
    data-aos-easing="ease-in-out"
    data-aos-mirror="true"
    data-aos-once="false"
    data-aos-anchor-placement="top-center" className="reviewbox bluecolor">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book.
                </p>
                <div className="reviewstar">
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                </div>
                <div className="authorname">Abdullah</div>
              </div>
            </div>
            <div className="col-md-4">
              <div data-aos="fade-right"
     data-aos-offset="300"
     data-aos-easing="ease-in-sine"  className="reviewbox bluecolor">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s.
                </p>
                <div className="reviewstar">
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                </div>
                <div className="authorname">Abdullah</div>
              </div>

              <div data-aos="slide-right"
     data-aos-offset="300"
     data-aos-easing="ease-in-sine" className="reviewbox maincolor">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text.
                </p>
                <div className="reviewstar">
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                </div>
                <div className="authorname">Abdullah</div>
              </div>

              <div data-aos="fade-left"
     data-aos-offset="300"
     data-aos-easing="ease-in-sine" className="reviewbox bluecolor">
                <p>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </p>
                <div className="reviewstar">
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                  <img src="./img/star.svg" alt="" />
                </div>
                <div className="authorname">Abdullah</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Get Special Section/////////// */}
      <div className="container">
        <div className="row">
          <div className="col-sm-12">
            <div className="getspecial">
              <h3>
                <span>Let’s Explore the World</span>
                Get Special Offers in Your Inbox
              </h3>
              <Form>
                <Form.Group
                  className="getspecial-form"
                  controlId="exampleForm.ControlInput1"
                >
                  <Form.Control type="email" placeholder="Submit your email" />
                  <Button className="planeicon">
                    <img src="./img/plane.svg" alt="" />
                  </Button>
                </Form.Group>
              </Form>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Footer Section/////////// */}

      {/* <footer>
                <div className="container">
                    <div className="row">
                        <div className="col-md-4">
                            <img src='./img/logo-white.svg' alt="" className="footerlogo" />
                            <ul className="footlocation">
                                <li><img src='./img/location.svg' alt="" />  123 address st. </li>
                                <li><img src='./img/call-calling.svg' alt="" />  <Link to="#">+971-589706050</Link> </li>
                                <li><img src='./img/send-2.svg' alt="" />  <Link to="mailto:wfrlee.com@gmail.com">wfrlee.com@gmail.com</Link>  </li>
                            </ul>
                        </div>
                        <div className="col-md-4">
                            <div className="footerpadding">
                                <h3>Company</h3>
                                <ul>
                                    <li><Link to="/"> Home</Link></li>
                                    <li><Link to="#">Register</Link></li>
                                    <li><Link to="/aboutus">About us</Link></li>
                                    <li><Link to="#">Careers</Link></li>
                                    <li><Link to="#">Contact us</Link></li>
                                </ul>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="footerpadding">
                                <h3>Other Links</h3>
                                <ul>
                                    <li><Link to="#">Safety and Security</Link></li>
                                    <li><Link to="#">Terms & Conditions</Link></li>
                                    <li><Link to="#">Privacy Policy</Link></li>
                                    <li><Link to="#">Referral Page</Link></li>
                                    <li><Link to="#">Partner with wfrlee.com</Link></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="whiteborder"></div>
                <div className="container">
                    <div className="row">
                        <div className="col-md-6">
                            <div className="footer-socialarea">
                                <Link to="#"><GrFacebookOption /></Link>
                                <Link to="#"><GrTwitter /></Link>
                                <Link to="#"><GrLinkedinOption /></Link>
                                <Link to="#"><GrInstagram /></Link>
                                <Link to="#"><GrYoutube /></Link>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className="copyright">Copyright @ Techit LLC. All Rights Reserved</div>
                        </div>
                    </div>
                </div>
            </footer> */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
languageToShow: selectlanguageToShow,
offersPromotionsDestinations:selectofferspromotionsdestinationData,
selectofferLoading:selectofferLoading
});
const mapDispatchToProps = (dispatch) => ({
getOfferPromotionsPartnersPreferenceRequest: (data) => dispatch(getOfferPromotionsPartnersPreferenceRequest(data)),
getPerferenceDataList: (data) => dispatch(getPerferenceDataList(data))
});
export default connect(mapStateToProps, mapDispatchToProps)(HomePage);

//https://www.npmjs.com/package/use-places-autocomplete
// console.log(
//   navigator.geolocation.getCurrentPosition(function (position) {
//     console.log(position);
//   })
// );