import React, { useState ,  useEffect } from "react";
import {
  Button,
  Dropdown,
  Form,
  Tabs,
  Tab,
  Pagination,
  Modal,
} from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { createStructuredSelector } from "reselect";
import { connect } from "react-redux";
import { selectLanguage } from "./../../redux/language/language.actions";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { getFullHotelDetailsRequest, placeStateDataSave, hotelRouteDetailsStateHandler } from "./../../redux/hotels/hotel.actions";
import { selectHotelData, selectHotelBidNowPageRouteData, selectHotelDetailsPageRouteData  } from "./../../redux/hotels/hotel.selectors";
import { selectUserLoginData } from "../../redux/user/user.selectors";
import { useParams } from "react-router-dom";
import axios from "axios";
import hotelService from "../../services/hotel.service";
import HotelListingDetails from "../../components/Hotels/HotelListingDetails";
import {
  useSearchParams,
  createSearchParams,
  useLocation,
} from "react-router-dom";
const ListingdetailsPage = ({
  getFullHotelDetailsRequest,
  selectLanguage,
  languageToShow,
  selectHotelData,
  userAuthData,
  placeStateDataSave,
  hotelRouteDetailsStateHandler,
  selectHotelDetailsPageRouteData,
  selectHotelBidNowPageRouteData
}) => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const data = {
    hotel_slug: slug,
    languageToShow: languageToShow,
    token: userAuthData != null ? userAuthData.token : "",
  };
  React.useEffect(() => {
    console.log("searchParams", searchParams);
    if (searchParams.get("search_type") == "bid") {
      const searchedParams = {
        search_type: searchParams.get("search_type"),
        city: searchParams?.get("city"),
        check_in_date: searchParams.get("check_in_date"),
        check_out_date: searchParams.get("check_out_date"),
        adults: searchParams.get("adults"),
        children: searchParams.get("children"),
        rooms: searchParams.get("rooms"),
      };

      const fullHotelDetailsParam = {
        hotel_slug: slug,
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        searchedParams: searchedParams,
      };
      getFullHotelDetailsRequest(fullHotelDetailsParam);
    }

    if (searchParams.get("search_type") == "hour") {
      const searchedParams = {
        search_type: searchParams.get("search_type"),
        book_for: searchParams?.get("book_for"),
        city: searchParams?.get("city"),
        check_in_date: searchParams.get("check_in_date"),
        adults: searchParams.get("adults"),
        children: searchParams.get("children"),
        rooms: searchParams.get("rooms"),
      };
      const fullHotelDetailsParam = {
        hotel_slug: slug,
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        searchedParams: searchedParams,
      };

      getFullHotelDetailsRequest(fullHotelDetailsParam);
      placeStateDataSave(searchParams.get("city"));
    }
    console.log("city ",searchParams.get("city"))
    window.scroll(0, 0);
  }, [languageToShow]);

  useEffect(() => {
  return () => {
  hotelRouteDetailsStateHandler("BiddingDetails")    
  };
  }, []);
  
  

  
  // React.useEffect(() => {

  //   getFullHotelDetailsRequest(data);

  // }, [languageToShow]);

  // window.onpopstate = () => {
  //   const searchData = {
  //     search_type: searchParams != null ? searchParams?.get("search_type") : "",
  //     hour: searchParams != null ? searchParams?.get("hour") : "",
  //     city: searchParams != null ? searchParams?.get("city") : "",
  //     check_in_date:
  //       searchParams != null ? searchParams?.get("check_in_date") : "",
  //     check_out_date:
  //       searchParams != null ? searchParams?.get("check_out_date") : "",
  //     adults: searchParams != null ? searchParams?.get("adults") : "",
  //     children: searchParams != null ? searchParams?.get("children") : "",
  //     rooms: searchParams != null ? searchParams?.get("rooms") : "",
  //   };
  //   navigate({
  //     pathname: "/listingbidnow",
  //     search: createSearchParams(searchData).toString(),
  //   });
  //   console.log("DDDDDDD");
  // };
  return <HotelListingDetails hotel_slug={slug} />;
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  selectHotelData: selectHotelData,
  userAuthData: selectUserLoginData,
  selectHotelBidNowPageRouteData:selectHotelBidNowPageRouteData,
  selectHotelDetailsPageRouteData:selectHotelDetailsPageRouteData
});
const mapDispatchToProps = (dispatch) => ({
  getFullHotelDetailsRequest: (data) => dispatch(getFullHotelDetailsRequest(data)),
  selectLanguage: (data) => dispatch(selectLanguage(data)),
  placeStateDataSave: (data) => dispatch(placeStateDataSave(data)),
  hotelRouteDetailsStateHandler:(data) => dispatch(hotelRouteDetailsStateHandler(data))
  
});

export default connect(mapStateToProps, mapDispatchToProps)(ListingdetailsPage);
