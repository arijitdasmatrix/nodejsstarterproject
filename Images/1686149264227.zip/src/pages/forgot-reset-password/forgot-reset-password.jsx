import React from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { AiOutlineEyeInvisible } from "react-icons/ai";
import { AiOutlineEye } from "react-icons/ai";
import ResetPasswordAfterForgot from "./../../components/reset-password-forgot/reset-password-forgot"
import SocialLogin from "../../components/SocialLogin/SocialLogin";
import { useSelector } from "react-redux";
import profilePic from "../../assets/images/ProfilePic.png";
import Footer from "../../components/Layouts/Footer/Footer";
import { createStructuredSelector } from "reselect";
import { selectSocialLoginUser } from "./../../redux/user/user.selectors";
import { connect } from "react-redux";


const ForgotPasswordPage = ({userData}) => {
  const stateData = useSelector((state) => state.userReducer);

  return (
    <>
      {/* Header Section sssss*/}
    
  <>{console.log('userData',userData)}</>
      {/* //////////loginSection/////////// */}
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="logtotal customform">
                
                  <ResetPasswordAfterForgot />
                  <p className="text-center">
           
                  </p>
               

           
            </div>
          </div>
        </div>
      </div>

      {/* //////////Footer Section/////////// */}
      {/* <Footer /> */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  userData: selectSocialLoginUser,
});

export default connect(mapStateToProps)(ForgotPasswordPage);
