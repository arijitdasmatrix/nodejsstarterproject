import React, { useState } from "react";
import { Button, Form } from "react-bootstrap";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import validator from "validator";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { selectcurrencyToShow } from "./../../redux/currency/currency.selectors";
import {
  selectUserLoginData,
  // selectSaveGuestUserCheckoutData,
  selectValidateUserEmailData,
} from "./../../redux/user/user.selectors";
import {
  selectHourlyCheckoutDetails,
  selectHotelBooking,
  selectApplyHotelOffers,
  selectFavouriteHotelSearchData,
  selectSaveGuestUserCheckoutData,
  selectApplyHotelOffersFailedData,
} from "../../redux/hotels/hotel.selectors";
import {
  getHourlyCheckoutDetailsRequest,
  hotelBookingRequest,
  applyHotelOffersRequest,
  stateClearAfterTask,
  saveGuestUserCheckoutDataRequest,
  hotelWheatherApiRequest,
} from "../../redux/hotels/hotel.actions";
import moment from "moment";
import { errorToast } from "../../utils/toastHelper";
import {
  validateUserEmailRequest,
  validateEmailStateClearAfterTask,
} from "../../redux/user/user.actions";
import { Link } from "react-router-dom";
import {
  useSearchParams,
  useLocation,
  useNavigate,
  createSearchParams,
} from "react-router-dom";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import CheckoutUserForm from "../../components/checkout/CheckoutUserForm";
import CheckoutCardDetailsForm from "../../components/checkout/CheckoutCardDetailsForm";
import CheckoutHotelDetails from "../../components/checkout/CheckoutHotelDetails";
import {
  TimeFormatValidator,
  CardNumberFormatValidator,
  CardExpiryFormatValidator,
  NumberValidator,
  MobileNumberValidator,
  EmailValidator,
} from "../../constants/InputValidator";
import ConfirmDialog from "../../components/common/confirmation/ConfirmDialog";
import BookingDetailsDialog from "../../components/checkout/BookingDetailsDialog";
import LoginModal from "../../components/checkout/LoginModal";
import LoginPage from "../../pages/Login/Login";

const HourlyGuestUser = ({
  hourlyCheckoutDetails,
  getHourlyCheckoutDetailsRequest,
  hotelBookingRequest,
  hotelBooking,
  applyHotelOffersRequest,
  applyHotelOffers,
  languageToShow,
  userAuthData,
  stateClearAfterTask,
  saveGuestUserCheckoutDataRequest,
  saveGuestUserCheckoutData,
  currencyToShow,
  searchsavedData,
  applyHotelOffersFailedData,
  hotelWheatherApiRequest,
  validateUserEmailRequest,
  validateEmailStateClearAfterTask,
  validateUserEmail,
}) => {
  const location = useLocation();
  // const { bidCheckoutParams } = stateParams.state;
  let {
    search_type,
    hotel_id,
    room_type_id,
    check_in_date,
    check_out_date,
    // check_in_time,
    // check_out_time,
    adults,
    rooms,
    children,
    slot_id,
    book_for,
    city,
  } = location.state;

  const navigate = useNavigate();
  var [showLoginPopup, setShowLoginPopup] = useState(false);
  const [paymentModeValue, setPaymentModeValue] = React.useState("cash");
  const [walletBal, setWalletBal] = React.useState("");
  const [walletBalErr, setWalletBalErr] = React.useState("");
  const [promoCode, setPromoCode] = React.useState("");
  const [promoCodeErr, setPromoCodeErr] = React.useState("");
  const [selectedCheckInTime, setSelectedCheckInTime] = React.useState("");
  // const [selectedCardType, setSelectedCardType] = React.useState("");
  // const [selectedCardTypeErr, setSelectedCardTypeErr] = React.useState("");

  const [disabledBtn, setDisabledBtn] = React.useState(true);

  const [userData, setUserData] = React.useState({
    firstname:
      hourlyCheckoutDetails?.data?.user_details?.first_name != null
        ? hourlyCheckoutDetails?.data?.user_details?.first_name
        : "",
    lastname:
      hourlyCheckoutDetails?.data?.user_details?.last_name != null
        ? hourlyCheckoutDetails?.data?.user_details?.last_name
        : "",
    email:
      hourlyCheckoutDetails?.data?.user_details?.email != null
        ? hourlyCheckoutDetails?.data?.user_details?.email
        : "",
    confirmEmail:
      hourlyCheckoutDetails?.data?.user_details?.email != null
        ? hourlyCheckoutDetails?.data?.user_details?.email
        : "",
    mobileNo:
      hourlyCheckoutDetails?.data?.user_details?.contact_n != null
        ? hourlyCheckoutDetails?.data?.user_details?.contact_no
        : "",
    // countryCode:
    //   hourlyCheckoutDetails != null ?
    //   hourlyCheckoutDetails?.data.user_details?.country_code:"",
    expecedTimeArrival: "",
  });

  const [userDataError, setuserDataError] = React.useState({
    firstnameErr: "",
    emailErr: "",
    confirmEmailErr: "",
    mobileNoErr: "",
    expecedTimeArrivalErr: "",
  });

  const [cardData, setCardData] = React.useState({
    cardnumber:
      saveGuestUserCheckoutData?.card_details?.cardnumber != null
        ? saveGuestUserCheckoutData?.card_details?.cardnumber
        : "",
    nameoncard:
      saveGuestUserCheckoutData?.card_details?.nameoncard != null
        ? saveGuestUserCheckoutData?.card_details?.nameoncard
        : "",
    expirydate:
      saveGuestUserCheckoutData?.card_details?.expirydate != null
        ? saveGuestUserCheckoutData?.card_details?.expirydate
        : "",
    securitycode:
      saveGuestUserCheckoutData?.card_details?.securitycode != null
        ? saveGuestUserCheckoutData?.card_details?.securitycode
        : "",
    selectedCardType:
      saveGuestUserCheckoutData?.card_details?.selectedCardType != null
        ? saveGuestUserCheckoutData?.card_details?.selectedCardType
        : "",
    zipcode:
      saveGuestUserCheckoutData?.card_details?.zipcode != null
        ? saveGuestUserCheckoutData?.card_details?.zipcode
        : "",
    termsandConditions:
      saveGuestUserCheckoutData?.card_details?.termsandConditions != null
        ? saveGuestUserCheckoutData?.card_details?.termsandConditions
        : false,
  });

  const [cardDataError, setCardDataError] = React.useState({
    cardnumberErr: "",
    nameoncardErr: "",
    expirydateErr: "",
    securitycodeErr: "",
    selectedCardTypeErr: "",
    zipcodeErr: "",
    termsandConditionsErr: "",
  });

  const [countryCode, setCountryCode] = React.useState(
    hourlyCheckoutDetails?.data?.user_details?.country_code != null
      ? hourlyCheckoutDetails?.data?.user_details?.country_code
      : ""
  );
  const [countryCodeErr, setCountryCodeErr] = React.useState("");
  const firstnameRef = React.useRef();
  const emailRef = React.useRef();
  const confirmEmailRef = React.useRef();
  const mobileNoRef = React.useRef();
  const countryCodeRef = React.useRef();
  const expectedTimeArrRef = React.useRef();
  const cardnumberRef = React.useRef();
  const nameoncardRef = React.useRef();
  const expirydateRef = React.useRef();
  const securitycodeRef = React.useRef();
  const selectedCardTypeRef = React.useRef();
  const zipcodeRef = React.useRef();
  const [expDate, setExpDate] = React.useState();

  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showBookingDetailsModal, setShowBookingDetailsModal] = useState(false);

  var collecSlider = {
    arrows: true,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  /*** Set Default User Details  ***/
  React.useEffect(() => {
    setUserData(
      hourlyCheckoutDetails != null
        ? {
            firstname:
              hourlyCheckoutDetails?.data?.user_details?.first_name != null
                ? hourlyCheckoutDetails?.data?.user_details?.first_name
                : "",
            lastname:
              hourlyCheckoutDetails?.data?.user_details?.last_name != null
                ? hourlyCheckoutDetails?.data?.user_details?.last_name
                : "",
            email:
              hourlyCheckoutDetails?.data?.user_details?.email != null
                ? hourlyCheckoutDetails?.data?.user_details?.email
                : "",
            confirmEmail:
              hourlyCheckoutDetails?.data?.user_details?.email != null
                ? hourlyCheckoutDetails?.data?.user_details?.email
                : "",
            mobileNo:
              hourlyCheckoutDetails?.data?.user_details?.contact_no != null
                ? hourlyCheckoutDetails?.data?.user_details?.contact_no
                : "",
            expecedTimeArrival: "",
          }
        : {
            firstname: "",
            lastname: "",
            email: "",
            confirmEmail: "",
            mobileNo: "",
            expecedTimeArrival: "",
          }
    );
    setCountryCode(
      hourlyCheckoutDetails != null
        ? hourlyCheckoutDetails?.data?.user_details?.country_code != null
          ? hourlyCheckoutDetails?.data?.user_details?.country_code
          : ""
        : ""
    );
    // cleanup function which will be invoked on component unmount
    return () => {
      setUserData({
        firstname: hourlyCheckoutDetails?.data?.user_details?.first_name,
        lastname: hourlyCheckoutDetails?.data?.user_details?.last_name,
        email: hourlyCheckoutDetails?.data?.user_details?.email,
        confirmEmail: hourlyCheckoutDetails?.data?.user_details?.email,
        mobileNo: hourlyCheckoutDetails?.data?.user_details?.contact_no,
        expecedTimeArrival: "",
      });
      setCountryCode(hourlyCheckoutDetails?.data?.user_details?.country_code);
    };
  }, [hourlyCheckoutDetails]);

  /***** Set default Card details for guest user login ** */
  React.useEffect(() => {
    setCardData(
      saveGuestUserCheckoutData != null
        ? {
            cardnumber:
              saveGuestUserCheckoutData?.card_details?.cardnumber != null
                ? saveGuestUserCheckoutData?.card_details?.cardnumber
                : "",
            nameoncard:
              saveGuestUserCheckoutData?.card_details?.nameoncard != null
                ? saveGuestUserCheckoutData?.card_details?.nameoncard
                : "",
            expirydate:
              saveGuestUserCheckoutData?.card_details?.expirydate != null
                ? saveGuestUserCheckoutData?.card_details?.expirydate
                : "",
            securitycode:
              saveGuestUserCheckoutData?.card_details?.securitycode != null
                ? saveGuestUserCheckoutData?.card_details?.securitycode
                : "",
            selectedCardType:
              saveGuestUserCheckoutData?.card_details?.selectedCardType != null
                ? saveGuestUserCheckoutData?.card_details?.selectedCardType
                : "",
            zipcode:
              saveGuestUserCheckoutData?.card_details?.zipcode != null
                ? saveGuestUserCheckoutData?.card_details?.zipcode
                : "",
            termsandConditions:
              saveGuestUserCheckoutData?.card_details?.termsandConditions !=
              null
                ? saveGuestUserCheckoutData?.card_details?.termsandConditions
                : false,
          }
        : {
            cardnumber: "",
            nameoncard: "",
            expirydate: "",
            securitycode: "",
            selectedCardType: "",
            zipcode: "",
            termsandConditions: false,
          }
    );

    // cleanup function which will be invoked on component unmount
    return () => {
      setCardData({
        cardnumber: saveGuestUserCheckoutData?.card_details?.cardnumber,
        nameoncard: saveGuestUserCheckoutData?.card_details?.nameoncard,
        expirydate: saveGuestUserCheckoutData?.card_details?.expirydate,
        securitycode: saveGuestUserCheckoutData?.card_details?.securitycode,
        selectedCardType:
          saveGuestUserCheckoutData?.card_details?.selectedCardType,
        zipcode: saveGuestUserCheckoutData?.card_details?.zipcode,
        termsandConditions:
          saveGuestUserCheckoutData?.card_details?.termsandCondition,
      });
    };
  }, []);

  /*** Fetching Checkout Details Hourly Wise   ***/
  React.useEffect(() => {
    const postData = {
      hotel_id: hotel_id,
      room_type_id: room_type_id,
      slot_id: slot_id,
      check_in_date: check_in_date,
      adults: adults,
      children: children,
      no_of_rooms: rooms,
    };

    const data = {
      postData,
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };
    getHourlyCheckoutDetailsRequest(data);
    window.scrollTo(0, 0);
  }, [languageToShow]);

  /*** Fetching Checkout Guest User details   ***/
  React.useEffect(() => {
    const data = {
      // booking_details:
      //   hourlyCheckoutDetails != null
      //     ? hourlyCheckoutDetails?.data?.booking_details
      //     : "",
      // payment_summery_details:
      //   hourlyCheckoutDetails != null
      //     ? hourlyCheckoutDetails?.data?.payment_summery_details
      //     : "",
      request_data: hourlyCheckoutDetails?.data?.request_data,
      user_details:
        hourlyCheckoutDetails != null
          ? Object.entries(hourlyCheckoutDetails?.data?.user_details).length > 0
            ? hourlyCheckoutDetails?.data?.user_details
            : userData
          : "",
      card_details: search_type === "hour" ? cardData : null,
      pay_type: paymentModeValue,
      promo_code: promoCode,
      bid_now_amount: 0,
      slot_id: slot_id,
      book_for: book_for != null ? book_for : "",
      city: city != null ? city : "",
    };

    // console.log("data", data);

    saveGuestUserCheckoutDataRequest(data);
    hotelWheatherApiRequest(city);
  }, [userData, cardData, promoCode, paymentModeValue]);

  React.useEffect(() => {}, [
    hourlyCheckoutDetails,
    applyHotelOffers,
    validateUserEmail,
  ]);

  const handleCloseLoginPopup = () => {
    setShowLoginPopup(false);
  };

  const handleShowLoginPopup = () => setShowLoginPopup(true);

  React.useEffect(() => {
    if (userAuthData != null) {
      const postData = {
        hotel_id: hotel_id,
        room_type_id: room_type_id,
        slot_id: slot_id,
        check_in_date: check_in_date,
        adults: adults,
        children: children,
        no_of_rooms: rooms,
      };

      const data = {
        postData,
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
      };
      getHourlyCheckoutDetailsRequest(data);
    }
  }, [showLoginPopup, languageToShow]);

  /*** Country Code Selection   ***/
  const handleCountryCodeChange = (value, data, event, formattedValue) => {
    if (data.dialCode == "") {
      setCountryCode("");
    } else {
      setCountryCode(formattedValue);
      // setCountryCode("");
      setCountryCodeErr("");
    }
  };

  /*** Card Type Selection   ***/
  const handleChangeCardType = (e) => {
    if (e.target.name == "selectedCardType") {
      setCardData({
        ...cardData,
        selectedCardType: e.target.value,
      });
      setCardDataError({
        ...cardDataError,
        selectedCardTypeErr: "",
      });
    } else {
      setCardData({
        ...cardData,
        selectedCardType: "",
      });
    }
  };

  /***  Cardnumber change handler  ***/
  const handleChangeCardNumber = (e) => {
    if (e.target.name == "cardnumber") {
      const cardNumberformat = CardNumberFormatValidator(e.target.value);

      setCardData({
        ...cardData,
        cardnumber: cardNumberformat,
      });
      setCardDataError({
        ...cardDataError,
        cardnumberErr: "",
      });
    } else {
      setCardData({
        ...cardData,
        cardnumber: "",
      });
      // if (!validator.isNumeric(e.target.value)) {
      //   setCardDataError({
      //     ...cardDataError,
      //     cardnumberErr: "Please Enter Only number",
      //   });
      // }
    }
  };

  /***   Expected Time Arrival Handler   ***/
  const chandleChangeExpectedTime = (e) => {
    if (e.target.name == "expecedTimeArrival") {
      const timeformat = TimeFormatValidator(e.target.value);

      setUserData({
        ...userData,
        expecedTimeArrival: timeformat,
      });
      setuserDataError({
        ...userDataError,
        expecedTimeArrivalErr: "",
      });
    } else {
      setUserData({
        ...userData,
        expecedTimeArrival: "",
      });
    }
  };

  /*** Card Expiry Date handler  ***/
  const handleChangeExpiryDate = (e) => {
    if (e.target.name == "expirydate") {
      const expiryNumberFormat = CardExpiryFormatValidator(e.target.value);

      setCardData({
        ...cardData,
        expirydate: expiryNumberFormat,
      });
      setCardDataError({
        ...cardDataError,
        expirydateErr: "",
      });
    } else {
      setCardData({
        ...cardData,
        expirydate: "",
      });
    }
  };

  /*** Personal Details Handler  ***/
  const handlePersonalDetailsChange = (e) => {
    if (e.target.name == "firstname") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "",
      });
    } else if (e.target.name == "email") {
      const emailError = EmailValidator(e.target.value);
      if (emailError) {
        setuserDataError({
          ...userDataError,
          emailErr: emailError,
        });
      } else {
        setuserDataError({
          ...userDataError,
          emailErr: "",
        });
      }
    } else if (e.target.name == "confirmEmail") {
      setuserDataError({
        ...userDataError,
        confirmEmailErr: "",
      });
    } else {
      if (e.target.name == "mobileNo") {
        const isNumberError = MobileNumberValidator(e.target.value);
        if (isNumberError) {
          setuserDataError({
            ...userDataError,
            mobileNoErr: isNumberError,
          });
        } else {
          setuserDataError({
            ...userDataError,
            mobileNoErr: "",
          });
        }
      }
    }
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  /*** Terms and Policy Handler  ***/
  const handletermspolicy = (e) => {
    if (e.target.checked) {
      setCardData({
        ...cardData,
        termsandConditions: true,
      });
      setCardDataError({
        ...cardDataError,
        termsandConditionsErr: "",
      });
    } else {
      setCardData({
        ...cardData,
        termsandConditions: false,
      });
    }
  };

  /*** Card Details Handler  ***/
  const handleCardDetailsChange = (e) => {
    if (e.target.name == "nameoncard") {
      setCardDataError({
        ...cardDataError,
        nameoncardErr: "",
      });
      // } else if (e.target.name == "expirydate") {
      //   setCardDataError({
      //     ...cardDataError,
      //     expirydateErr: "",
      //   });
    } else if (e.target.name == "securitycode") {
      setCardDataError({
        ...cardDataError,
        securitycodeErr: "",
      });
      if (!validator.isNumeric(e.target.value)) {
        setCardDataError({
          ...cardDataError,
          securitycodeErr: "Please Enter Only number",
        });
      }
    } else {
      // if (e.target.name == "zipcode") {
      setCardDataError({
        ...cardDataError,
        zipcodeErr: "",
      });
      if (!validator.isNumeric(e.target.value)) {
        setCardDataError({
          ...cardDataError,
          zipcodeErr: "Please Enter Only number",
        });
      }
      // if (e.target.value < 6 || e.target.value > 9) {
      //   setCardDataError({
      //     ...cardDataError,
      //     zipcodeErr: "Atleast 6 or maximum 9 Digits Required",
      //   });
      // }
      // }
    }

    setCardData({
      ...cardData,
      [e.target.name]: e.target.value,
    });
  };

  const handleCheckExistingUser = React.useCallback(
    (e) => {
      console.log("blur event fired", e.target.value);
      if (userAuthData == null) {
        if (e.target.value !== "") {
          const data = {
            email: e.target.value,
            languageToShow: languageToShow,
          };

          validateUserEmailRequest(data);
        }
      }
    },
    [languageToShow]
  );

  React.useEffect(() => {
    if (validateUserEmail != null) {
      if (validateUserEmail?.data?.is_email_exist) {
        console.log("blur event fire", validateUserEmail?.data?.is_email_exist);
        // emailRef.current.focus();
        setuserDataError({
          ...userDataError,
          emailErr: "Email already exists, please login",
        });
      } else {
        setuserDataError({
          ...userDataError,
          emailErr: "",
        });
      }
    }
  }, [languageToShow, validateUserEmail]);

  /*** Apply Wallet Balance Handler  ***/
  const applyWalletBal = (event) => {
    event.preventDefault();
    if (
      walletBal == "" &&
      hourlyCheckoutDetails?.data?.user_details?.wallet_balance_points > 0
    ) {
      setWalletBalErr("Please Enter Your Wallet Balance");
    } else {
      const postData = {
        room_type_id:
          hourlyCheckoutDetails?.data?.booking_details?.room_type_id,
        slot_id: hourlyCheckoutDetails?.data?.booking_details?.slot_id,
        no_of_rooms: hourlyCheckoutDetails?.data?.booking_details?.no_of_rooms,
        no_of_points: walletBal,
        promo_code:
          promoCode != "" && applyHotelOffersFailedData?.code != 3014
            ? promoCode
            : "",
        bid_now_amount: 0,
      };
      const data = {
        postData,
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
      };

      if (
        (applyHotelOffers?.success == true &&
          applyHotelOffers.data.amount_to_be_paid_now <
            hourlyCheckoutDetails?.data?.user_details?.wallet_balance_points) ||
        hourlyCheckoutDetails.data.amount_to_be_paid_now <
          hourlyCheckoutDetails?.data?.user_details?.wallet_balance_points
      ) {
        navigate("/mypoints");
      } else {
        applyHotelOffersRequest(data);
        setWalletBal(walletBal);
      }

      // applyHotelOffersRequest(data);
      // setWalletBal(walletBal);
    }
  };

  /*** Apply Promo Code Handler  ***/
  const applyPromoCode = (event) => {
    event.preventDefault();
    if (promoCode == "") {
      setPromoCodeErr("Please Enter Your Promo Code");
    } else {
      setPromoCodeErr("");

      const postData = {
        room_type_id:
          hourlyCheckoutDetails?.data?.booking_details?.room_type_id,
        slot_id: hourlyCheckoutDetails?.data?.booking_details?.slot_id,
        no_of_rooms: hourlyCheckoutDetails?.data?.booking_details?.no_of_rooms,
        no_of_points:
          walletBal != "" &&
          hourlyCheckoutDetails?.data?.user_details?.wallet_balance_points > 0
            ? walletBal
            : 0,
        promo_code: promoCode,
        bid_now_amount: 0,
      };
      const data = {
        postData,
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
      };

      applyHotelOffersRequest(data);
      setPromoCode(promoCode);
    }
  };

  /*** Payment Type Handler  ***/
  const handlePaymentMode = (event) => {
    setPaymentModeValue(event.target.value);
  };

  var isEmailExist =
    validateUserEmail != null
      ? validateUserEmail?.data?.is_email_exist
        ? "Email already exists, please login"
        : ""
      : null;

  /*** Confirm and Payment Booking Handler  ***/
  const handleConfirmPay = (e) => {
    e.preventDefault();
    console.log(
      validateUserEmail,
      "isEmailExist",
      isEmailExist,
      validateUserEmail?.data?.is_email_exist
    );
    const regex = /^(0[1-9]|1[0-2])\/?([0-9]{2})$/;
    const expectedArrTimeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
    const mobileNoError = MobileNumberValidator(userData.mobileNo);
    const emailError = EmailValidator(userData.email);

    if (paymentModeValue === "cash") {
      if (userData.firstname == "") {
        firstnameRef.current.focus();
        setuserDataError({
          ...userDataError,
          firstnameErr: "Please Enter Your First Name",
        });
        return;
      } else if (emailError) {
        emailRef.current.focus();
        setuserDataError({
          ...userDataError,
          emailErr: emailError,
        });
        return;
      } else if (isEmailExist) {
        emailRef.current.focus();
        setuserDataError({
          ...userDataError,
          emailErr: isEmailExist,
        });
        return;
      } else if (userData.email != userData.confirmEmail) {
        confirmEmailRef.current.focus();
        setuserDataError({
          ...userDataError,
          confirmEmailErr: "Email and Confirm Email Not Same",
        });
        return;
      } else if (countryCode == "") {
        // countryCodeRef.current.focus();
        setCountryCodeErr("Please Select Your country code");
        return;
      } else if (mobileNoError) {
        mobileNoRef.current.focus();
        setuserDataError({
          ...userDataError,
          mobileNoErr: mobileNoError,
        });
        return;
      } else if (
        userData.expecedTimeArrival !== "" &&
        expectedArrTimeRegex.exec(userData.expecedTimeArrival) == null
      ) {
        expectedTimeArrRef.current.focus();
        setuserDataError({
          ...userDataError,
          expecedTimeArrivalErr: "Please Enter valid time (Ex: 08:00)",
        });
        return;
      } else if (cardData.termsandConditions == false) {
        setCardDataError({
          ...cardDataError,
          termsandConditionsErr: "Please accept terms and conditions",
        });
        return;
      } else {
        const cardDetailsObj = {
          card_number: "871492145677",
          name_on_card: "BUBAI SAHA",
          exp_date: "04/25",
          security_code: "073",
          card_type: "debit",
          zip_code: "700144",
          // card_number: cardData.cardnumber.replaceAll(/\s/g, ""),
          // name_on_card: cardData.nameoncard,
          // exp_date: cardData.expirydate,
          // security_code: cardData.securitycode,
          // card_type: cardData.selectedCardType,
          // zip_code: cardData.zipcode,
        };
        const postData = {
          search_type: hourlyCheckoutDetails?.data?.request_data?.search_type,
          hotel_id: hourlyCheckoutDetails?.data?.request_data?.hotel_id,
          room_type_id:
            hourlyCheckoutDetails?.data?.request_data?.room_type_id,
          slot_id: hourlyCheckoutDetails?.data?.request_data?.slot_id,
          check_in_date:
            hourlyCheckoutDetails?.data?.request_data?.check_in_date,
          check_in_time: selectedCheckInTime
            ? selectedCheckInTime
            : hourlyCheckoutDetails?.data?.booking_details?.check_in_time,
          check_out_time: selectedCheckInTime
            ? moment(
                moment(selectedCheckInTime, ["hh:mm"]).add(
                  hourlyCheckoutDetails?.data?.booking_details
                    ?.total_length_of_stay_hours,
                  "h"
                )
              ).format("HH:mm")
            : hourlyCheckoutDetails?.data?.booking_details?.check_out_time,
          adults: hourlyCheckoutDetails?.data?.request_data?.adults,
          children: hourlyCheckoutDetails?.data?.request_data?.children,
          no_of_rooms:
            hourlyCheckoutDetails?.data?.request_data?.no_of_rooms,
          user_details: {
            first_name: userData.firstname,
            last_name: userData.lastname,
            email: userData.email,
            country_code: countryCode,
            contact_no: userData.mobileNo,
            expected_time_of_arrival: userData.expecedTimeArrival,
          },
          // no_of_points: walletBal,
          no_of_points:
            walletBal != "" &&
            hourlyCheckoutDetails?.data?.user_details?.wallet_balance_points > 0
              ? walletBal
              : 0,
          // promo_code: promoCode,
          promo_code:
            promoCode != "" && applyHotelOffersFailedData?.code != 3014
              ? promoCode
              : "",
          // bid_now_amount: 0,
          pay_type: paymentModeValue,
          card_details: cardDetailsObj,
          payment_summery_details: {
            currency:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.currency
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.currency,

            net_rate:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.net_rate
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.net_rate,

            taxes:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.taxes
                : hourlyCheckoutDetails?.data?.payment_summery_details?.taxes,

            // service_fee:
            //   applyHotelOffers != null
            //     ? applyHotelOffers?.data?.service_fee
            //     : hourlyCheckoutDetails?.data?.payment_summery_details
            //         ?.service_fee,
            service_fee:
              applyHotelOffers != null &&
              applyHotelOffers?.data?.service_fee != null
                ? applyHotelOffers?.data?.service_fee
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.service_fee != null
                ? hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.service_fee
                : 0,

            amount:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.amount
                : hourlyCheckoutDetails?.data?.payment_summery_details?.amount,

            amount_to_be_paid_now:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.amount_to_be_paid_now
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.amount_to_be_paid_now,
          },
        };

        const data = {
          postData,
          languageToShow: languageToShow,
          token: userAuthData != null ? userAuthData.token : "",
        };

        // console.log("postData", postData);
        if (selectedCheckInTime != "") {
          hotelBookingRequest(data);
          stateClearAfterTask();
          validateEmailStateClearAfterTask();
          // setUserData({
          //   firstname: "",
          //   lastname: "",
          //   email: "",
          //   confirmEmail: "",
          //   mobileNo: "",
          //   expecedTimeArrival: "",
          // });
          // setCountryCode("");
          // setCardData({
          //   cardnumber: "",
          //   nameoncard: "",
          //   expirydate: "",
          //   securitycode: "",
          //   selectedCardType: "",
          //   zipcode: "",
          //   termsandConditions: false,
          // });
        } else {
          errorToast("Please select Check-in Time");
        }
      }
    } else {
      if (userData.firstname == "") {
        firstnameRef.current.focus();
        setuserDataError({
          ...userDataError,
          firstnameErr: "Please Enter Your First Name",
        });
        return;
      } else if (emailError) {
        emailRef.current.focus();
        setuserDataError({
          ...userDataError,
          emailErr: emailError,
        });
        return;
      } else if (isEmailExist) {
        emailRef.current.focus();
        setuserDataError({
          ...userDataError,
          emailErr: isEmailExist,
        });
        return;
      } else if (userData.email != userData.confirmEmail) {
        confirmEmailRef.current.focus();
        setuserDataError({
          ...userDataError,
          confirmEmailErr: "Email and Confirm Email Not Same",
        });
        return;
      } else if (countryCode == "") {
        // countryCodeRef.current.focus();
        setCountryCodeErr("Please Select Your country code");
        return;
      } else if (mobileNoError) {
        mobileNoRef.current.focus();
        setuserDataError({
          ...userDataError,
          mobileNoErr: mobileNoError,
        });
        return;
      } else if (
        userData.expecedTimeArrival !== "" &&
        expectedArrTimeRegex.exec(userData.expecedTimeArrival) == null
      ) {
        expectedTimeArrRef.current.focus();
        setuserDataError({
          ...userDataError,
          expecedTimeArrivalErr: "Please Enter valid time (Ex: 08:00)",
        });
        return;
      } else if (cardData.cardnumber == "") {
        cardnumberRef.current.focus();
        setCardDataError({
          ...cardDataError,
          cardnumberErr: "Please Enter Your Card Number",
        });
        return;
      } else if (
        cardData.cardnumber.length < 14 ||
        cardData.cardnumber.length > 19
      ) {
        cardnumberRef.current.focus();
        setCardDataError({
          ...cardDataError,
          cardnumberErr: "Atleast 12 or maximum 16 Digits Required",
        });
        return;
      } else if (cardData.nameoncard == "") {
        nameoncardRef.current.focus();
        setCardDataError({
          ...cardDataError,
          nameoncardErr: "Please Enter Your Card Holder Name",
        });
        return;
      } else if (cardData.expirydate == "") {
        expirydateRef.current.focus();
        setCardDataError({
          ...cardDataError,
          expirydateErr: "Please Enter Your Card Expiry Date",
        });
        return;
      } else if (
        cardData.expirydate.length < 5 ||
        cardData.expirydate.length > 5
      ) {
        expirydateRef.current.focus();
        setCardDataError({
          ...cardDataError,
          expirydateErr: "Your Expiry Date must be 5 Characters",
        });
        return;
      } else if (regex.exec(cardData.expirydate) == null) {
        expirydateRef.current.focus();
        setCardDataError({
          ...cardDataError,
          expirydateErr: "Please Enter Your Card Expiry Date in format MM/YY",
        });
        return;
      } else if (cardData.securitycode == "") {
        securitycodeRef.current.focus();
        setCardDataError({
          ...cardDataError,
          securitycodeErr: "Please Enter Your Security Code",
        });
        return;
      } else if (
        cardData.securitycode.length < 3 ||
        cardData.securitycode.length > 3
      ) {
        securitycodeRef.current.focus();
        setCardDataError({
          ...cardDataError,
          securitycodeErr: "Your Security Code must be 3 Digits",
        });
        return;
        // } else if (cardData.selectedCardType == "") {
        //   selectedCardTypeRef.current.focus();
        //   setCardDataError({
        //     ...cardDataError,
        //     selectedCardTypeErr: "Please Select Your Card Type",
        //   });
        //   return;
        // } else if (cardData.zipcode == "") {
        //   zipcodeRef.current.focus();
        //   setCardDataError({
        //     ...cardDataError,
        //     zipcodeErr: "Please Enter Your Zip Code",
        //   });
        //   return;
        // } else if (cardData.zipcode.length < 6 || cardData.zipcode.length > 9) {
        //   zipcodeRef.current.focus();
        //   setCardDataError({
        //     ...cardDataError,
        //     zipcodeErr: "Atleast 6 or maximum 9 Digits Required",
        //   });
        //   return;
      } else if (cardData.termsandConditions == false) {
        setCardDataError({
          ...cardDataError,
          termsandConditionsErr: "Please accept terms and conditions",
        });
        return;
      } else {
        const cardDetailsObj = {
          card_number: cardData.cardnumber.replaceAll(/\s/g, ""),
          name_on_card: cardData.nameoncard,
          exp_date: cardData.expirydate,
          security_code: cardData.securitycode,
          card_type: cardData.selectedCardType,
          zip_code: cardData.zipcode,
        };
        const postData = {
          search_type: hourlyCheckoutDetails?.data?.request_data?.search_type,
          hotel_id: hourlyCheckoutDetails?.data?.request_data?.hotel_id,
          room_type_id:
            hourlyCheckoutDetails?.data?.request_data?.room_type_id,
          slot_id: hourlyCheckoutDetails?.data?.request_data?.slot_id,
          check_in_date:
            hourlyCheckoutDetails?.data?.request_data?.check_in_date,
          check_in_time: selectedCheckInTime
            ? selectedCheckInTime
            : hourlyCheckoutDetails?.data?.booking_details?.check_in_time,
          check_out_time: selectedCheckInTime
            ? moment(
                moment(selectedCheckInTime, ["hh:mm"]).add(
                  hourlyCheckoutDetails?.data?.booking_details
                    ?.total_length_of_stay_hours,
                  "h"
                )
              ).format("HH:mm")
            : hourlyCheckoutDetails?.data?.booking_details?.check_out_time,
          adults: hourlyCheckoutDetails?.data?.request_data?.adults,
          children: hourlyCheckoutDetails?.data?.request_data?.children,
          no_of_rooms:
            hourlyCheckoutDetails?.data?.request_data?.no_of_rooms,
          user_details: {
            first_name: userData.firstname,
            last_name: userData.lastname,
            email: userData.email,
            country_code: countryCode,
            contact_no: userData.mobileNo,
            expected_time_of_arrival: userData.expecedTimeArrival,
          },
          // no_of_points: walletBal,
          no_of_points:
            walletBal != "" &&
            hourlyCheckoutDetails?.data?.user_details?.wallet_balance_points > 0
              ? walletBal
              : 0,
          // promo_code: promoCode,
          promo_code:
            promoCode != "" && applyHotelOffersFailedData?.code != 3014
              ? promoCode
              : "",
          // bid_now_amount: 0,
          pay_type: paymentModeValue,
          card_details: cardDetailsObj,
          payment_summery_details: {
            currency:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.currency
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.currency,

            net_rate:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.net_rate
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.net_rate,

            taxes:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.taxes
                : hourlyCheckoutDetails?.data?.payment_summery_details?.taxes,

            // service_fee:
            //   applyHotelOffers != null
            //     ? applyHotelOffers?.data?.service_fee
            //     : hourlyCheckoutDetails?.data?.payment_summery_details
            //         ?.service_fee,
            service_fee:
              applyHotelOffers != null &&
              applyHotelOffers?.data?.service_fee != null
                ? applyHotelOffers?.data?.service_fee
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.service_fee != null
                ? hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.service_fee
                : 0,

            amount:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.amount
                : hourlyCheckoutDetails?.data?.payment_summery_details?.amount,

            amount_to_be_paid_now:
              applyHotelOffers != null
                ? applyHotelOffers?.data?.amount_to_be_paid_now
                : hourlyCheckoutDetails?.data?.payment_summery_details
                    ?.amount_to_be_paid_now,
          },
        };

        const data = {
          postData,
          languageToShow: languageToShow,
          token: userAuthData != null ? userAuthData.token : "",
        };

        // console.log("postData", postData);
        if (selectedCheckInTime != "") {
          hotelBookingRequest(data);
          stateClearAfterTask();
          validateEmailStateClearAfterTask();
          // setUserData({
          //   firstname: "",
          //   lastname: "",
          //   email: "",
          //   confirmEmail: "",
          //   mobileNo: "",
          //   expecedTimeArrival: "",
          // });
          // setCountryCode("");
          // setCardData({
          //   cardnumber: "",
          //   nameoncard: "",
          //   expirydate: "",
          //   securitycode: "",
          //   selectedCardType: "",
          //   zipcode: "",
          //   termsandConditions: false,
          // });
        } else {
          errorToast("Please select Check-in Time");
        }
      }
    }
  };
  const refreshPage = () => {
    navigate(0);
  };

  React.useEffect(() => {
    if (hotelBooking != null) {
      if (hotelBooking.code == 4036 || hotelBooking.code == 4054) {
        const timeout = setTimeout(() => {
          navigate("/");
          saveGuestUserCheckoutDataRequest(null);
          stateClearAfterTask();
        }, 5001);
        return () => clearTimeout(timeout);
      } else {
      }
      // stateClearAfterTask();
    }
  }, [JSON.stringify(hotelBooking)]);

  React.useEffect(() => {
    if (hotelBooking != null) {
      if (hotelBooking.success == true) {
        // navigate("/");
        setShowConfirmDialog(true);
        saveGuestUserCheckoutDataRequest(null);
        // stateClearAfterTask();
      } else {
      }
      // stateClearAfterTask();
    }
  }, [JSON.stringify(hotelBooking)]);

  const viewBookingDetailsHandler = () => {
    setShowConfirmDialog(false);
    setShowBookingDetailsModal(true);
  };

  return (
    <>
      <>{console.log("hotelBooking", hotelBooking)}</>
      {/* //////////Checkout main content start/////////// */}
      {/* <Button onClick={()=> setShowConfirmDialog(true)}>Show confirm modal</Button> */}

      <div className="container">
        <div className="WL_biduser_mainwrp">
          <div className="row">
            {/* ///Checkout left content start/// */}
            <div className="col-md-4">
              {/* <div className="WL_left-bibuser"> */}

              <div className="WL_left-bibuser">
                <h3 className="WL_bookingheading text-capitalize">
                  Your Hourly Booking Details
                </h3>
                <div className="WL_inner_leftwrp">
                  {/* ///checkout checkin wrp start/// */}
                  <div className="WL_checkwrp">
                    <div className="WL_checkwrp_left">
                      <p className="WL_check_txt">Check-In</p>
                      <p className="WL_check_txt2">
                        {moment(
                          hourlyCheckoutDetails?.data?.booking_details
                            ?.check_in_date
                          // ,"DD/MM/YYYY"
                        ).format("ddd, ll")}
                      </p>
                      {/* <p className="WL_check_txt">
                        {selectedCheckInTime
                          ? moment(
                              moment(selectedCheckInTime, ["hh:mm"])
                            ).format("hh:mm A")
                          : moment(
                              `${hourlyCheckoutDetails?.data?.booking_details?.check_in_time}`,
                              ["hh:mm"]
                            ).format("hh:mm A")}
                      </p> */}
                    </div>
                    <div className="WL_checkwrp_left">
                      <p className="WL_check_txt">Total Length of Stay</p>
                      <p className="WL_totl_text">
                        <strong>
                          {
                            hourlyCheckoutDetails?.data?.booking_details
                              ?.total_length_of_stay_hours
                          }
                          {"  "}
                          {hourlyCheckoutDetails?.data?.booking_details
                            ?.total_length_of_stay_hours > 1
                            ? "Hours"
                            : "Hour"}
                        </strong>
                      </p>
                    </div>
                  </div>
                  {/* ///checkout checkin wrp end/// */}

                  {/* ///////Select Check In Time start/////// */}
                  <div className="WL_select_checkintime">
                    <p className="WL_select_checkintime_text">
                      Select Your Check In Time
                    </p>
                    <div className="WL_checkintime_selectbox">
                      <Form.Select
                        aria-label="CheckIn"
                        value={selectedCheckInTime}
                        onChange={(e) => {
                          setSelectedCheckInTime(e.target.value);
                        }}
                      >
                        {/* <option>9:00 AM</option> */}
                        <option disabled selected value="">
                          {/* {moment(
                            `${hourlyCheckoutDetails?.data?.booking_details?.check_in_time}`,
                            ["hh:mm"]
                          ).format("hh:mm A")} */}
                          Select check-in time
                        </option>
                        {hourlyCheckoutDetails?.data?.booking_details?.check_in_slots.map(
                          (CHISlot, index) => (
                            <option value={CHISlot} key={index}>
                              {moment(`${CHISlot}`, ["hh:mm"]).format(
                                "hh:mm A"
                              )}
                            </option>
                          )
                        )}
                      </Form.Select>
                    </div>
                  </div>
                  {/* ///////Select Check In Time end/////// */}

                  {/* ///////Select Check Out Time start/////// */}
                  <div className="WL_select_checkintime">
                    <p className="WL_select_checkintime_text">
                      Your Check Out Time
                    </p>
                    <div className="WL_checkouttime_text">
                      {selectedCheckInTime
                        ? moment(
                            moment(selectedCheckInTime, ["hh:mm"]).add(
                              hourlyCheckoutDetails?.data?.booking_details
                                ?.total_length_of_stay_hours,
                              "h"
                            )
                          ).format("hh:mm A")
                        : moment(
                            `${hourlyCheckoutDetails?.data?.booking_details?.check_out_time}`,
                            ["hh:mm"]
                          ).format("hh:mm A")}
                    </div>
                  </div>
                  {/* ///////Select Check Out Time end/////// */}

                  {/* ///Total length wrp start/// */}
                  <div className="WL_totl_textwrp">
                    <p className="WL_totl_text">
                      No. of Room:{" "}
                      <strong>
                        {hourlyCheckoutDetails?.data?.request_data.no_of_rooms}{" "}
                        {hourlyCheckoutDetails?.data?.request_data.no_of_rooms >
                        1
                          ? "Rooms"
                          : "Room"}
                      </strong>
                    </p>
                    <p className="WL_totl_text">
                      Room Type:{" "}
                      <strong>
                        {
                          hourlyCheckoutDetails?.data?.booking_details
                            ?.room_type_name
                        }
                      </strong>
                    </p>
                    <p className="WL_totl_text">
                      {/* Fits up to: */}
                      No. of Guest:{" "}
                      <strong>
                        {hourlyCheckoutDetails?.data?.request_data.adults}{" "}
                        {hourlyCheckoutDetails?.data?.request_data.adults > 1
                          ? "Guests"
                          : "Guest"}
                      </strong>
                    </p>
                    {/* <p className="WL_totl_text">
                      Room :{" "}
                      <strong>
                        {
                          hourlyCheckoutDetails?.data?.booking_details
                            ?.room_type_name
                        }
                      </strong>
                    </p> */}
                  </div>
                  {/* ///Total length wrp end/// */}

                  {/* ////////////////////Available balance wrp start/////////////// */}

                  {/* ///Bid amount wrp start/// */}
                  {userAuthData != null && (
                    <div className="WL_bidamnt_wrp mt-4">
                      <div className="WL_amnt_textheading">
                        Available Wallet Balance
                      </div>
                      <div className="WL_pointbox">
                        {
                          hourlyCheckoutDetails?.data?.user_details
                            ?.wallet_balance_points
                        }{" "}
                        POINTS
                      </div>
                      <div className="d-flex justify-content-end w-100">
                        <p className="WL_totl_text_conversion">
                          (
                          {parseInt(
                            hourlyCheckoutDetails?.data
                              ?.wallet_points_conversion_rate
                              ?.conversion_amount *
                              currencyToShow.convertedRates
                          )}
                          {currencyToShow.current} ={" "}
                          {currencyToShow.current === "INR"
                            ? Number(
                                hourlyCheckoutDetails?.data
                                  ?.wallet_points_conversion_rate
                                  ?.wallet_point_value / 22
                              ).toFixed(2)
                            : hourlyCheckoutDetails?.data
                                ?.wallet_points_conversion_rate
                                ?.wallet_point_value}{" "}
                          Point)
                        </p>
                      </div>
                    </div>
                  )}

                  {/* ///Bid amount wrp end/// */}

                  {/* ///Card details wrp start/// */}
                  {userAuthData != null && (
                    <div className="WL_carddetailst_wrp customform">
                      <Form onSubmit={applyWalletBal}>
                        <div className="WL_innercardholder">
                          <Form.Group controlId="formCheckoutCardDetails">
                            <Form.Control
                              type="text"
                              placeholder="Enter wallet Balance"
                              className="WL_frm_wcrd WL_frm_wcrd_points"
                              name="walletBal"
                              onChange={(e) => {
                                setWalletBal(e.target.value);
                                if (!validator.isNumeric(e.target.value)) {
                                  setWalletBalErr("Please Enter only Number");
                                  return;
                                } else {
                                  setWalletBalErr("");
                                }
                              }}
                              value={walletBal}
                              disabled={
                                hourlyCheckoutDetails?.data?.user_details
                                  ?.wallet_balance_points > 0
                                  ? false
                                  : true
                              }
                            />
                            <Form.Text className="text-muted">
                              {walletBalErr}
                            </Form.Text>
                          </Form.Group>
                          <Button
                            variant=""
                            type="submit"
                            className="WL_card_submitbtn"
                            disabled={
                              hourlyCheckoutDetails?.data?.user_details
                                ?.wallet_balance_points > 0
                                ? false
                                : true
                            }
                          >
                            apply
                          </Button>
                        </div>
                      </Form>
                    </div>
                  )}
                  {/* ///card details wrp end/// */}
                  {/* ////////////////////Available balance wrp end/////////////// */}

                  {/* ///Total summary wrp start/// */}
                  <div className="WL_paymentwrp">
                    <h3>Payment Summary</h3>
                    <div className="WL_payment_inerwrp">
                      <div className="WL_payment_iner_left">Net rate:</div>
                      <div className="WL_payment_iner_right">
                        {/* {applyHotelOffers != null
                          ? applyHotelOffers?.data?.net_rate
                          : hourlyCheckoutDetails?.data?.payment_summery_details
                              ?.net_rate}{" "}
                        {applyHotelOffers != null
                          ? applyHotelOffers?.data?.currency
                          : hourlyCheckoutDetails?.data?.payment_summery_details
                              ?.currency} */}
                        {applyHotelOffers !== null &&
                        "data" in applyHotelOffers &&
                        "net_rate" in applyHotelOffers.data
                          ? Number(
                              applyHotelOffers.data.net_rate *
                                currencyToShow.convertedRates
                            ).toFixed(2)
                          : ""}
                        {applyHotelOffers === null &&
                        hourlyCheckoutDetails &&
                        "data" in hourlyCheckoutDetails &&
                        "payment_summery_details" in
                          hourlyCheckoutDetails.data &&
                        "net_rate" in
                          hourlyCheckoutDetails.data.payment_summery_details
                          ? Number(
                              hourlyCheckoutDetails.data.payment_summery_details
                                .net_rate * currencyToShow.convertedRates
                            ).toFixed(2)
                          : ""}
                        {" " + currencyToShow.current}
                      </div>
                    </div>
                    {/******  Vat(15%)**** */}
                    {applyHotelOffers != null &&
                    applyHotelOffers?.data?.vat != null ? (
                      <div className="WL_payment_inerwrp">
                        <div className="WL_payment_iner_left">Vat(15%):</div>
                        <div className="WL_payment_iner_right">
                          {applyHotelOffers !== null &&
                          "data" in applyHotelOffers &&
                          "vat" in applyHotelOffers.data
                            ? parseInt(
                                applyHotelOffers.data.vat *
                                  currencyToShow.convertedRates
                              )
                            : 0}
                          {applyHotelOffers === null &&
                          hourlyCheckoutDetails &&
                          "data" in hourlyCheckoutDetails &&
                          "payment_summery_details" in
                            hourlyCheckoutDetails.data &&
                          "vat" in
                            hourlyCheckoutDetails.data.payment_summery_details
                            ? parseInt(
                                hourlyCheckoutDetails.data
                                  .payment_summery_details.vat *
                                  currencyToShow.convertedRates
                              )
                            : ""}
                          {" " + currencyToShow.current}
                        </div>
                      </div>
                    ) : hourlyCheckoutDetails?.data?.payment_summery_details
                        ?.vat != null ? (
                      <div className="WL_payment_inerwrp">
                        <div className="WL_payment_iner_left">Vat(15%):</div>
                        <div className="WL_payment_iner_right">
                          {applyHotelOffers !== null &&
                          "data" in applyHotelOffers &&
                          "vat" in applyHotelOffers.data
                            ? parseInt(
                                applyHotelOffers.data.vat *
                                  currencyToShow.convertedRates
                              )
                            : 0}
                          {applyHotelOffers === null &&
                          hourlyCheckoutDetails &&
                          "data" in hourlyCheckoutDetails &&
                          "payment_summery_details" in
                            hourlyCheckoutDetails.data &&
                          "vat" in
                            hourlyCheckoutDetails.data.payment_summery_details
                            ? parseInt(
                                hourlyCheckoutDetails.data
                                  .payment_summery_details.vat *
                                  currencyToShow.convertedRates
                              )
                            : ""}
                          {" " + currencyToShow.current}
                        </div>
                      </div>
                    ) : (
                      ""
                    )}
                    {/******  Vat(15%)**** */}

                    <div className="WL_payment_inerwrp">
                      <div className="WL_payment_iner_left">vat(15%): </div>
                      <div className="WL_payment_iner_right">
                        {/* {applyHotelOffers != null
                          ? applyHotelOffers?.data?.taxes
                          : hourlyCheckoutDetails?.data?.payment_summery_details
                              ?.taxes}{" "}
                        {applyHotelOffers != null
                          ? applyHotelOffers?.data?.currency
                          : hourlyCheckoutDetails?.data?.payment_summery_details
                              ?.currency} */}

                        {applyHotelOffers !== null &&
                        "data" in applyHotelOffers &&
                        "taxes" in applyHotelOffers.data
                          ? Number(
                              applyHotelOffers.data.taxes *
                                currencyToShow.convertedRates
                            ).toFixed(2)
                          : ""}
                        {applyHotelOffers === null &&
                        hourlyCheckoutDetails &&
                        "data" in hourlyCheckoutDetails &&
                        "payment_summery_details" in
                          hourlyCheckoutDetails.data &&
                        "taxes" in
                          hourlyCheckoutDetails.data.payment_summery_details
                          ? Number(
                              hourlyCheckoutDetails.data.payment_summery_details
                                .taxes * currencyToShow.convertedRates
                            ).toFixed(2)
                          : ""}
                        {" " + currencyToShow.current}
                      </div>
                    </div>

                    {applyHotelOffers != null &&
                    applyHotelOffers?.data?.service_fee != null ? (
                      <div className="WL_payment_inerwrp">
                        <div className="WL_payment_iner_left">Service fee:</div>
                        <div className="WL_payment_iner_right">
                          {/* {applyHotelOffers != null
                          ? applyHotelOffers?.data?.service_fee
                          : hourlyCheckoutDetails?.data?.payment_summery_details
                              ?.service_fee}{" "}
                        {applyHotelOffers != null
                          ? applyHotelOffers?.data?.currency
                          : hourlyCheckoutDetails?.data?.payment_summery_details
                              ?.currency} */}

                          {applyHotelOffers !== null &&
                          "data" in applyHotelOffers &&
                          "service_fee" in applyHotelOffers.data
                            ? Number(
                                applyHotelOffers.data.service_fee *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : 0}
                          {applyHotelOffers === null &&
                          hourlyCheckoutDetails &&
                          "data" in hourlyCheckoutDetails &&
                          "payment_summery_details" in
                            hourlyCheckoutDetails.data &&
                          "service_fee" in
                            hourlyCheckoutDetails.data.payment_summery_details
                            ? Number(
                                hourlyCheckoutDetails.data
                                  .payment_summery_details.service_fee *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : ""}
                          {" " + currencyToShow.current}
                        </div>
                      </div>
                    ) : hourlyCheckoutDetails?.data?.payment_summery_details
                        ?.service_fee != null ? (
                      <div className="WL_payment_inerwrp">
                        <div className="WL_payment_iner_left">Service fee:</div>
                        <div className="WL_payment_iner_right">
                          {/* {applyHotelOffers != null
                              ? applyHotelOffers?.data?.service_fee
                              : hourlyCheckoutDetails?.data?.payment_summery_details
                                  ?.service_fee}{" "}
                            {applyHotelOffers != null
                              ? applyHotelOffers?.data?.currency
                              : hourlyCheckoutDetails?.data?.payment_summery_details
                                  ?.currency} */}

                          {applyHotelOffers !== null &&
                          "data" in applyHotelOffers &&
                          "service_fee" in applyHotelOffers.data
                            ? Number(
                                applyHotelOffers.data.service_fee *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : 0}
                          {applyHotelOffers === null &&
                          hourlyCheckoutDetails &&
                          "data" in hourlyCheckoutDetails &&
                          "payment_summery_details" in
                            hourlyCheckoutDetails.data &&
                          "service_fee" in
                            hourlyCheckoutDetails.data.payment_summery_details
                            ? Number(
                                hourlyCheckoutDetails.data
                                  .payment_summery_details.service_fee *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : ""}
                          {" " + currencyToShow.current}
                        </div>
                      </div>
                    ) : (
                      ""
                    )}

                    <div className="WL_payment_inerwrp">
                      <div className="WL_payment_iner_left">
                        <strong>Amount</strong>{" "}
                      </div>
                      <div className="WL_payment_iner_right">
                        <strong>
                          {/* {applyHotelOffers != null
                            ? applyHotelOffers?.data?.amount
                            : hourlyCheckoutDetails?.data
                                ?.payment_summery_details?.amount}{" "}
                          {applyHotelOffers != null
                            ? applyHotelOffers?.data?.currency
                            : hourlyCheckoutDetails?.data
                                ?.payment_summery_details?.currency} */}

                          {applyHotelOffers !== null &&
                          "data" in applyHotelOffers &&
                          "amount" in applyHotelOffers.data
                            ? Number(
                                applyHotelOffers.data.amount *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : ""}
                          {applyHotelOffers === null &&
                          hourlyCheckoutDetails &&
                          "data" in hourlyCheckoutDetails &&
                          "payment_summery_details" in
                            hourlyCheckoutDetails.data &&
                          "amount" in
                            hourlyCheckoutDetails.data.payment_summery_details
                            ? Number(
                                hourlyCheckoutDetails.data
                                  .payment_summery_details.amount *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : ""}
                          {" " + currencyToShow.current}
                        </strong>
                      </div>
                    </div>
                    {/* Coupon applied */}
                    {applyHotelOffers != null
                      ? applyHotelOffers?.data?.coupon_amount_applied && (
                          <div className="WL_payment_inerwrp">
                            <div className="WL_payment_iner_left">
                              <strong style={{ color: "#5287b3" }}>
                                Applied Coupon Amount
                              </strong>{" "}
                            </div>
                            <div className="WL_payment_iner_right">
                              <strong style={{ color: "#5287b3" }}>
                                {/* {applyHotelOffers?.data?.coupon_amount_applied}{" "}
                                {applyHotelOffers?.data?.currency} */}

                                {applyHotelOffers !== null &&
                                "data" in applyHotelOffers &&
                                "coupon_amount_applied" in applyHotelOffers.data
                                  ? Number(
                                      applyHotelOffers.data
                                        .coupon_amount_applied *
                                        currencyToShow.convertedRates
                                    ).toFixed(2)
                                  : ""}

                                {" " + currencyToShow.current}
                              </strong>
                            </div>
                          </div>
                        )
                      : null}
                    {/* Wallet balance applied */}
                    {applyHotelOffers != null
                      ? applyHotelOffers?.data?.wallet_balance_applied && (
                          <div className="WL_payment_inerwrp">
                            <div className="WL_payment_iner_left">
                              <strong style={{ color: "#5287b3" }}>
                                Applied Wallet Balance
                              </strong>{" "}
                            </div>
                            <div className="WL_payment_iner_right">
                              <strong style={{ color: "#5287b3" }}>
                                {/* {applyHotelOffers?.data?.wallet_balance_applied}{" "}
                                {applyHotelOffers?.data?.currency} */}

                                {applyHotelOffers !== null &&
                                "data" in applyHotelOffers &&
                                "wallet_balance_applied" in
                                  applyHotelOffers.data
                                  ? Number(
                                      applyHotelOffers.data
                                        .wallet_balance_applied *
                                        currencyToShow.convertedRates
                                    ).toFixed(2)
                                  : ""}

                                {" " + currencyToShow.current}
                              </strong>
                            </div>
                          </div>
                        )
                      : null}
                    <div className="WL_payment_inerwrp">
                      <div className="WL_payment_iner_left">
                        <strong>Amount to be paid now</strong>{" "}
                      </div>
                      <div className="WL_payment_iner_right">
                        <strong>
                          {/* {applyHotelOffers != null
                            ? applyHotelOffers?.data?.amount_to_be_paid_now
                            : hourlyCheckoutDetails?.data
                                ?.payment_summery_details
                                ?.amount_to_be_paid_now}{" "}
                          {applyHotelOffers != null
                            ? applyHotelOffers?.data?.currency
                            : hourlyCheckoutDetails?.data
                                ?.payment_summery_details?.currency} */}

                          {applyHotelOffers !== null &&
                          "data" in applyHotelOffers &&
                          "amount_to_be_paid_now" in applyHotelOffers.data
                            ? Number(
                                applyHotelOffers.data.amount_to_be_paid_now *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : ""}
                          {applyHotelOffers === null &&
                          hourlyCheckoutDetails &&
                          "data" in hourlyCheckoutDetails &&
                          "payment_summery_details" in
                            hourlyCheckoutDetails.data &&
                          "amount_to_be_paid_now" in
                            hourlyCheckoutDetails.data.payment_summery_details
                            ? Number(
                                hourlyCheckoutDetails.data
                                  .payment_summery_details
                                  .amount_to_be_paid_now *
                                  currencyToShow.convertedRates
                              ).toFixed(2)
                            : ""}
                          {" " + currencyToShow.current}
                        </strong>
                      </div>
                    </div>
                  </div>
                  {/* ///Total summary wrp end/// */}

                  {/* ///Card details wrp start/// */}
                  {/* ///card details wrp end/// */}
                  {userAuthData == null && (
                    <Button
                      className="WL_walletballenec_btn"
                      type="button"
                      onClick={handleShowLoginPopup}
                      // onClick={() => {
                      //   navigate("/login", {
                      //     state: {
                      //       RenderedPageName:
                      //         "checkout-day-book-hourly-guest-user",
                      //     },
                      //   });
                      //   stateClearAfterTask();
                      // }}
                    >
                      Login to use your wallet Balance{" "}
                    </Button>
                  )}
                </div>
              </div>
            </div>
            {/* ///Checkout left content end/// */}

            {/* ///Checkout right content start/// */}
            <div className="col-md-8">
              {/* ///review slider content start/// */}
              <CheckoutHotelDetails
                CheckoutHotelDetailsData={hourlyCheckoutDetails}
              />
              {/* ///review slider content end/// */}

              <Form onSubmit={handleConfirmPay}>
                {/* ///personal details start/// */}
                <>{console.log("paymentModeValue", paymentModeValue)}</>

                <CheckoutUserForm
                  userData={userData}
                  userDataError={userDataError}
                  handlePersonalDetailsChange={handlePersonalDetailsChange}
                  handleCountryCodeChange={handleCountryCodeChange}
                  countryCode={countryCode}
                  countryCodeErr={countryCodeErr}
                  firstnameRef={firstnameRef}
                  confirmEmailRef={confirmEmailRef}
                  emailRef={emailRef}
                  countryCodeRef={countryCodeRef}
                  mobileNoRef={mobileNoRef}
                  chandleChangeExpectedTime={chandleChangeExpectedTime}
                  expectedTimeArrRef={expectedTimeArrRef}
                  handleCheckExistingUser={handleCheckExistingUser}
                />

                {/* ///personal details  end/// */}

                {/* ///promo code wrapper start/// */}
                <div className="WL_persnal_wrap customform">
                  {/* ///promo code start/// */}
                  <h3 className="WL_amnt_textheading">
                    Do you Have a Promo Code?
                  </h3>
                  <div className="WL_carddetailst_wrp customform">
                    {/* <Form onSubmit={applyPromoCode}> */}
                    <div className="WL_innercardholder">
                      <Form.Group controlId="formCheckoutCardPromo">
                        <Form.Control
                          type="text"
                          placeholder="TEST1234"
                          className="WL_frm_prmcode"
                          name="promoCode"
                          onChange={(e) => {
                            setPromoCode(e.target.value);
                            if (e.target.value != "") {
                              setPromoCodeErr("");
                              return;
                            }
                          }}
                          value={promoCode}
                        />
                      </Form.Group>
                      <Button
                        variant=""
                        onClick={applyPromoCode}
                        className="WL_card_submitbtn"
                        disabled={promoCode == "" ? true : false}
                      >
                        apply
                      </Button>
                    </div>
                    {/* </Form> */}
                  </div>
                  {/* ///promo code end/// */}

                  {/* ///amount paid display start/// */}

                  <div className="WL_paid_wrp">
                    <div className="WL_textleft">Amount to be paid Now</div>

                    <div className="WL_textright">
                      {/* {applyHotelOffers != null
                        ? applyHotelOffers?.data?.amount_to_be_paid_now
                        : hourlyCheckoutDetails?.data?.payment_summery_details
                            ?.amount_to_be_paid_now}{" "}
                      {applyHotelOffers != null
                        ? applyHotelOffers?.data?.currency
                        : hourlyCheckoutDetails?.data?.payment_summery_details
                            ?.currency} */}
                      {applyHotelOffers !== null &&
                      "data" in applyHotelOffers &&
                      "amount_to_be_paid_now" in applyHotelOffers.data
                        ? Number(
                            applyHotelOffers.data.amount_to_be_paid_now *
                              currencyToShow.convertedRates
                          ).toFixed(2)
                        : ""}
                      {applyHotelOffers === null &&
                      hourlyCheckoutDetails &&
                      "data" in hourlyCheckoutDetails &&
                      "payment_summery_details" in hourlyCheckoutDetails.data &&
                      "amount_to_be_paid_now" in
                        hourlyCheckoutDetails.data.payment_summery_details
                        ? Number(
                            hourlyCheckoutDetails.data.payment_summery_details
                              .amount_to_be_paid_now *
                              currencyToShow.convertedRates
                          ).toFixed(2)
                        : ""}
                      {" " + currencyToShow.current}
                    </div>
                  </div>
                  {/* ///amount paid display end/// */}

                  <h4 className="WL_personalheading">Pay Now </h4>

                  <div className="WL_creditradio_mwrp">
                    {/* <Form> */}
                    <Form.Group
                      className="WL-custmpayradio"
                      controlId="formPayRadio"
                    >
                      <Form.Check
                        type="radio"
                        checked={paymentModeValue === "card"}
                        name="paynowcreditcard"
                        id="paynowcreditcard"
                        label="Credit Card or Debit Card"
                        onChange={handlePaymentMode}
                        value={"card"}
                      />
                      <Form.Check
                        type="radio"
                        name="paynowcreditcard"
                        id="paynowathotel"
                        label="Pay at Hotel"
                        checked={paymentModeValue === "cash"}
                        value={"cash"}
                        onChange={handlePaymentMode}
                      />
                    </Form.Group>
                    {/* </Form> */}
                  </div>
                  <div className="WL_cc_cardicon">
                    <img src="./img/Paypal.svg" alt="" />
                    <img src="./img/Visa.svg" alt="" />
                    <img src="./img/mastercard.svg" alt="" />
                    <img src="./img/mada.svg" alt="" />
                    <img src="./img/Stc_pay.svg" alt="" />
                  </div>

                  <div className="WL_creditfrmcont_mwrp">
                    {/* <Form> */}
                    {paymentModeValue === "cash" ? (
                      ""
                    ) : (
                      <CheckoutCardDetailsForm
                        cardData={cardData}
                        cardDataError={cardDataError}
                        handleCardDetailsChange={handleCardDetailsChange}
                        handleChangeCardNumber={handleChangeCardNumber}
                        handleChangeExpiryDate={handleChangeExpiryDate}
                        handleChangeCardType={handleChangeCardType}
                        cardnumberRef={cardnumberRef}
                        nameoncardRef={nameoncardRef}
                        expirydateRef={expirydateRef}
                        securitycodeRef={securitycodeRef}
                        selectedCardTypeRef={selectedCardTypeRef}
                        zipcodeRef={zipcodeRef}
                      />
                    )}
                    <Form.Group
                      className="form-checkbox WL_checkbx_crdcard"
                      controlId="formCheckoutAgree"
                    >
                      <Form.Check
                        type="checkbox"
                        label={
                          <>
                            I agree to the{" "}
                            <Link to="/terms&conditions">
                              Terms and Conditions
                            </Link>{" "}
                            and{" "}
                            <Link to="privacy-policy">Privacy Policies</Link> of
                            wfrlee.
                          </>
                        }
                        checked={cardData.termsandConditions}
                        onChange={handletermspolicy}
                      />
                      <br />
                      <Form.Text className="text-muted">
                        {cardDataError.termsandConditionsErr}
                      </Form.Text>
                    </Form.Group>
                    <Button variant="" type="submit" className="formsubmit">
                      Confirm and Pay
                    </Button>
                    {/* </Form> */}
                  </div>
                </div>

                {/* ///promo code wrapper  end/// */}
              </Form>
            </div>
            {/* ///Checkout right content start/// */}
          </div>
        </div>

        <ConfirmDialog
          setShowConfirmDialog={setShowConfirmDialog}
          isOpen={showConfirmDialog}
          caption={hotelBooking != null ? "Booking Confirmed Successfully" : ""}
          description={
            <p>
              Your Booking no. is{" "}
              <strong>
                {hotelBooking != null ? hotelBooking?.data?.booking_number : ""}
              </strong>{" "}
              for hotel{" "}
              <strong>
                {hotelBooking != null
                  ? hotelBooking?.data?.hotel_details?.name
                  : ""}
              </strong>
            </p>
          }
          confirmButtonLabel="View Booking Details"
          continueButtonLabel="Go to Home"
          confirmButtonHandler={viewBookingDetailsHandler}
          bookingData={hotelBooking != null ? hotelBooking : null}
          cancelButtonHandler={() => {
            setShowConfirmDialog(false);
            navigate("/");
            stateClearAfterTask();
          }}
        />

        <BookingDetailsDialog
          setShowDialog={setShowBookingDetailsModal}
          isOpen={showBookingDetailsModal}
          bookingData={hotelBooking != null ? hotelBooking.data : null}
          cancelButtonLabel={"Close"}
          cancelDialogHandler={() => {
            setShowBookingDetailsModal(false);
            navigate(-1);
            stateClearAfterTask();
          }}
        />
        <LoginModal
          show={showLoginPopup}
          handleClose={handleCloseLoginPopup}
          search_type={hourlyCheckoutDetails?.data?.request_data?.search_type}
        >
          <LoginPage
            handleCloseLoginPopup={handleCloseLoginPopup}
            search_type={hourlyCheckoutDetails?.data?.request_data?.search_type}
          />
        </LoginModal>
      </div>
      {/* //////////Checkout main content end/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  hourlyCheckoutDetails: selectHourlyCheckoutDetails,
  hotelBooking: selectHotelBooking,
  languageToShow: selectlanguageToShow,
  userAuthData: selectUserLoginData,
  applyHotelOffers: selectApplyHotelOffers,
  saveGuestUserCheckoutData: selectSaveGuestUserCheckoutData,
  currencyToShow: selectcurrencyToShow,
  searchsavedData: selectFavouriteHotelSearchData,
  applyHotelOffersFailedData: selectApplyHotelOffersFailedData,
  validateUserEmail: selectValidateUserEmailData,
});
const mapDispatchToProps = (dispatch) => ({
  getHourlyCheckoutDetailsRequest: (data) =>
    dispatch(getHourlyCheckoutDetailsRequest(data)),
  hotelBookingRequest: (data) => dispatch(hotelBookingRequest(data)),
  applyHotelOffersRequest: (data) => dispatch(applyHotelOffersRequest(data)),
  stateClearAfterTask: () => dispatch(stateClearAfterTask()),
  saveGuestUserCheckoutDataRequest: (data) =>
    dispatch(saveGuestUserCheckoutDataRequest(data)),
  hotelWheatherApiRequest: (data) => dispatch(hotelWheatherApiRequest(data)),
  validateUserEmailRequest: (data) => dispatch(validateUserEmailRequest(data)),
  validateEmailStateClearAfterTask: () =>
    dispatch(validateEmailStateClearAfterTask()),
});
export default connect(mapStateToProps, mapDispatchToProps)(HourlyGuestUser);
