import React, { useEffect, useState, useRef } from "react";
import { Button, Dropdown, Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import { AiOutlineEye } from "react-icons/ai";
import { AiOutlineEyeInvisible } from "react-icons/ai";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { createStructuredSelector } from "reselect";
import { connect } from "react-redux";
import {
  ResetPasswordStart,
  ProfileDataUpdateRequest,
  ProfileImageUpdateRequest,
  stateClearAfterTask,
  UserProfileDetailsRequest,
} from "./../../redux/user/user.actions";
import { selectLanguage } from "./../../redux/language/language.actions";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import {
  selectCurrentUser,
  selectUserProfileMessage,
  selectUserResetPassword,
} from "./../../redux/user/user.selectors";
import Countries from "./../../assets/country-data/countrydata.json";
import DefaultImage from "./../../assets/images/istockphoto-1341046662-612x612.jpg";

import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const MyprofilePage = ({
  ResetPasswordStart,
  languageToShow,
  selectCurrentUser,
  ProfileDataUpdateRequest,
  ProfileImageUpdateRequest,
  selectUserProfileMessage,
  stateClearAfterTask,
  UserProfileDetailsRequest,
  resetPasswordData,
}) => {
  const [show, setShow] = useState(false);
  const inputRef = useRef();
  const [imageFile, setImageFile] = useState("");
  function handleShowChanePasswrd() {
    setShow(!show);
  }
  // const [eye, seteye] = useState(false);
  const [eyes, setEyes] = useState({
    oldpassword: false,
    password: false,
    confirmpassword: false,
  });
  const [userData, setUserData] = useState({
    oldpassword: "",
    password: "",
    confirmPassword: "",
  });
  const [userDataError, setuserDataError] = useState({
    oldpasswordErr: "",
    passwordErr: "",
    confirmPasswordErr: "",
  });
  const [userProfileData, setUserProfileData] = useState({
    first_name: selectCurrentUser.first_name,
    last_name: selectCurrentUser.last_name,
    contact_no: selectCurrentUser.contact_no,
    country_code: selectCurrentUser.country_code,
    profile_image: selectCurrentUser.profile_image,
  });
  const [profieDataError, setProfieDataError] = useState({
    first_name_error: "",
    last_name_error: "",
    contact_no_error: "",
    country_code_error: "",
  });

  const handleChange = (e) => {
    //console.log("eerrrww",e.target.name,e.target.value)
    if (e.target.name == "oldpassword") {
      setuserDataError({
        ...userDataError,
        oldpasswordErr: "",
      });
    } else if (e.target.name == "password") {
      setuserDataError({
        ...userDataError,
        passwordErr: "",
      });
    } else if (e.target.name == "confirmPassword") {
      setuserDataError({
        ...userDataError,
        confirmPasswordErr: "",
      });
    }
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  /*** Country Code Selection   ***/
  const handleCountryCodeChange = (value, data, event, formattedValue) => {
    console.log("data.dialCode", data.dialCode);
    if (data.dialCode == "") {
      setUserProfileData({
        ...userProfileData,
        country_code: "",
      });
    } else {
      setUserProfileData({
        ...userProfileData,
        country_code: formattedValue,
      });
      setProfieDataError({
        ...profieDataError,
        country_code_error: "",
      });
    }
  };

  const handleResetPasswordSubmit = (e) => {
    e.preventDefault();
    if (userData.oldpassword == "") {
      setuserDataError({
        ...userDataError,
        oldpasswordErr: "Please Enter Your Old Password",
      });
      return;
    } else if (userData.oldpassword.length < 8) {
      setuserDataError({
        ...userDataError,
        oldpasswordErr: "Atleast 8 characters are required",
      });
      return;
    } else if (userData.password == "") {
      setuserDataError({
        ...userDataError,
        passwordErr: "Please Enter Your Password",
      });
      return;
    } else if (userData.password.length < 8) {
      setuserDataError({
        ...userDataError,
        passwordErr: "Atleast 8 characters are required",
      });
      return;
    } else if (userData.confirmPassword == "") {
      setuserDataError({
        ...userDataError,
        confirmPasswordErr: "Please Enter Your Confirm Password",
      });
      return;
    } else if (userData.confirmPassword != userData.password) {
      setuserDataError({
        ...userDataError,
        confirmPasswordErr: "Confirm Password and Password are not same",
      });
      return;
    } else {
      var data = {
        current_password: userData.oldpassword,
        new_password: userData.password,
        confirm_password: userData.confirmPassword,
      };
      ResetPasswordStart(data);
      if (resetPasswordData != null) {
        if (resetPasswordData?.success == true) {
          setUserData({
            oldpassword: "",
            password: "",
            confirmPassword: "",
          });
        }
      } else {
      }
    }
  };

  const handleChaneProfiledata = (e) => {
    if (e.target.name == "first_name") {
      setProfieDataError({
        ...profieDataError,
        first_name_error: "",
      });
    } else if (e.target.name == "last_name") {
      setProfieDataError({
        ...profieDataError,
        last_name_error: "",
      });
    } else {
      setProfieDataError({
        ...profieDataError,
        contact_no_error: "",
      });
    }
    setUserProfileData({
      ...userProfileData,
      [e.target.name]: e.target.value,
    });
  };

  const handleProfileSubmit = (event) => {
    event.preventDefault();
    if (userProfileData.first_name == "") {
      setProfieDataError({
        ...profieDataError,
        first_name_error: "Please Enter Your First Name",
      });
      return;
    } else if (userProfileData.last_name == "") {
      setProfieDataError({
        ...profieDataError,
        last_name_error: "Please Enter Your Last Name",
      });
      return;
    } else if (userProfileData.contact_no == "") {
      setProfieDataError({
        ...profieDataError,
        contact_no_error: "Please Enter Your Contact Number",
      });
      return;
    } else if (userProfileData.country_code == "") {
      setProfieDataError({
        ...profieDataError,
        country_code_error: "Please Enter Your Country Code",
      });
      return;
    } else {
      if (imageFile != "") {
        const formData = new FormData();
        formData.append("profile-image", userProfileData.profile_image);
        ProfileImageUpdateRequest(formData);
      }
      let datachecking = userProfileData;
      delete datachecking.profile_image;
      // console.log("datachecking", datachecking);
      ProfileDataUpdateRequest(datachecking);
    }
  };

  const handleImageChange = () => {
    setUserProfileData({
      ...userProfileData,
      ["profile_image"]: inputRef.current.files[0],
    });
    var reader = new FileReader();
    reader.onloadend = function () {
      setImageFile(reader.result);
      // console.log('RESULT', reader.result)
    };
    reader.readAsDataURL(inputRef.current.files[0]);
    console.log("RESULT", reader.result);

    //
  };

  useEffect(() => {
    if (selectUserProfileMessage != null) {
      const data = {
        language: languageToShow,
      };
      UserProfileDetailsRequest(data);
      stateClearAfterTask();
    }
  }, [selectUserProfileMessage]);

  console.log("prolieData", selectUserProfileMessage,resetPasswordData);

  const handlepasswordhideshow = (number) => {
    // seteye(!eye);
    if (number == 2) {
      setEyes({
        ...eyes,
        oldpassword: !eyes.oldpassword,
      });
    } else if (number == 3) {
      setEyes({
        ...eyes,
        confirmpassword: !eyes.confirmpassword,
      });
    } else {
      setEyes({
        ...eyes,
        password: !eyes.password,
      });
    }
  };

  return (
    <>
      {/* //////////Myprofile page Section/////////// */}
      <div className="myaccountpage">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="account-titlearea">
                <h2>My Account </h2>
                <p>Manage your wfrlee.com experience</p>
              </div>
            </div>
            <div className="col-md-12">
              <div className="accounttotalsection">
                <ul className="leftmenu">
                  <li className="active">
                    <Link to="/myaccount">My Profile</Link>
                  </li>
                  <li>
                    <Link to="/mybooking">My Bookings</Link>
                  </li>
                  <li>
                    <Link to="/mybidding">My Biddings</Link>
                  </li>
                  <li>
                    <Link to="/favorites">My Favorites</Link>
                  </li>
                  <li>
                    <Link to="/mypoints">My Points</Link>
                  </li>
                  <li>
                    <Link to="/mywallet">My Wallet</Link>
                  </li>
                  <li>
                    <Link to="/myreferrals">My Referrals</Link>
                  </li>
                  <li>
                    <Link to="/notification">Notifications</Link>
                  </li>
                </ul>
                <div className="rightsection">
                  <h1 style={show ? { display: "none" } : { display: "block" }}>
                    My Profile
                  </h1>
                  <div className="customform">
                    <Form
                      style={show ? { display: "none" } : { display: "block" }}
                      onSubmit={handleProfileSubmit}
                    >
                      <div className="form50">
                        <Form.Group controlId="formBasicFirstname">
                          <Form.Label>Name *</Form.Label>
                          <Form.Control
                            type="text"
                            value={userProfileData.first_name}
                            onChange={handleChaneProfiledata}
                            name="first_name"
                            placeholder="First Name"
                          />
                          <Form.Text className="text-muted errorformmessage">
                            {profieDataError.first_name_error}
                          </Form.Text>
                          {/* {profieDataError.first_name_error} */}
                        </Form.Group>
                        <Form.Group
                          className="lastname"
                          controlId="formBasicLastname"
                        >
                          <Form.Label>Last Name *</Form.Label>
                          <Form.Control
                            type="text"
                            value={userProfileData.last_name}
                            onChange={handleChaneProfiledata}
                            name="last_name"
                            placeholder="Last Name"
                          />
                          <Form.Text className="text-muted errorformmessage">
                            {profieDataError.last_name_error}
                          </Form.Text>
                          {/* {profieDataError.last_name_error} */}
                        </Form.Group>
                      </div>
                      <div className="form50 countryCodePhoneDiv">
                        <Form.Group controlId="formBasicCountryCode">
                          <Form.Label>Country Code *</Form.Label>
                          {/* <Form.Select aria-label="Default select example" name="country_code" onChange={handleChaneProfiledata} className="form-control">
                                                    <option>Select Country Code</option>
                                                    {
                                                        Countries.map((country) => {
                                                            return (
                                                                <option value={country.phone_code} selected={country.phone_code == userProfileData.country_code ? true : false}  >{country.emoji} {country.name} </option>
                                                            )
                                                        })
                                                    }
                                                </Form.Select> */}
                          <Form.Group controlId="formCheckoutCountryCode">
                            <PhoneInput
                              // defaultCountry="IN"
                              autoFormat={false}
                              enableSearch={true}
                              // country={"in"}
                              value={userProfileData.country_code}
                              onChange={handleCountryCodeChange}
                              name="countryCode"
                              placeholder={"+91"}
                              className="checkoutcountryCodeInput countryCodeInput"
                            />
                          </Form.Group>
                          <Form.Text className="text-muted errorformmessage">
                            {profieDataError.country_code_error}
                          </Form.Text>
                        </Form.Group>

                        <Form.Group controlId="formBasicPhone">
                          <Form.Label>Mobile Number *</Form.Label>
                          <Form.Control
                            type="tel"
                            className="form-control"
                            value={userProfileData.contact_no}
                            onChange={handleChaneProfiledata}
                            placeholder="Enter Your Phone No"
                            name="contact_no"
                          />
                          <Form.Text className="text-muted errorformmessage">
                            {profieDataError.contact_no_error}
                          </Form.Text>
                        </Form.Group>
                      </div>

                      <Form.Group controlId="formBasicProfileImage">
                        <div className="profilepic">
                          <Form.Label>Profile Image</Form.Label>
                          <img
                            src={
                              imageFile != ""
                                ? imageFile
                                : userProfileData.profile_image != ""
                                ? userProfileData.profile_image
                                : DefaultImage
                            }
                            style={{
                              width: "100px",
                              height: "100px",
                              borderRadius: "50%",
                            }}
                          />
                          <Form.Control
                            type="file"
                            className="form-control"
                            ref={inputRef}
                            onChange={handleImageChange}
                            placeholder="Please Select Image"
                            name="profile-image"
                          />
                          {/* {profieDataError.contact_no_error} */}
                        </div>
                      </Form.Group>
                      <Form.Group controlId="formBasicEmail">
                        <Form.Label>Email id</Form.Label>
                        <Form.Text className="text-email">
                          {selectCurrentUser.email}
                        </Form.Text>
                      </Form.Group>

                      <Button
                        variant="primary"
                        type="submit"
                        className="formsubmit"
                      >
                        Save
                      </Button>
                    </Form>

                    <p
                      className="text-center pt-30"
                      style={
                        show
                          ? { display: "none", cursor: "pointer" }
                          : { display: "block", cursor: "pointer" }
                      }
                      onClick={handleShowChanePasswrd}
                    >
                      Change Your Password
                    </p>

                    <div
                      style={show ? { display: "block" } : { display: "none" }}
                    >
                      <h1>Change Password</h1>

                      <Form onSubmit={handleResetPasswordSubmit}>
                        {/* <div className="form50"> */}
                        <Form.Group controlId="formBasicOldPassword">
                          <Form.Label>Old Password *</Form.Label>
                          <span className="passwordsec">
                            <Form.Control
                              type={eyes.oldpassword ? "text" : "password"}
                              placeholder="Old Password"
                              onChange={handleChange}
                              name="oldpassword"
                              value={userData.oldpassword}
                            />
                            {eyes.oldpassword ? (
                              <AiOutlineEye
                                onClick={() => {
                                  handlepasswordhideshow(2);
                                }}
                              />
                            ) : (
                              <AiOutlineEyeInvisible
                                onClick={() => {
                                  handlepasswordhideshow(2);
                                }}
                              />
                            )}
                            <Form.Text className="text-muted errorformmessage">
                              {userDataError.oldpasswordErr}
                            </Form.Text>
                          </span>
                        </Form.Group>

                        {/* </div> */}
                        <Form.Group controlId="formBasicPassword">
                          <Form.Label>Password *</Form.Label>
                          <span className="passwordsec">
                            <Form.Control
                              type={eyes.password ? "text" : "password"}
                              placeholder="Password"
                              onChange={handleChange}
                              name="password"
                              value={userData.password}
                            />
                            {eyes.password ? (
                              <AiOutlineEye
                                onClick={() => {
                                  handlepasswordhideshow();
                                }}
                              />
                            ) : (
                              <AiOutlineEyeInvisible
                                onClick={() => {
                                  handlepasswordhideshow();
                                }}
                              />
                            )}
                            <Form.Text className="text-muted errorformmessage">
                              {userDataError.passwordErr}
                            </Form.Text>
                          </span>
                        </Form.Group>
                        <Form.Group controlId="formBasicConfirmPassword">
                          <Form.Label>Confirm Password *</Form.Label>
                          <span className="passwordsec">
                            <Form.Control
                              type={eyes.confirmpassword ? "text" : "password"}
                              placeholder="Confirm Password"
                              onChange={handleChange}
                              name="confirmPassword"
                              value={userData.confirmpassword}
                            />
                            {eyes.confirmpassword ? (
                              <AiOutlineEye
                                onClick={() => {
                                  handlepasswordhideshow(3);
                                }}
                              />
                            ) : (
                              <AiOutlineEyeInvisible
                                onClick={() => {
                                  handlepasswordhideshow(3);
                                }}
                              />
                            )}
                            <Form.Text className="text-muted errorformmessage">
                              {userDataError.confirmPasswordErr}
                            </Form.Text>
                          </span>
                        </Form.Group>

                        <Button
                          variant="primary"
                          type="submit"
                          className="formsubmit"
                        >
                          Change Password
                        </Button>
                      </Form>
                    </div>
                    <button
                      className="formback"
                      style={show ? { display: "block" } : { display: "none" }}
                      onClick={handleShowChanePasswrd}
                    >
                      {" "}
                      Back{" "}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Myprofile page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  selectCurrentUser: selectCurrentUser,
  selectUserProfileMessage: selectUserProfileMessage,
  resetPasswordData: selectUserResetPassword,
});
const mapDispatchToProps = (dispatch) => ({
  selectLanguage: (data) => dispatch(selectLanguage(data)),
  ResetPasswordStart: (data) => dispatch(ResetPasswordStart(data)),
  ProfileDataUpdateRequest: (data) => dispatch(ProfileDataUpdateRequest(data)),
  ProfileImageUpdateRequest: (data) =>
    dispatch(ProfileImageUpdateRequest(data)),
  UserProfileDetailsRequest: (data) =>
    dispatch(UserProfileDetailsRequest(data)),
  stateClearAfterTask: () => dispatch(stateClearAfterTask()),
});

export default connect(mapStateToProps, mapDispatchToProps)(MyprofilePage);
