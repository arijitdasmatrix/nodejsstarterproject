import React, { useEffect } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import {
  Link,
  useLocation,
  useNavigate,
  createSearchParams,
} from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { createStructuredSelector } from "reselect";
import { connect } from "react-redux";
import { selectLanguage } from "./../../redux/language/language.actions";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { bidingGetDataStart } from "./../../redux/useraccount/useraccount.actions";
import { selectUserAccountBidingData } from "./../../redux/useraccount/useraccount.selectors";
import moment from "moment";
//import TablePagination from "@mui/material/TablePagination";
import Pagination from "@mui/material/Pagination";
import {
  selectUserLoginData,
  selectSocialLoginUser,
} from "../../redux/user/user.selectors";

const MybiddingsPage = ({
  bidingGetDataStart,
  selectUserAccountBidingData,
  languageToShow,
  userAuthData,
}) => {
  const [page, setPage] = React.useState(1);
  const [rowsPerPage, setRowsPerPage] = React.useState(3);
  const location = useLocation();
  const navigate = useNavigate();

  const perPageLimit = 3;
  useEffect(() => {
    const data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
      skip: page,
      limit: perPageLimit,
    };
    bidingGetDataStart(data);
    setPage(1);
    setRowsPerPage(perPageLimit);
  }, [languageToShow]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    const data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
      skip: newPage,
      limit: perPageLimit,
    };
    bidingGetDataStart(data);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const gotoHotelDetails = (slug, cityname) => {
    var checkinDate = new Date();
    checkinDate.setDate(checkinDate.getDate() + 1);
    var checkoutDate = new Date();
    checkoutDate.setDate(checkoutDate.getDate() + 2);

    if (location.pathname == `/hotel-details/${slug}`) {
      navigate({
        pathname: location.pathname,
        search: createSearchParams({
          search_type: "bid",
          city: cityname,
          check_in_date: moment(checkinDate).format("DD/MM/YYYY"),
          check_out_date: moment(checkoutDate).format("DD/MM/YYYY"),
          // check_in_date: "" + year + "-" + month + "-" + (day + 1) + "",
          // check_out_date: "" + year + "-" + month + "-" + (day + 2) + "",
          adults: "1",
          children: "1",
          rooms: "1",
        }).toString(),
      });
    } else {
      navigate(
        {
          pathname: `/hotel-details/${slug}`,
          search: createSearchParams({
            search_type: "bid",
            city: cityname,
            check_in_date: moment(checkinDate).format("DD/MM/YYYY"),
            check_out_date: moment(checkoutDate).format("DD/MM/YYYY"),
            // check_in_date: "" + year + "-" + month + "-" + (day + 1) + "",
            // check_out_date: "" + year + "-" + month + "-" + (day + 2) + "",
            adults: "1",
            children: "1",
            rooms: "1",
          }).toString(),
        },
        { replace: false }
      );
    }
  };

  return (
    <>
      {/* Header Section */}

      <>{console.log("MyBiddings comp", selectUserAccountBidingData)}</>

      {/* //////////Myprofile page Section/////////// */}
      <div className="myaccountpage">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="account-titlearea">
                <h2>My Account </h2>
                <p>Manage your wfrlee.com experience</p>
              </div>
            </div>
            <div className="col-md-12">
              <div className="accounttotalsection">
                <ul className="leftmenu">
                  <li>
                    <Link to="/myaccount">My Profile</Link>
                  </li>
                  <li>
                    <Link to="/mybooking">My Bookings</Link>
                  </li>
                  <li className="active">
                    <Link to="/mybidding">My Biddings</Link>
                  </li>
                  <li>
                    <Link to="/favorites">My Favorites</Link>
                  </li>
                  <li>
                    <Link to="/mypoints">My Points</Link>
                  </li>
                  <li>
                    <Link to="/mywallet ">My Wallet</Link>
                  </li>
                  <li>
                    <Link to="/myreferrals">My Referrals</Link>
                  </li>
                  <li>
                    <Link to="/notification">Notifications</Link>
                  </li>
                </ul>
                <div className="rightsection">
                  <h1>My Biddings</h1>
                  <div className="accountbooking">
                    {selectUserAccountBidingData != null ? (
                      <>
                        {(selectUserAccountBidingData.data || []).map(
                          (data, index) => {
                            return (
                              <div className="bookingbox" key={index}>
                                <div className="bookingboxlft">
                                  <h3
                                    // onClick={() => {
                                    //   gotoHotelDetails(
                                    //     data.hotel_details.slug,
                                    //     data.hotel_details.address.city_village
                                    //   );
                                    // }}
                                  > {data?.hotel_details?.name}</h3>
                                  <p>
                                    {" "}
                                    {data?.hotel_details?.address.district}{" "}
                                    <br />
                                    <span>
                                      {
                                        data?.hotel_details?.address
                                          .address_line1
                                      }
                                    </span>
                                    {data?.hotel_details?.address
                                      .address_line2 && (
                                      <span>
                                        ,{" "}
                                        {
                                          data?.hotel_details?.address
                                            .address_line2
                                        }
                                        ,{" "}
                                      </span>
                                    )}{" "}
                                    {data?.hotel_details?.address
                                      .city_village && (
                                      <span>
                                        {
                                          data?.hotel_details?.address
                                            .city_village
                                        }{" "}
                                        -
                                      </span>
                                    )}
                                    <span>
                                      {" "}
                                      {data?.hotel_details?.address.pincode}
                                    </span>
                                  </p>
                                  <p>{data?.hotel_details?.address.country}</p>
                                  {/* <h3>Mansard Dubai, a Radisson Collection Hotel</h3> */}
                                  {/* <p>
                              {" "}
                              {Dubai} <br />
                              22nd St, PO Box 39 39 71, Dubai, Dubai PO Box 39
                            </p> */}
                                </div>
                                <div className="bidarea">
                                  <div className="bookingboxmid">
                                    <p>
                                      {" "}
                                      <label>Date of Bidding</label>
                                      <br />{" "}
                                      <span>
                                        {/* 15 Dec, 2022{" "} */}
                                        {moment(data?.createdAt).format(
                                          "DD MMM, YYYY"
                                        )}
                                      </span>
                                      {/* moment(assessmentData?.measuredDate).format('DD MMMM YY') */}
                                    </p>
                                  </div>
                                  <div className="bookingboxmid bidprice">
                                    <p>
                                      {" "}
                                      <label>Bid Price</label>
                                      <br />{" "}
                                      <span>AED {data?.bid_offered}</span>
                                    </p>
                                  </div>
                                  <div className="bookingboxmid bidstatus">
                                    <p>
                                      {" "}
                                      <label>Status</label>{" "}
                                      {data?.biding_status === 1 && (
                                        <span className="acceptcolor">
                                          Accepted
                                        </span>
                                      )}
                                      {data?.biding_status === 6 && (
                                        <span className="pendingcolor">
                                          Pending
                                        </span>
                                      )}
                                      {data?.biding_status === 2 && (
                                        <span className="rejectcolor">
                                          Rejected
                                        </span>
                                      )}
                                    </p>
                                  </div>
                                </div>
                                <div className="bookingboxrgt">
                                  <Link to="#" className="gen-btn">
                                    Re-send Confirmation
                                  </Link>
                                  <Link to="#" className="gen-btn">
                                    Share Confirmation
                                  </Link>
                                </div>
                              </div>
                            );
                          }
                        )}
                      </>
                    ) : (
                      // If no data
                      <div className="bookingbox">
                        <div className="bookingboxlft">
                          <h3>No Data Found...</h3>
                        </div>
                      </div>
                    )}
                    {/* static data */}
                    {/* <div className="bookingbox">
                        <div className="bookingboxlft">
                          <h3>Mansard Dubai, a Radisson Collection Hotel</h3>
                          <p>
                            {" "}
                            Dubai <br />
                            22nd St, PO Box 39 39 71, Dubai, Dubai PO Box 39
                          </p>
                        </div>
                        <div className="bidarea">
                          <div className="bookingboxmid">
                            <p>
                              {" "}
                              <label>Date of Bidding</label>
                              <br /> <span>15 Dec, 2022</span>
                            </p>
                          </div>
                          <div className="bookingboxmid bidprice">
                            <p>
                              {" "}
                              <label>Bid Price</label>
                              <br /> <span>AED 600</span>
                            </p>
                          </div>
                          <div className="bookingboxmid bidstatus">
                            <p>
                              {" "}
                              <label>Status</label>{" "}
                              <span className="acceptcolor">Accepted</span>
                            </p>
                          </div>
                        </div>
                        <div className="bookingboxrgt">
                          <Link to="#" className="gen-btn">
                            Re-send Confirmation
                          </Link>
                          <Link to="#" className="gen-btn">
                            Share Confirmation
                          </Link>
                        </div>
                      </div> */}
                    <Pagination
                      boundaryCount={1}
                      count={
                        selectUserAccountBidingData != null
                          ? Math.ceil(
                              selectUserAccountBidingData?.total_count /
                                perPageLimit
                            )
                          : 0
                      }
                      defaultPage={1}
                      onChange={handleChangePage}
                      page={page}
                      showFirstButton={true}
                      showLastButton={true}
                    />
                    {/* <TablePagination
                      rowsPerPageOptions={[3, 5, 10]}
                      component="div"
                      count={
                        selectUserAccountBidingData != null
                          ? selectUserAccountBidingData?.total_count
                          : 0
                      }
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    /> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Myprofile page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  selectUserAccountBidingData: selectUserAccountBidingData,
  userAuthData: selectUserLoginData,
  userSocialAuthData: selectSocialLoginUser,
});
const mapDispatchToProps = (dispatch) => ({
  bidingGetDataStart: (data) => dispatch(bidingGetDataStart(data)),
  selectLanguage: (data) => dispatch(selectLanguage(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(MybiddingsPage);
