import React from "react";
import { Dropdown, Tabs, Tab,Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import {
  getMyWalletPointsDataStart,
  getMyWalletListDataStart,
  buyWalletPointsRequest,
  getAllLoyaltyPointsRequest
} from "../../redux/useraccount/useraccount.actions";
import {
  selectMyWalletPointsData,
  selectMyWalletListData,
  selectAllLoyaltyPointsData
} from "../../redux/useraccount/useraccount.selectors";
import {
  selectUserLoginData,
  selectSocialLoginUser,
} from "../../redux/user/user.selectors";
import { selectlanguageToShow } from "../../redux/language/language.selectors";
import moment from "moment";
import TablePagination from "@mui/material/TablePagination";
import { errorToast } from "../../utils/toastHelper";

const MypointsPage = ({
  myWalletListData,
  // myWalletPointsData,
  // getMyWalletPointsDataStart,
  getMyWalletListDataStart,
  languageToShow,
  userAuthData,
  loyaltyPointsData,
  buyWalletPointsRequest,
  getAllLoyaltyPointsRequest
}) => {
  const [tabValue, setTabValue] = React.useState("all");
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(3);
  const [showBuyPointsPopup, setShowBuyPointsPopup] = React.useState(false);
  const [pointSelected, setPointSelected] = React.useState(false);
  const [loyaltyId, setLoyaltyId] = React.useState();
  const [loyaltyPointSelected, setLoyaltyPointSelected] = React.useState({});

  React.useEffect(() => {
    getAllLoyaltyPointsRequest(data);
  }, [languageToShow]);

  const popupRef = React.useRef(null);

  const handleClickOutside = (event) => {
    if (popupRef.current && !popupRef.current.contains(event.target)) {
      setShowBuyPointsPopup(false);
    }
  };

  React.useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, []);



  const handleTabChange = (value) => {
    if (value == "all") {
      setTabValue(value);
    } else if (value == "spent ") {
      setTabValue(value);
    } else if (value == "received") {
      setTabValue(value);
    } else {
      setTabValue(value);
    }
  };

  const data = {
    languageToShow: languageToShow,
    token: userAuthData != null ? userAuthData.token : "",
  };

  React.useEffect(() => {
    var data = {};
    if (tabValue == "all") {
      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        type: tabValue,
      };
      getMyWalletListDataStart(data);
      setPage(0);
      setRowsPerPage(3);
    } else if (tabValue == "spent") {
      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        type: tabValue,
      };
      getMyWalletListDataStart(data);
      setPage(0);
      setRowsPerPage(3);
    } else if (tabValue == "received") {
      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        type: tabValue,
      };
      getMyWalletListDataStart(data);
      setPage(0);
      setRowsPerPage(3);
    } else {
      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        type: tabValue,
      };
      getMyWalletListDataStart(data);
      setPage(0);
      setRowsPerPage(3);
    }
  }, [tabValue]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handlePopupBox = () => {
    setShowBuyPointsPopup(true);
  };

  const getPoints = (data, index) => {
    console.log(data.type, data.id);
    setLoyaltyId(index);
    setPointSelected(!pointSelected);
    setLoyaltyPointSelected(data);
  };

  const buyPointsHandler = () => {
    const postData = {
      loyalty_point_id: loyaltyPointSelected.id,
    };
    const data = {
      postData,
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };

    if (userAuthData != null) {
      buyWalletPointsRequest(data);
      setShowBuyPointsPopup(false);
      setLoyaltyId();
    } else {
      errorToast("Please login first");
    }
  };

  return (
    <>
      {/* //////////Mypoints page Section/////////// */}
      <div className="myaccountpage">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="account-titlearea">
                <h2>My Account </h2>
                <p>Manage your wfrlee.com experience</p>
              </div>
            </div>
            <div className="col-md-12">
              <div className="accounttotalsection">
                <ul className="leftmenu">
                  <li>
                    <Link to="/myaccount">My Profile</Link>
                  </li>
                  <li>
                    <Link to="/mybooking">My Bookings</Link>
                  </li>
                  <li>
                    <Link to="/mybidding">My Biddings</Link>
                  </li>
                  <li>
                    <Link to="/favorites">My Favorites</Link>
                  </li>
                  <li className="active">
                    <Link to="/mypoints">My Points</Link>
                  </li>
                  <li>
                    <Link to="/mywallet">My Wallet</Link>
                  </li>
                  <li>
                    <Link to="/myreferrals">My Referrals</Link>
                  </li>
                  <li>
                    <Link to="/notification">Notifications</Link>
                  </li>
                </ul>
                <div className="rightsection">
                  <h1>My Points</h1>
                  <div className="accountpoint">
                    <div className="pointsarea">
                      <span>
                        My wfrlee Points{" "}
                        <label>
                          {myWalletListData != null
                            ? myWalletListData?.data.total_points
                            : ""}
                        </label>
                      </span>
                      <Link to="/" className="gen-btn">
                        Use Points
                      </Link>
                      <div className="walletdropdown">
                        <Button
                          onClick={handlePopupBox}
                          className={"gen-btn buy-btn"}
                        >
                          Buy Points
                        </Button>
                        <div
                          className={
                            showBuyPointsPopup == true
                              ? " popbox popupFadeIn"
                              : " popbox popupFadeOut"
                          }
                          ref={popupRef}
                        >
                          <h3>
                            <Button
                              className="popclose onClickBtn p-0"
                              onClick={() => {
                                setShowBuyPointsPopup(false);
                                setLoyaltyId();
                              }}
                            >
                              <img src="./img/popclose.svg" alt="" />
                            </Button>
                            Buy Points <span>Get Points in Your wallet</span>
                          </h3>
                          <div className="pointboxarea">
                            {loyaltyPointsData != null ?
                              loyaltyPointsData?.data.map((data, index) => (
                                <div
                                  key={index}
                                  className={
                                    loyaltyId === index
                                      ? "selectedPointsmallbox pointsmallbox"
                                      : " pointsmallbox"
                                  }
                                  onClick={() => getPoints(data, index)}
                                  // style={{
                                  //   background: loyaltyId === index ? 'lightblue' : 'white'
                                  // }}
                                >
                                  {data.type} <span>{data.point_value}</span>{" "}
                                  Points
                                  <Link to="#">
                                    {data.currency}
                                    {data.price}
                                  </Link>
                                </div>
                              )):"No point available..."}
                            
                          </div>

                          <Button
                            className="gen-btn submitBuyPointsBtn"
                            onClick={buyPointsHandler}
                          >
                            Buy Points
                          </Button>
                        </div>
                      </div>
                    </div>
                    <Tabs
                      defaultActiveKey={tabValue}
                      id="booking-tab"
                      className="bookingtab"
                      onSelect={handleTabChange}
                    >
                      <Tab eventKey="all" title="All">
                        {myWalletListData != null &&
                          (rowsPerPage > 0
                            ? myWalletListData?.data.wallet_transactions.slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage
                              )
                            : myWalletListData?.data.wallet_transactions
                          ).map((transaction, index) => (
                            <div className="bookingbox" key={index}>
                              <div className="pointslft">
                                <p className="pointdate">
                                  {" "}
                                  {moment(transaction.date).format("ll")}
                                </p>
                                <p>
                                  <Link to="#">
                                    {transaction.status == "spent"
                                      ? "Spent on Hotel Booking"
                                      : "Wfrlee Points Added"}
                                  </Link>
                                </p>
                                {transaction.status == "spent" ? (
                                  <h3>
                                    Mansard Dubai, a Radisson Hotel
                                    <br />
                                    Dubai
                                  </h3>
                                ) : (
                                  ""
                                )}
                              </div>
                              <div className="pointsright">
                                {transaction.points} Points
                              </div>
                            </div>
                          ))}
                      </Tab>
                      <Tab eventKey={"received"} title="Received">
                        {myWalletListData != null &&
                          (rowsPerPage > 0
                            ? myWalletListData?.data.wallet_transactions.slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage
                              )
                            : myWalletListData?.data.wallet_transactions
                          ).map((transaction, index) => (
                            <div className="bookingbox" key={index}>
                              <div className="pointslft">
                                <p className="pointdate">
                                  {" "}
                                  {moment(transaction.date).format("ll")}
                                </p>
                                <p>
                                  <Link to="#">Wfrlee Points Added</Link>
                                </p>
                                {transaction.status == "spent" ? (
                                  <h3>
                                    Mansard Dubai, a Radisson Hotel
                                    <br />
                                    Dubai
                                  </h3>
                                ) : (
                                  ""
                                )}
                              </div>
                              <div className="pointsright">
                                {transaction.points} Points
                              </div>
                            </div>
                          ))}
                      </Tab>
                      <Tab eventKey="spent" title="Spent">
                        {myWalletListData != null &&
                          (rowsPerPage > 0
                            ? myWalletListData?.data.wallet_transactions.slice(
                                page * rowsPerPage,
                                page * rowsPerPage + rowsPerPage
                              )
                            : myWalletListData?.data.wallet_transactions
                          ).map((transaction, index) => (
                            <div className="bookingbox" key={index}>
                              <div className="pointslft">
                                <p className="pointdate">
                                  {" "}
                                  {moment(transaction.date).format("ll")}
                                </p>
                                <p>
                                  <Link to="#">Spent on Hotel Booking</Link>
                                </p>
                                {transaction.status == "spent" ? (
                                  <h3>
                                    Mansard Dubai, a Radisson Hotel
                                    <br />
                                    Dubai
                                  </h3>
                                ) : (
                                  ""
                                )}
                              </div>
                              <div className="pointsright">
                                {transaction.points} Points
                              </div>
                            </div>
                          ))}
                      </Tab>
                    </Tabs>

                    <TablePagination
                      rowsPerPageOptions={[3, 5, 10]}
                      component="div"
                      count={
                        myWalletListData != null
                          ? myWalletListData?.data.wallet_transactions.length
                          : 0
                      }
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Mypoints page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  myWalletPointsData: selectMyWalletPointsData,
  myWalletListData: selectMyWalletListData,
  userAuthData: selectUserLoginData,
  userSocialAuthData: selectSocialLoginUser,
  languageToShow: selectlanguageToShow,
  loyaltyPointsData: selectAllLoyaltyPointsData,
});
const mapDispatchToProps = (dispatch) => ({
  getMyWalletPointsDataStart: (data) =>
    dispatch(getMyWalletPointsDataStart(data)),
  getMyWalletListDataStart: (data) => dispatch(getMyWalletListDataStart(data)),
  buyWalletPointsRequest: (data) => dispatch(buyWalletPointsRequest(data)),
  getAllLoyaltyPointsRequest: (data) => dispatch(getAllLoyaltyPointsRequest(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MypointsPage);
