import React from "react";
import { Dropdown, Table } from "react-bootstrap";
import { Link } from "react-router-dom";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import {
  getMyReferralsDetailsStart,
  getMyReferralsListStart,
} from "../../redux/useraccount/useraccount.actions";
import {
  selectMyReferralsDetails,
  selectMyReferralsList,
} from "../../redux/useraccount/useraccount.selectors";
import {
  selectUserLoginData,
  selectSocialLoginUser,
} from "../../redux/user/user.selectors";
import { selectlanguageToShow } from "../../redux/language/language.selectors";
// import { GrFacebookOption } from "react-icons/gr";
// import { GrTwitter } from "react-icons/gr";
// import { GrLinkedinOption } from "react-icons/gr";
// import { GrInstagram } from "react-icons/gr";
// import { GrYoutube } from "react-icons/gr";
// import { BsWhatsapp } from "react-icons/bs";
// import { BsTelegram } from "react-icons/bs";
import ShareModal from "../../utils/ShareModal";
import TablePagination from "@mui/material/TablePagination";
import { Button } from "react-bootstrap";

const MyreferralsPage = ({
  myReferralsDetails,
  myReferralsList,
  getMyReferralsDetailsStart,
  getMyReferralsListStart,
  languageToShow,
  userAuthData,
}) => {
  const [openSharePopup, setOpenSharePopup] = React.useState(false);
  const [isCopied, setIsCopied] = React.useState(false);
  const [shareCode, setShareCode] = React.useState();
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const data = {
    languageToShow: languageToShow,
    token: userAuthData != null ? userAuthData.token : "",
  };

  // React.useEffect(() => {
  //   getMyReferralsDetailsStart(data);
  // }, [languageToShow]);

  React.useEffect(() => {
    getMyReferralsListStart(data);
    setPage(0);
    setRowsPerPage(5);
  }, [languageToShow]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSharePopup = (shareData) => {
    if (shareData) {
      setShareCode(
        // myReferralsList?.data?.referral_code == shareData
        //   ? `http://wfrlee.demoyourprojects.com/sign-up?referral_code=${shareData}`
        //   : shareData
        shareData
      );
      setOpenSharePopup(!openSharePopup);
    } else {
    }
  };

  const onCopy = React.useCallback((value) => {
    setIsCopied(value);
    setOpenSharePopup(false);
  }, []);

  return (
    <>
      {/* //////////Mypoints page Section/////////// */}
      <div className="myaccountpage">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="account-titlearea">
                <h2>My Account </h2>
                <p>Manage your wfrlee.com experience</p>
              </div>
            </div>
            <div className="col-md-12">
              <div className="accounttotalsection">
                <ul className="leftmenu">
                  <li>
                    <Link to="/myaccount">My Profile</Link>
                  </li>
                  <li>
                    <Link to="/mybooking">My Bookings</Link>
                  </li>
                  <li>
                    <Link to="/mybidding">My Biddings</Link>
                  </li>
                  <li>
                    <Link to="/favorites">My Favorites</Link>
                  </li>
                  <li>
                    <Link to="/mypoints">My Points</Link>
                  </li>
                  <li>
                    <Link to="/mywallet">My Wallet</Link>
                  </li>
                  <li className="active">
                    <Link to="/myreferrals">My Referrals</Link>
                  </li>
                  <li>
                    <Link to="/notification">Notifications</Link>
                  </li>
                </ul>
                <div className="rightsection">
                  <h1>My Referrals</h1>
                  <div className="accountreferral">
                    <div className="referralcodearea">
                      <div className="referralcode">
                        <label>Your Referral Code</label>
                        <span>
                          {myReferralsList != null
                            ? myReferralsList?.data?.referral_code
                            : ""}
                        </span>

                        <Button
                          className="onClickBtn"
                          onClick={() =>
                            handleSharePopup(
                              myReferralsList?.data?.referral_code
                            )
                          }
                        >
                          <img src="./img/shareicon.svg" alt="" />
                        </Button>
                      </div>

                      <div className="referralcode referrallink">
                        <label>Your Referral Link</label>
                        <span>
                          {myReferralsList != null
                            ? myReferralsList?.data.referral_link
                            : ""}
                        </span>
                        <Button
                          className="onClickBtn"
                          onClick={() =>
                            handleSharePopup(
                              myReferralsList?.data.referral_link
                            )
                          }
                        >
                          <img src="./img/shareicon.svg" alt="" />
                        </Button>

                        <ShareModal
                          setOpenSharePopup={setOpenSharePopup}
                          openSharePopup={openSharePopup}
                          shareCode={shareCode}
                          setShareCode={setShareCode}
                          onCopy={onCopy}
                          isCopied={isCopied}
                          setIsCopied={setIsCopied}
                          referral_code={myReferralsList?.data?.referral_code}
                        />
                      </div>
                    </div>

                    <div className="accounttable">
                      <Table>
                        <thead>
                          <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Points</th>
                            <th>Active</th>
                          </tr>
                        </thead>
                        <tbody>
                          {myReferralsList != null &&
                            (rowsPerPage > 0
                              ? myReferralsList?.data.referred_transactions.slice(
                                  page * rowsPerPage,
                                  page * rowsPerPage + rowsPerPage
                                )
                              : myReferralsList?.data.referred_transactions
                            ).map((data, index) => (
                              <tr key={index}>
                                <td>{data.first_name}</td>
                                <td>{data.last_name}</td>
                                <td>{data.email}</td>
                                <td>{data.points}</td>
                                <td>{data.active == true ? "Yes" : "No"}</td>
                              </tr>
                            ))}
                        </tbody>
                      </Table>
                      <TablePagination
                        rowsPerPageOptions={[5, 10, 25]}
                        component="div"
                        count={
                          myReferralsList != null
                            ? myReferralsList?.data.referred_transactions.length
                            : 0
                        }
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Mypoints page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  myReferralsDetails: selectMyReferralsDetails,
  myReferralsList: selectMyReferralsList,
  userAuthData: selectUserLoginData,
  userSocialAuthData: selectSocialLoginUser,
});
const mapDispatchToProps = (dispatch) => ({
  getMyReferralsDetailsStart: (data) =>
    dispatch(getMyReferralsDetailsStart(data)),
  getMyReferralsListStart: (data) => dispatch(getMyReferralsListStart(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MyreferralsPage);
