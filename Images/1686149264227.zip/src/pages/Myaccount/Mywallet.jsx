import React from "react";
import { Button, Dropdown, Table, Pagination } from "react-bootstrap";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import {
  getMyWalletListDataStart,
  buyWalletPointsRequest,
  getMyWalletPointsDataStart,
  getAllLoyaltyPointsRequest,
} from "../../redux/useraccount/useraccount.actions";
import {
  selectMyWalletPointsData,
  selectMyWalletListData,
  selectBuyWalletPointsData,
  selectAllLoyaltyPointsData,
} from "../../redux/useraccount/useraccount.selectors";
import {
  selectUserLoginData,
  selectSocialLoginUser,
} from "../../redux/user/user.selectors";
import { selectlanguageToShow } from "../../redux/language/language.selectors";
import moment from "moment";
import { errorToast } from "../../utils/toastHelper";
import TablePagination from "@mui/material/TablePagination";

const MywalletPage = ({
  myWalletPointsData,
  myWalletListData,
  buyWalletPointsData,
  loyaltyPointsData,
  getMyWalletPointsDataStart,
  getMyWalletListDataStart,
  buyWalletPointsRequest,
  getAllLoyaltyPointsRequest,
  languageToShow,
  userAuthData,
}) => {
  const [showBuyPointsPopup, setShowBuyPointsPopup] = React.useState(false);
  const [pointSelected, setPointSelected] = React.useState(false);
  const [loyaltyId, setLoyaltyId] = React.useState();
  const [loyaltyPointSelected, setLoyaltyPointSelected] = React.useState({});

  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const data = {
    languageToShow: languageToShow,
    token: userAuthData != null ? userAuthData.token : "",
  };

  const popupRef = React.useRef(null);

  const handleClickOutside = (event) => {
    if (popupRef.current && !popupRef.current.contains(event.target)) {
      setShowBuyPointsPopup(false);
    }
  };

  React.useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, []);

  React.useEffect(() => {
    var data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
      type: "all",
    };

    getMyWalletListDataStart(data);
    setPage(0);
    setRowsPerPage(5);
  }, [languageToShow]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  React.useEffect(() => {
    getAllLoyaltyPointsRequest(data);
  }, [languageToShow]);

  const handlePopupBox = () => {
    setShowBuyPointsPopup(true);
  };
  const buyPointsHandler = () => {
    const postData = {
      loyalty_point_id: loyaltyPointSelected.id,
    };
    const data = {
      postData,
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };

    if (userAuthData != null) {
      buyWalletPointsRequest(data);
      setShowBuyPointsPopup(false);
      setLoyaltyId();
    } else {
      errorToast("Please login first");
    }
  };

  const getPoints = (data, index) => {
    console.log(data.type, data.id);
    setLoyaltyId(index);
    setPointSelected(!pointSelected);
    setLoyaltyPointSelected(data);
  };

  React.useEffect(() => {
    const data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
      type: "all",
    };
    if (buyWalletPointsData != null) {
      if (buyWalletPointsData.success == true) {
        getMyWalletListDataStart(data);
        setPage(0);
        setRowsPerPage(5);
      } else {
      }
    }
  }, [buyWalletPointsData, languageToShow]);

  return (
    <>
      {/* //////////Mypoints page Section/////////// */}
      <div className="myaccountpage">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="account-titlearea">
                <h2>My Account </h2>
                <p>Manage your wfrlee.com experience</p>
              </div>
            </div>
            <div className="col-md-12">
              <div className="accounttotalsection">
                <ul className="leftmenu">
                  <li>
                    <Link to="/myaccount">My Profile</Link>
                  </li>
                  <li>
                    <Link to="/mybooking">My Bookings</Link>
                  </li>
                  <li>
                    <Link to="/mybidding">My Biddings</Link>
                  </li>
                  <li>
                    <Link to="/favorites">My Favorites</Link>
                  </li>
                  <li>
                    <Link to="/mypoints">My Points</Link>
                  </li>
                  <li className="active">
                    <Link to="/mywallet">My Wallet</Link>
                  </li>
                  <li>
                    <Link to="/myreferrals">My Referrals</Link>
                  </li>
                  <li>
                    <Link to="/notification">Notifications</Link>
                  </li>
                </ul>
                <div className="rightsection">
                  <h1>My Wallet</h1>
                  <div className="accountpoint accountwallet">
                    <div className="pointsarea">
                      <span>
                        My Wallet value{" "}
                        <label>
                          {" "}
                          {myWalletListData != null
                            ? myWalletListData?.data.total_points
                            : 200}{" "}
                          Points
                        </label>
                      </span>
                      <div className="walletdropdown">
                        <Button
                          onClick={handlePopupBox}
                          className={"buyPointBtn"}
                        >
                          Buy Points
                        </Button>
                        <div
                          className={
                            showBuyPointsPopup == true
                              ? " popbox popupFadeIn"
                              : " popbox popupFadeOut"
                          }
                          ref={popupRef}
                        >
                          <h3>
                            <Button
                              className="popclose onClickBtn p-0"
                              onClick={() => {
                                setShowBuyPointsPopup(false);
                                setLoyaltyId();
                              }}
                            >
                              <img src="./img/popclose.svg" alt="" />
                            </Button>
                            Buy Points <span>Get Points in Your wallet</span>
                          </h3>
                          <div className="pointboxarea">
                            {loyaltyPointsData != null
                              ? loyaltyPointsData?.data.map((data, index) => (
                                  <div
                                    key={index}
                                    className={
                                      loyaltyId === index
                                        ? "selectedPointsmallbox pointsmallbox"
                                        : " pointsmallbox"
                                    }
                                    onClick={() => getPoints(data, index)}
                                  >
                                    {data.type} <span>{data.point_value}</span>{" "}
                                    Points
                                    <Link to="#">
                                      {data.currency}
                                      {data.price}
                                    </Link>
                                  </div>
                                ))
                              : "No point available..."}
                          </div>

                          <Button
                            className="gen-btn submitBuyPointsBtn"
                            onClick={buyPointsHandler}
                          >
                            Buy Points
                          </Button>
                        </div>
                      </div>
                    </div>
                    <div className="accounttable">
                      {myWalletListData != null ? (
                        <Table>
                          <thead>
                            <tr>
                              <th>Date</th>
                              <th>Wallet Value</th>
                              <th>Transaction ID</th>
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {(rowsPerPage > 0
                              ? myWalletListData?.data.wallet_transactions.slice(
                                  page * rowsPerPage,
                                  page * rowsPerPage + rowsPerPage
                                )
                              : myWalletListData?.data.wallet_transactions
                            ).map((data, index) => (
                              <tr key={index}>
                                <td> {moment(data.date).format("ll")}</td>
                                <td>{data.points} Points</td>
                                <td>{data.transaction_id}</td>
                                <td className="text-capitalize">
                                  {data.status}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </Table>
                      ) : (
                        <div className="accounttable">
                          <div className="bookingbox">
                            <div className="bookingboxlft">
                              <h3>No Data Found...</h3>
                            </div>
                          </div>
                        </div>
                      )}
                      <TablePagination
                        rowsPerPageOptions={[5, 10, 25]}
                        component="div"
                        count={
                          myWalletListData != null
                            ? myWalletListData?.data.wallet_transactions.length
                            : 0
                        }
                        rowsPerPage={rowsPerPage}
                        page={page}
                        onPageChange={handleChangePage}
                        onRowsPerPageChange={handleChangeRowsPerPage}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Mypoints page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  myWalletPointsData: selectMyWalletPointsData,
  myWalletListData: selectMyWalletListData,
  buyWalletPointsData: selectBuyWalletPointsData,
  loyaltyPointsData: selectAllLoyaltyPointsData,
  languageToShow: selectlanguageToShow,
  userAuthData: selectUserLoginData,
  userSocialAuthData: selectSocialLoginUser,
});
const mapDispatchToProps = (dispatch) => ({
  getMyWalletPointsDataStart: (data) =>
    dispatch(getMyWalletPointsDataStart(data)),
  getMyWalletListDataStart: (data) => dispatch(getMyWalletListDataStart(data)),
  buyWalletPointsRequest: (data) => dispatch(buyWalletPointsRequest(data)),
  getAllLoyaltyPointsRequest: (data) =>
    dispatch(getAllLoyaltyPointsRequest(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MywalletPage);
