import React from "react";
import { Dropdown } from "react-bootstrap";
import { Link } from "react-router-dom";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import {
  getAllFavouriteHotelListRequest,
  addFavouriteHotelRequest,
  removeFavouriteHotelRequest,
} from "../../redux/hotels/hotel.actions";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { selectFavouriteHotelList } from "../../redux/hotels/hotel.selectors";
import { selectUserLoginData } from "../../redux/user/user.selectors";

import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import MyFavouriteHotelList from "../../components/Hotels/MyFavouriteHotelList";
import TablePagination from "@mui/material/TablePagination";
import { errorToast } from "../../utils/toastHelper";

const MyfavoritesPage = ({
  getAllFavouriteHotelListRequest,
  favouriteHotelListData,
  addFavouriteHotelRequest,
  removeFavouriteHotelRequest,
  languageToShow,
  userAuthData,
}) => {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(3);
  const [isAddedFavourite, setIsAddedFavourite] = React.useState();

  var collecSlider = {
    arrows: true,
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  const data = {
    languageToShow: languageToShow,
    token: userAuthData != null ? userAuthData.token : "",
  };

  React.useEffect(() => {
    getAllFavouriteHotelListRequest(data);
    setPage(0);
    setRowsPerPage(3);
    window.scroll(0, 0);
  }, [languageToShow]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // React.useEffect(() => {
  //   setIsAddedFavourite(selectFavouriteHotelList?.data.is_favourite);
  // }, [selectHotelData]);

  const handleFavourite = (hotel_id) => {
    const postData = {
      hotel_id: hotel_id,
    };

    const hotelFavouritesParam = {
      postData,
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };

    if (userAuthData != null) {
      if (hotel_id) {
        removeFavouriteHotelRequest(hotelFavouritesParam);
        setIsAddedFavourite(!isAddedFavourite);
        getAllFavouriteHotelListRequest(data);
      }
      // else {
      //   addFavouriteHotelRequest(hotelFavouritesParam);
      //   setIsAddedFavourite(!isAddedFavourite);
      //   getAllFavouriteHotelListRequest(data);
      // }
    } else {
      errorToast("Please login first");
    }
  };

  return (
    <>
      <>{console.log("favouriteHotelListData", favouriteHotelListData)}</>
      {/* //////////Myprofile page Section/////////// */}
      <div className="myaccountpage">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="account-titlearea">
                <h2>My Account </h2>
                <p>Manage your wfrlee.com experience</p>
              </div>
            </div>
            <div className="col-md-12">
              <div className="accounttotalsection">
                <ul className="leftmenu">
                  <li>
                    <Link to="/myaccount">My Profile</Link>
                  </li>
                  <li>
                    <Link to="/mybooking">My Bookings</Link>
                  </li>
                  <li>
                    <Link to="/mybidding">My Biddings</Link>
                  </li>
                  <li className="active">
                    <Link to="/favorites">My Favorites</Link>
                  </li>
                  <li>
                    <Link to="/mypoints">My Points</Link>
                  </li>
                  <li>
                    <Link to="/mywallet ">My Wallet</Link>
                  </li>
                  <li>
                    <Link to="/myreferrals">My Referrals</Link>
                  </li>
                  <li>
                    <Link to="/notification">Notifications</Link>
                  </li>
                </ul>
                <div className="rightsection">
                  <h1>My Favorites</h1>
                  <div className="accountpoint notificaton">
                    {/* ///review slider content start/// */}

                    {favouriteHotelListData != null ? (
                      <>
                        {(rowsPerPage > 0
                          ? (favouriteHotelListData?.data || []).slice(
                              page * rowsPerPage,
                              page * rowsPerPage + rowsPerPage
                            )
                          : favouriteHotelListData?.data || []
                        ).map((myFavouriteHotelList, index) => (
                          <MyFavouriteHotelList
                            key={index}
                            myFavouriteHotelList={myFavouriteHotelList}
                          />
                        ))}
                      </>
                    ) : (
                      // If no data
                      <div className="WL_right_rivewbox">
                        <div className="WL_collection_left WL_collection_myfavlist_left">
                          <p>No Data Found...</p>
                        </div>
                      </div>
                    )}

                    <TablePagination
                      rowsPerPageOptions={[3, 5, 10]}
                      component="div"
                      count={
                        favouriteHotelListData?.data != null
                          ? favouriteHotelListData?.data?.length
                          : 0
                      }
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Myprofile page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  favouriteHotelListData: selectFavouriteHotelList,
  userAuthData: selectUserLoginData,
});
const mapDispatchToProps = (dispatch) => ({
  getAllFavouriteHotelListRequest: (data) =>
    dispatch(getAllFavouriteHotelListRequest(data)),
  addFavouriteHotelRequest: (data) => dispatch(addFavouriteHotelRequest(data)),
  removeFavouriteHotelRequest: (data) =>
    dispatch(removeFavouriteHotelRequest(data)),
  // selectLanguage: (data) => dispatch(selectLanguage(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MyfavoritesPage);
