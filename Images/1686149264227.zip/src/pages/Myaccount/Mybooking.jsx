import React, { useEffect } from "react";
import { Dropdown, Tabs, Tab, Button } from "react-bootstrap";
import {
  Link,
  useLocation,
  useNavigate,
  createSearchParams,
} from "react-router-dom";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import {
  hotelBookingHistoryRequest,
  hotelResendConfirmationRequest,
} from "./../../redux/hotels/hotel.actions";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { BsChevronDoubleLeft } from "react-icons/bs";
import {
  selectHotelBookingHistoryLoading,
  selectHotelBookingHistoryData,
} from "./../../redux/hotels/hotel.selectors";
import {
  selectUserLoginData,
  selectSocialLoginUser,
} from "../../redux/user/user.selectors";
import moment from "moment/moment";
import Skeleton from "react-loading-skeleton";
import TablePagination from "@mui/material/TablePagination";
import "react-loading-skeleton/dist/skeleton.css";
import ShareModal from "../../utils/ShareModal";
import { cancelBookingRequest } from "../../redux/useraccount/useraccount.actions";
import { selectCancelBookingData } from "../../redux/useraccount/useraccount.selectors";
import PaginationWithDisplay from "../../components/paginationWithDisplay/paginationWithDisplay";

const MybookingPage = ({
  hotelBookingHistoryRequest,
  selectHotelBookingHistoryData,
  languageToShow,
  selectHotelBookingHistoryLoading,
  userAuthData,
  hotelResendConfirmationRequest,
  cancelBookingRequest,
  selectCancelBookingData,
}) => {
  const [tabValue, setTabValue] = React.useState("upcoming");
  // const [page, setPage] = React.useState(0);
  // const [rowsPerPage, setRowsPerPage] = React.useState(3);
  const [openSharePopup, setOpenSharePopup] = React.useState(false);
  const [isCopied, setIsCopied] = React.useState(false);
  const [shareCode, setShareCode] = React.useState();
  const [page, setPage] = React.useState({
    page_no: 1,
    per_page_limit: 3,
    total: 0,
  });
  const location = useLocation();
  const navigate = useNavigate();

  const handleTabChange = (value) => {
    if (value == "upcoming") {
      setTabValue(value);
    } else if (value == "past") {
      setTabValue(value);
    } else if (value == "cancelled") {
      setTabValue(value);
    } else {
      setTabValue(value);
    }
  };

  React.useEffect(() => {
    var data = {};
    if (tabValue == "upcoming") {
      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        filterbystatus: tabValue,
        skip: 1,
        limit: page.per_page_limit,
      };
      hotelBookingHistoryRequest(data);
      // setPage(0);
      // setRowsPerPage(3);
      console.log("tabValue", tabValue);
    } else if (tabValue == "past") {
      console.log("tabValue", tabValue);

      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        filterbystatus: tabValue,
        skip: 1,
        limit: page.per_page_limit,
      };
      hotelBookingHistoryRequest(data);
      // setPage(0);
      // setRowsPerPage(3);
    } else if (tabValue == "cancelled") {
      console.log("tabValue", tabValue);

      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        filterbystatus: tabValue,
        skip: 1,
        limit: page.per_page_limit,
      };
      hotelBookingHistoryRequest(data);
      // setPage(0);
      // setRowsPerPage(3);
    } else {
      data = {
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        filterbystatus: tabValue,
        skip: 1,
        limit: page.per_page_limit,
      };
      //   getMyWalletListDataStart(data);
      hotelBookingHistoryRequest(data);
      // setPage(0);
      // setRowsPerPage(3);
    }
  }, [tabValue]);

  useEffect(() => {
    if (selectHotelBookingHistoryData != null) {
      setPage({
        ...page,
        total: selectHotelBookingHistoryData.total_count,
      });
    }
  }, [selectHotelBookingHistoryData]);

  const handleChangePage = (event, page, limit) => {
    setPage({
      ...page,
      page_no: page,
      per_page_limit: limit,
    });
    let data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
      filterbystatus: tabValue,
      skip: page,
      limit: limit,
    };
    hotelBookingHistoryRequest(data);
  };

  // const handleChangeRowsPerPage = (event) => {
  //   setRowsPerPage(parseInt(event.target.value, 10));
  //   setPage(0);
  // };

  const handleResendConfirmation = (bookingNo) => {
    const postData = {
      booking_number: bookingNo,
    };
    const data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
      postData: postData,
    };
    // console.log(bookingNo);
    hotelResendConfirmationRequest(data);
  };

  const handleSharePopup = (shareData) => {
    if (shareData) {
      setShareCode(shareData);
      setOpenSharePopup(!openSharePopup);
    } else {
    }
  };

  const onCopy = React.useCallback((value) => {
    setIsCopied(value);
    setOpenSharePopup(false);
  }, []);

  const handleCancelBooking = (bookingNo) => {
    const postData = {
      booking_number: bookingNo,
      status: "canceled",
    };
    const data = {
      languageToShow: languageToShow,
      postData: postData,
    };
    cancelBookingRequest(data);
    // data = {
    //   languageToShow: languageToShow,
    //   token: userAuthData != null ? userAuthData.token : "",
    //   filterbystatus: tabValue,
    // };
    // hotelBookingHistoryRequest(data);
    // setPage(0);
    // setRowsPerPage(3);
  };

  React.useEffect(() => {
    const data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
      filterbystatus: tabValue,
    };
    if (selectCancelBookingData != null) {
      if (selectCancelBookingData.success == true) {
        hotelBookingHistoryRequest(data);
      } else {
      }
    }
  }, [selectCancelBookingData]);

  const gotoHotelDetails = (slug, cityname) => {
    var checkinDate = new Date();
    checkinDate.setDate(checkinDate.getDate() + 1);
    var checkoutDate = new Date();
    checkoutDate.setDate(checkoutDate.getDate() + 2);

    if (location.pathname == `/hotel-details/${slug}`) {
      navigate({
        pathname: location.pathname,
        search: createSearchParams({
          search_type: "bid",
          city: cityname,
          check_in_date: moment(checkinDate).format("DD/MM/YYYY"),
          check_out_date: moment(checkoutDate).format("DD/MM/YYYY"),
          // check_in_date: "" + year + "-" + month + "-" + (day + 1) + "",
          // check_out_date: "" + year + "-" + month + "-" + (day + 2) + "",
          adults: "1",
          children: "1",
          rooms: "1",
        }).toString(),
      });
    } else {
      navigate(
        {
          pathname: `/hotel-details/${slug}`,
          search: createSearchParams({
            search_type: "bid",
            city: cityname,
            check_in_date: moment(checkinDate).format("DD/MM/YYYY"),
            check_out_date: moment(checkoutDate).format("DD/MM/YYYY"),
            // check_in_date: "" + year + "-" + month + "-" + (day + 1) + "",
            // check_out_date: "" + year + "-" + month + "-" + (day + 2) + "",
            adults: "1",
            children: "1",
            rooms: "1",
          }).toString(),
        },
        { replace: false }
      );
    }
  };

  return (
    <>
      {/* //////////Myprofile page Section/////////// */}
      <div className="myaccountpage">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="account-titlearea">
                <h2>My Account </h2>
                <p>Manage your wfrlee.com experience</p>
              </div>
            </div>
            <div className="col-md-12">
              <div className="accounttotalsection">
                <ul className="leftmenu">
                  <li>
                    <Link to="/myaccount">My Profile</Link>
                  </li>
                  <li className="active">
                    <Link to="/mybooking">My Bookings</Link>
                  </li>
                  <li>
                    <Link to="/mybidding">My Biddings</Link>
                  </li>
                  <li>
                    <Link to="/favorites">My Favorites</Link>
                  </li>
                  <li>
                    <Link to="/mypoints">My Points</Link>
                  </li>
                  <li>
                    <Link to="/mywallet">My Wallet</Link>
                  </li>
                  <li>
                    <Link to="/myreferrals">My Referrals</Link>
                  </li>
                  <li>
                    <Link to="/notification">Notifications</Link>
                  </li>
                </ul>
                <div className="rightsection">
                  <h1>My Bookings</h1>
                  <div className="accountbooking">
                    <Tabs
                      defaultActiveKey={tabValue}
                      id="booking-tab"
                      className="bookingtab"
                      onSelect={handleTabChange}
                    >
                      <Tab eventKey="upcoming" title="Upcoming">
                        {selectHotelBookingHistoryLoading ? (
                          <Skeleton count={10} />
                        ) : selectHotelBookingHistoryData != null &&
                          selectHotelBookingHistoryData?.data != null ? (
                          //   selectHotelBookingHistoryData.data
                          (selectHotelBookingHistoryData?.data || []).map(
                            (data, index) => (
                              <div className="bookingbox" key={index}>
                                <div className="bookingboxlft">
                                  <h3
                                    onClick={() => {
                                      gotoHotelDetails(
                                        data.hotel_details.slug,
                                        data.hotel_details.address.city_village
                                      );
                                    }}
                                  >
                                    {data.hotel_details.name}
                                  </h3>
                                  <p>
                                    {" "}
                                    {
                                      data.hotel_details.address.city_village
                                    }{" "}
                                    <br />
                                    {
                                      data.hotel_details.address.address_line1
                                    }, {data.hotel_details.address.country},{" "}
                                    {data.hotel_details.address.district}{" "}
                                    {data.hotel_details.address.pincode}
                                  </p>
                                </div>
                                <div className="bookingboxmid">
                                  <p>
                                    {" "}
                                    <label>Booking Date</label>{" "}
                                    <span>
                                      {moment(data.booking_date).format(
                                        "DD MMM, YYYY"
                                      )}
                                    </span>
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Booking id</label>{" "}
                                    <span>{data.booking_number}</span>
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Check-in date</label>{" "}
                                    <span>
                                      {moment(data.checkin_date).format(
                                        "DD MMM, YYYY"
                                      )}
                                    </span>{" "}
                                    {data.checkin_time != null
                                      ? moment(`${data.checkin_time}`, [
                                          "hh:mm",
                                        ]).format("hh:mm A")
                                      : ""}
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Room Type</label>{" "}
                                    <span>{data.room_type_details.name}</span>
                                  </p>
                                </div>
                                <div className="bookingboxrgt">
                                  <Button
                                    onClick={() =>
                                      handleResendConfirmation(
                                        data.booking_number
                                      )
                                    }
                                    className={"gen-btn"}
                                  >
                                    Re-send Confirmation
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      handleSharePopup(data.share_link);
                                    }}
                                    className={"gen-btn"}
                                  >
                                    {" "}
                                    Share Confirmation
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      handleCancelBooking(data.booking_number);
                                    }}
                                    className={"gen-btn"}
                                  >
                                    {" "}
                                    Cancel Booking
                                  </Button>
                                </div>
                              </div>
                            )
                          )
                        ) : (
                          <>
                            <div className="datanotfound">
                              <img src="./img/searc.png" alt="" />
                              <h2>
                                Sorry{" "}
                                <span>
                                  {selectHotelBookingHistoryData?.message}
                                </span>
                              </h2>
                            </div>
                          </>
                        )}
                      </Tab>
                      <Tab eventKey="past" title="Past">
                        {selectHotelBookingHistoryLoading ? (
                          <Skeleton count={10} />
                        ) : selectHotelBookingHistoryData != null &&
                          selectHotelBookingHistoryData?.data != null ? (
                          //   selectHotelBookingHistoryData.data
                          (selectHotelBookingHistoryData?.data || []).map(
                            (data, index) => (
                              <div className="bookingbox" key={index}>
                                <div className="bookingboxlft">
                                  <h3
                                    onClick={() => {
                                      gotoHotelDetails(
                                        data.hotel_details.slug,
                                        data.hotel_details.address.city_village
                                      );
                                    }}
                                  >
                                    {data.hotel_details.name}
                                  </h3>
                                  <p>
                                    {" "}
                                    {
                                      data.hotel_details.address.city_village
                                    }{" "}
                                    <br />
                                    {
                                      data.hotel_details.address.address_line1
                                    }, {data.hotel_details.address.country},{" "}
                                    {data.hotel_details.address.district}{" "}
                                    {data.hotel_details.address.pincode}
                                  </p>
                                </div>
                                <div className="bookingboxmid">
                                  <p>
                                    {" "}
                                    <label>Booking Date</label>{" "}
                                    <span>
                                      {moment(data.booking_date).format(
                                        "DD MMM, YYYY"
                                      )}
                                    </span>
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Booking id</label>{" "}
                                    <span>{data.booking_number}</span>
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Check-in date</label>{" "}
                                    <span>
                                      {moment(data.checkin_date).format(
                                        "DD MMM, YYYY"
                                      )}
                                    </span>{" "}
                                    {data.checkin_time != null
                                      ? moment(`${data.checkin_time}`, [
                                          "hh:mm",
                                        ]).format("hh:mm A")
                                      : ""}
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Room Type</label>{" "}
                                    <span>{data.room_type_details.name}</span>
                                  </p>
                                </div>
                                <div className="bookingboxrgt">
                                  <Button
                                    onClick={() =>
                                      handleResendConfirmation(
                                        data.booking_number
                                      )
                                    }
                                    className={"gen-btn"}
                                  >
                                    Re-send Confirmation
                                  </Button>
                                  <Button
                                    onClick={() => {
                                      handleSharePopup(data.share_link);
                                    }}
                                    className={"gen-btn"}
                                  >
                                    {" "}
                                    Share Confirmation
                                  </Button>
                                </div>
                              </div>
                            )
                          )
                        ) : (
                          <>
                            <div className="datanotfound">
                              <img src="./img/searc.png" alt="" />
                              <h2>
                                Sorry{" "}
                                <span>
                                  {selectHotelBookingHistoryData?.message}
                                </span>
                              </h2>
                            </div>
                          </>
                        )}
                      </Tab>
                      <Tab eventKey="cancelled" title="Cancelled">
                        {selectHotelBookingHistoryLoading ? (
                          <Skeleton count={10} />
                        ) : selectHotelBookingHistoryData != null &&
                          selectHotelBookingHistoryData?.data != null ? (
                          (selectHotelBookingHistoryData?.data || []).map(
                            (data, index) => (
                              <div className="bookingbox" key={index}>
                                <div className="bookingboxlft">
                                  <h3
                                    onClick={() => {
                                      gotoHotelDetails(
                                        data.hotel_details.slug,
                                        data.hotel_details.address.city_village
                                      );
                                    }}
                                  >
                                    {data.hotel_details.name}
                                  </h3>
                                  <p>
                                    {" "}
                                    {
                                      data.hotel_details.address.city_village
                                    }{" "}
                                    <br />
                                    {
                                      data.hotel_details.address.address_line1
                                    }, {data.hotel_details.address.country},{" "}
                                    {data.hotel_details.address.district}{" "}
                                    {data.hotel_details.address.pincode}
                                  </p>
                                </div>
                                <div className="bookingboxmid">
                                  <p>
                                    {" "}
                                    <label>Booking Date</label>{" "}
                                    <span>
                                      {moment(data.booking_date).format(
                                        "DD MMM, YYYY"
                                      )}
                                    </span>
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Booking id</label>{" "}
                                    <span>{data.booking_number}</span>
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Check-in date</label>{" "}
                                    <span>
                                      {moment(data.checkin_date).format(
                                        "DD MMM, YYYY"
                                      )}
                                    </span>{" "}
                                    {data.checkin_time != null
                                      ? moment(`${data.checkin_time}`, [
                                          "hh:mm",
                                        ]).format("hh:mm A")
                                      : ""}
                                  </p>
                                  <p>
                                    {" "}
                                    <label>Room Type</label>{" "}
                                    <span>{data.room_type_details.name}</span>
                                  </p>
                                </div>
                                <div className="bookingboxrgt">
                                  {/* <Button
                                  onClick={() =>
                                    handleResendConfirmation(
                                      data.booking_number
                                    )
                                  }
                                  className={"gen-btn"}
                                >
                                  Re-send Confirmation
                                </Button>
                                <Button
                                  onClick={() => {
                                    handleSharePopup(data.share_link);
                                  }}
                                  className={"gen-btn"}
                                >
                               
                                  Share Confirmation
                                </Button> */}
                                </div>
                              </div>
                            )
                          )
                        ) : (
                          <>
                            <div className="datanotfound">
                              <img src="./img/searc.png" alt="" />
                              <h2>
                                Sorry{" "}
                                <span>
                                  {selectHotelBookingHistoryData?.message}
                                </span>
                              </h2>
                            </div>
                          </>
                        )}{" "}
                      </Tab>
                    </Tabs>
                    <ShareModal
                      setOpenSharePopup={setOpenSharePopup}
                      openSharePopup={openSharePopup}
                      shareCode={shareCode}
                      setShareCode={setShareCode}
                      onCopy={onCopy}
                      isCopied={isCopied}
                      setIsCopied={setIsCopied}
                    />
                    <PaginationWithDisplay
                      page={page}
                      handleChangePage={handleChangePage}
                      displayShow={true}
                    />
                    {/* <TablePagination
                      rowsPerPageOptions={[3, 5, 10]}
                      component="div"
                      count={
                        selectHotelBookingHistoryData != null
                          ? selectHotelBookingHistoryData?.data != null
                            ? selectHotelBookingHistoryData?.data?.length
                            : 0
                          : 0
                      }
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                      showFirstButton={true}
                      showLastButton={true}
                    /> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Myprofile page Section/////////// */}
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  selectHotelBookingHistoryLoading: selectHotelBookingHistoryLoading,
  selectHotelBookingHistoryData: selectHotelBookingHistoryData,
  userAuthData: selectUserLoginData,
  selectCancelBookingData: selectCancelBookingData,
});
const mapDispatchToProps = (dispatch) => ({
  hotelBookingHistoryRequest: (data) =>
    dispatch(hotelBookingHistoryRequest(data)),
  hotelResendConfirmationRequest: (data) =>
    dispatch(hotelResendConfirmationRequest(data)),
  cancelBookingRequest: (data) => dispatch(cancelBookingRequest(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(MybookingPage);
