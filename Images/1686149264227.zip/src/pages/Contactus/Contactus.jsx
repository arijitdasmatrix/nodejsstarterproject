import React from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import ContactusForm from "../../components/contact/ContactusForm";

const ContactPage = () => {
  const location = useLocation();
  useEffect(() => {
    window.scroll(0, 0);
  }, []);

  return (
    <>
      {/* //////////Common page Section/////////// */}
      <div className="commonpage">
        <div className="container">
          <div className="row">
            <div className="col-md-3">
              <ul className="leftmenu">
                <li className={location.pathname == "/aboutus" ? "active" : ""}>
                  <Link to="/aboutus">About us</Link>
                </li>
                <li
                  className={
                    location.pathname == "/safety-security" ? "active" : ""
                  }
                >
                  <Link to="/safety-security">Safety and Security</Link>
                </li>
                <li
                  className={
                    location.pathname == "/terms&conditions" ? "active" : ""
                  }
                >
                  <Link to="/terms&conditions">Terms and Conditoins </Link>
                </li>
                <li
                  className={
                    location.pathname == "/privacy-policy" ? "active" : ""
                  }
                >
                  <Link to="/privacy-policy">Privacy Policy</Link>
                </li>
                <li
                  className={location.pathname == "/contactus" ? "active" : ""}
                >
                  <Link to="/contactus">Contact us</Link>
                </li>
                <li className={location.pathname == "/career" ? "active" : ""}>
                  <Link to="/career">Career</Link>
                </li>
                <li
                  className={
                    location.pathname == "/partnerswithwfrlee" ? "active" : ""
                  }
                >
                  <Link to="/partnerswithwfrlee">Partners with wfrlee</Link>
                </li>
                <li className={location.pathname == "/faq" ? "active" : ""}>
                  <Link to="/faq">FAQ</Link>
                </li>
              </ul>
            </div>
            <div className="col-md-9">
              <div className="WL_contactmwrp customform rightFormWidth">
                <h1>Contact us</h1>

                <ContactusForm />
                {/* //////////call text Section start /////////// */}
                <div className="WL_contacttextwrp">
                  <div className="WL_innercontacttext">
                    <p className="WL_innercontacttextinner">
                      Call Us at
                      <span>
                        <Link to="tel:+971 589-706-050">+971 589-706-050</Link>
                      </span>
                    </p>
                  </div>

                  <div className="WL_innercontacttext">
                    <p className="WL_innercontacttextinner">
                     Text Us at
                      <span>
                        <Link to="mailto:info@wfrlee.com">
                          info@wfrlee.com
                        </Link>
                      </span>
                    </p>
                  </div>
                </div>
                {/* //////////call text Section end /////////// */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* //////////Common page Section/////////// */}
    </>
  );
};

export default ContactPage;
