const LanaguageActionTypes = {
SELECT_DEFAULT_LANGUAGE:'SELECT_DEFAULT_LANGUAGE',
};
    
export default LanaguageActionTypes;