import LanaguageActionTypes from './languae.types';

export const selectLanguage = language => ({
type:LanaguageActionTypes.SELECT_DEFAULT_LANGUAGE,
payload:language
});