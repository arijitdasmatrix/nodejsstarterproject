import HomeActionTypes from "./home.types";

/***** Home Page  Data Actions  ********/

export const getOfferPromotionsPartnersPreferenceRequest = (homeData) => ({
 type: HomeActionTypes.GET_OFFER_PROMOTIONS_PARTNERS_PREFERENCE_DATA_REQUEST,
 payload: homeData,
});
  
export const getOfferPromotionsPartnersPreferenceSuccess = (hotelData) => ({
 type: HomeActionTypes.GET_OFFER_PROMOTIONS_PARTNERS_PREFERENCE_DATA_SUCCESS,
 payload: hotelData,
});
  
export const getOfferPromotionsPartnersPreferenceFailure = (error) => ({
 type: HomeActionTypes.GET_OFFER_PROMOTIONS_PARTNERS_PREFERENCE_DATA_FAILED,
 payload: error,
});

export const getPerferenceDataList = (data) => ({
type: HomeActionTypes.GET_PREFERENCE_DATA_REQUEST_LIST,
payload: data
}); 

/***** Home Page Data Actions  ********/