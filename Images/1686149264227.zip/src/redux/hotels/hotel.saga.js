import { takeLatest, put, all, call } from "redux-saga/effects";
import axios from "axios";
import HotelActionTypes from "./hotel.types";

import {
  errorToast,
  successToast,
} from "../../utils/toastHelper";

import {
  getFullHotelDetailsSuccess,
  getFullHotelDetailsFailure,
  getFullHotelListSuccess,
  getFullHotelListFailure,
  getHotelAnimitySuccess,
  getHotelAnimityError,
  addFavouriteHotelSuccess,
  addFavouriteHotelFailure,
  removeFavouriteHotelSuccess,
  removeFavouriteHotelFailure,
  getAllFavouriteHotelListSuccess,
  getAllFavouriteHotelListFailure,
  getBidCheckoutDetailsSuccess,
  getBidCheckoutDetailsFailure,
  getHourlyCheckoutDetailsSuccess,
  getHourlyCheckoutDetailsFailure,
  hotelBookingSuccess,
  hotelBookingFailure,
  hotelBookingHistorySuccess,
  hotelBookingHistoryFailure,
  applyWalletSuccess,
  applyWalletFailure,
  applyPromoCodeSuccess,
  applyPromoCodeFailure,
  bidYourAmountSuccess,
  bidYourAmountFailure,
  applyHotelOffersSuccess,
  applyHotelOffersFailure,
  getTotalHotelListCount,
  hotelWheatherApiSuccess,
  hotelWheatherApiFailure,
  hotelResendConfirmationSuccess,
  hotelResendConfirmationFailure,
} from "./hotel.actions";
import store from "./../store";
/************ Full Hotel List   *************** */
var backendUrlEndPoint = process.env.REACT_APP_BACKEND_API_ENDPOINT;
var weatherAPIEndPoint =
  process.env.NODE_ENV == "production"
    ? process.env.REACT_APP_WEATHER_API_ENDPOINT_PROD
    : process.env.REACT_APP_WEATHER_API_ENDPOINT_DEV;

export function* getFullHotelListDatasAsync({ payload: data }) {
  console.log("dataHello", data);
  //&sort_by=${data.sort_by}&filters=${data.filters} -- when API complete this section will add
  try {
    const recomended = data.sort_by != "" ? "&sort_by=" + data.sort_by : "";
    const filter = data.filter ? recomended + "&filters=" + data.filters : "";
    const extraurl =
      data.search_type == "bid"
        ? "&check_out_date=" + data.check_out_date + ""
        : " &book_for=" + data.book_for + "";
    const Preference = store.getState().home.perference != null ? `&preference=${store.getState().home.perference}` : "";  
    
    const url = 
      "" +
      backendUrlEndPoint +
      "/hotel/search?search_type=" +
      data.search_type +
      "&city=" +
      data.city +
      "&check_in_date=" +
      data.check_in_date +
      extraurl +
      "&adults=" +
      data.adults +
      "&children=" +
      data.children +
      "&rooms=" +
      data.rooms +
      filter + 
      Preference;
    // }&city=${data.city}&check_in_date=${data.check_in_date}${
    //   data.search_type == `bid`
    //     ? `&check_out_date=${data.check_out_date}`
    //     : `&book_for=${data.hours}`
    // }&adults=${data.adults}&children=${data.children}&rooms=${
    //   data.rooms
    // }&sort_by=${data.sort_by}&filters=${data.filters}`
    const hotelDetailsResponse = yield axios.get(url, {
      headers: {
        mobile: "true",
        "Accept-Language": `${data.language}`,
        Authorization:
          store.getState().user.currentUser != null
            ? "Bearer " + store.getState().user.currentUser.token + ""
            : "",
      },
    });
    console.log(
      "EEEEEE",
      hotelDetailsResponse.data.success ||
        hotelDetailsResponse.data.message == "No hotel found."
    );
    if (
      hotelDetailsResponse.data.success ||
      hotelDetailsResponse.data.message == "No hotel found."
    ) {
      yield put(getFullHotelListSuccess(hotelDetailsResponse.data.data));
      yield put(getTotalHotelListCount(hotelDetailsResponse.data.total_count));
    } else {
      yield put(getFullHotelListFailure(hotelDetailsResponse.data));
    }
  } catch (error) {
    console.log("Network Error");
  }
  // console.log("HotelListData",hotelDetailsResponse.data.success)
}

/************ Full Hotel Amenity List   *************** */
export function* getFullHotelAnimityListDatasAsync({ payload: data }) {
  try {
    const hotelAminityDataResponse = yield axios.get(
      `${backendUrlEndPoint}/amenity/get-all`,
      {
        headers: {
          mobile: "true",
          "Accept-Language": `${data.language}`,
        },
      }
    );
    if (hotelAminityDataResponse.data.success) {
      yield put(getHotelAnimitySuccess(hotelAminityDataResponse.data.data));
    } else {
      yield put(getHotelAnimityError(hotelAminityDataResponse.data));
    }
  } catch (error) {}
}

/************ Full Hotel Details By hotel slug    *************** */
export function* getFullHotelDetailsAsync({ payload: data }) {
  try {
    const extraurl =
      data.searchedParams.search_type == "bid"
        ? "&check_out_date=" + data.searchedParams.check_out_date + ""
        : " &book_for=" + data.searchedParams.book_for + "";
    const url =
      backendUrlEndPoint +
      "/hotel/get-hotel/" +
      data.hotel_slug +
      "?search_type=" +
      data.searchedParams.search_type +
      "&city=" +
      data.searchedParams.city +
      "&check_in_date=" +
      data.searchedParams.check_in_date +
      extraurl +
      "&adults=" +
      data.searchedParams.adults +
      "&children=" +
      data.searchedParams.children +
      "&rooms=" +
      data.searchedParams.rooms;

    const response = yield axios.get(url, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        mobile: "true",
        "Accept-Language": `${data.languageToShow}`,
        Authorization:
          store.getState().user.currentUser != null
            ? "Bearer " + store.getState().user.currentUser.token + ""
            : "",
      },
    });
    // const response = yield call(hotelService.getFullHotelDetails, data);
    if (response.data.success === true) {
      yield put(getFullHotelDetailsSuccess(response.data));
    } else {
      yield put(getFullHotelDetailsFailure(response.data));
    }
  } catch (error) {
    console.log("Network Error");
  }
}

/************ Add Favourite Hotel    *************** */
export function* addFavouriteHotelAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      `${backendUrlEndPoint}/hotel/add-favourite/`,
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization:
            store.getState().user.currentUser != null
              ? "Bearer " + store.getState().user.currentUser.token + ""
              : "",
        },
      }
    );

    // const response = yield call(hotelService.addFavouriteHotel, data);
    if (response.status != 200) {
      if (response.error.response.data.success === false) {
        if (response.error.response.data.message == "Token is required.") {
          errorToast("Please Login");
        }
      }
    }
    if (response.data.success === true) {
      yield put(addFavouriteHotelSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(addFavouriteHotelFailure(response.data));
      errorToast(response.data.message);
      console.log("failed saga");
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/************ Remove Favourite Hotel    *************** */
export function* removeFavouriteHotelAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      `${backendUrlEndPoint}/hotel/remove-favourite/`,
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization:
            store.getState().user.currentUser != null
              ? "Bearer " + store.getState().user.currentUser.token + ""
              : "",
        },
      }
    );

    // const response = yield call(hotelService.removeFavouriteHotel, data);

    if (response.data.success == true) {
      yield put(removeFavouriteHotelSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(removeFavouriteHotelFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error");
  }
}

/************ Favourites Hotel List    *************** */
export function* getAllFavouriteHotelListAsync({ payload: data }) {
  try {
    const response = yield axios.get(
      `${backendUrlEndPoint}/hotel/get-all-favourite/`,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization:
            store.getState().user.currentUser != null
              ? "Bearer " + store.getState().user.currentUser.token + ""
              : "",
        },
      }
    );
    // const response = yield call(
    //   hotelService.getAllFavouriteHotelList,
    //   language
    // );

    if (response.data.success === true) {
      yield put(getAllFavouriteHotelListSuccess(response.data));
      console.log(response.data.message);
    } else {
      yield put(getAllFavouriteHotelListFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error");
  }
}
/************ Bid Checkout Details     *************** */
export function* getBidCheckoutDetailsAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/hotel/get-bid-checkout-details",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    // console.log("bidCheckoutResponse saga", response);
    if (response.data.success === true) {
      yield put(getBidCheckoutDetailsSuccess(response.data));
      // successToast(response.data.message);
    } else {
      yield put(getBidCheckoutDetailsFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/************ Hourly Checkout Details     *************** */
export function* getHourlyCheckoutDetailsAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/hotel/get-hourly-checkout-details",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    // console.log("hourlyCheckoutResponse saga", response);
    if (response.data.success === true) {
      yield put(getHourlyCheckoutDetailsSuccess(response.data));
      // successToast(response.data.message);
    } else {
      yield put(getHourlyCheckoutDetailsFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/************ Hotel Booking     *************** */
export function* hotelBookingAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/hotel/booking",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    console.log("Hotel Booking saga", response);
    if (response.data.success === true) {
      yield put(hotelBookingSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(hotelBookingFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/********** User Hotel Booking List History Handleing  ***********/
export function* userBookingHistoryList({ payload: data }) {
  try {
    const response = yield axios.get(
      // ""+backendUrlEndPoint+"/booking/get-all?filterbystatus=" +
      //   data.filterbystatus +
      //   "",
      `${backendUrlEndPoint}/booking/get-all`,

      {
        // headers: {
        //   "Access-Control-Allow-Origin": "*",
        //   mobile: true,
        //   "Accept-Language": `${data.languageToShow}`,
        //   Authorization: data.token ? "Bearer " + data.token : "",
        // },
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization:
            store.getState().user.currentUser != null
              ? "Bearer " + store.getState().user.currentUser.token + ""
              : "",
        },
        params: {
          filterbystatus: data.filterbystatus,
          skip: data.skip,
          limit: data.limit,
        },
      }
    );

    // console.log("Hotel Booking saga", response);
    if (response.data.success === true) {
      yield put(hotelBookingHistorySuccess(response.data));
      // successToast(response.data.message);
    } else {
      yield put(hotelBookingHistoryFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/************ Apply Wallet     *************** */
export function* applyWalletAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/wallet/point-apply/",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    console.log("apply wallet saga", response);
    if (response.data.success === true) {
      yield put(applyWalletSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(applyWalletFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error");
  }
}

/************ Apply Promo Code     *************** */
export function* applyPromoCodeAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/coupon/apply/",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    console.log("apply promo code saga", response);
    if (response.data.success === true) {
      yield put(applyPromoCodeSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(applyPromoCodeFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error");
  }
}

/************ Bid Your Amount     *************** */
export function* bidYourAmountAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/biding-request/add/",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    console.log("bid your amount saga", response);
    if (response.data.success === true) {
      yield put(bidYourAmountSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(bidYourAmountFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error");
  }
}

/************ Apply Hotel Offers     *************** */
export function* applyHotelOffersAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/hotel/apply-offers/",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    console.log("apply hotel offers saga", response);
    if (response.data.success === true) {
      yield put(applyHotelOffersSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(applyHotelOffersFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/** HOTEL DATA WEATHER API WORKING  ***/
export function* hotelWeatherDataHandle({ payload: data }) {
  try {
    const response = yield axios.post(
      `${weatherAPIEndPoint}/current.json?key=${process.env.REACT_APP_WeatherAPI}&q=${data}&aqi=no`
    );
    console.log(
      "weather-saga",
      response,
      response.statusText,
      response.statusText === "OK"
    );
    if (response.status === 200) {
      yield put(hotelWheatherApiSuccess(response.data));
      //  successToast(response.data.message);
    } else {
      yield put(hotelWheatherApiFailure(response));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/************ HOTEL RE-SEND CONFIRMATION  *************** */
export function* hotelResendConfirmationAsync({ payload: data }) {
  try {
    const response = yield axios.post(
      "" + backendUrlEndPoint + "/hotel/resend-booking-email",
      data.postData,
      {
        headers: {
          "Access-Control-Allow-Origin": "*",
          mobile: true,
          "Accept-Language": `${data.languageToShow}`,
          Authorization: data.token ? "Bearer " + data.token : "",
        },
      }
    );

    console.log("hotel resend confirmation saga", response);
    if (response.data.success === true) {
      yield put(hotelResendConfirmationSuccess(response.data));
      successToast(response.data.message);
    } else {
      yield put(hotelResendConfirmationFailure(response.data));
      errorToast(response.data.message);
    }
  } catch (error) {
    console.log("Network Error", error);
  }
}

/** HOTEL DATA WEATHER API WORKING  ***/

export function* getFullHotelDetailsFetchStart() {
  yield takeLatest(
    HotelActionTypes.GET_FULL_HOTELS_DETAILS_REQUEST,
    getFullHotelDetailsAsync
  );
}

export function* getFullHotelListFetchStart() {
  yield takeLatest(
    HotelActionTypes.GET_HOTEL_LIST_SEARCH_START,
    getFullHotelListDatasAsync
  );
}

export function* getHotelAminityListFetchStart() {
  yield takeLatest(
    HotelActionTypes.GET_HOTEL_ANIMITY_LIST_START,
    getFullHotelAnimityListDatasAsync
  );
}
export function* addFavouriteHotelFetchStart() {
  yield takeLatest(
    HotelActionTypes.ADD_TO_FAVOURITE_HOTEL_REQUEST,
    addFavouriteHotelAsync
  );
}

export function* removeFavouriteHotelFetchStart() {
  yield takeLatest(
    HotelActionTypes.REMOVE_TO_FAVOURITE_HOTEL_REQUEST,
    removeFavouriteHotelAsync
  );
}

export function* getAllFavouriteHotelListFetchStart() {
  yield takeLatest(
    HotelActionTypes.GET_ALL_FAVOURITE_HOTEL_LIST_REQUEST,
    getAllFavouriteHotelListAsync
  );
}
/********** Hottel Weather Data API *************/
export function* hotelWeatherAPIDataFetching() {
  yield takeLatest(
    HotelActionTypes.HOTEL_WHEATHER_API_REQUEST,
    hotelWeatherDataHandle
  );
}
/********** Hottel Weather Data API *************/

/************ Bid Checkout Details     *************** */
export function* getBidCheckoutDetailsFetchStart() {
  yield takeLatest(
    HotelActionTypes.GET_BID_CHECKOUT_DETAILS_REQUEST,
    getBidCheckoutDetailsAsync
  );
}

/************ Hourly Checkout Details  *************** */
export function* getHourlyCheckoutDetailsFetchStart() {
  yield takeLatest(
    HotelActionTypes.GET_HOURLY_CHECKOUT_DETAILS_REQUEST,
    getHourlyCheckoutDetailsAsync
  );
}

/************ Hourly Checkout Details  *************** */
export function* hotelBookingFetchStart() {
  yield takeLatest(HotelActionTypes.HOTEL_BOOKING_REQUEST, hotelBookingAsync);
}

/******** User Hotel Booking List History Handleing *******/
export function* hotelBookingHistoryFetchStart() {
  yield takeLatest(
    HotelActionTypes.HOTEL_BOOKING_LIST_DATA_FETCH,
    userBookingHistoryList
  );
}

/************ Apply Wallet  *************** */
export function* applyWalletFetchStart() {
  yield takeLatest(HotelActionTypes.APPLY_WALLET_REQUEST, applyWalletAsync);
}

/************ Apply Promo Code  *************** */
export function* applyPromoCodeFetchStart() {
  yield takeLatest(
    HotelActionTypes.APPLY_PROMO_CODE_REQUEST,
    applyPromoCodeAsync
  );
}

/************ Bid Your Amount  *************** */
export function* bidYourAmountFetchStart() {
  yield takeLatest(
    HotelActionTypes.BID_YOUR_AMOUNT_REQUEST,
    bidYourAmountAsync
  );
}

/************ Apply Hotel Offers  *************** */
export function* applyHotelOffersFetchStart() {
  yield takeLatest(
    HotelActionTypes.APPLY_HOTEL_OFFERS_REQUEST,
    applyHotelOffersAsync
  );
}

/************ HOTEL RE-SEND CONFIRMATION  *************** */
export function* hotelResendConfirmationFetchStart() {
  yield takeLatest(
    HotelActionTypes.HOTEL_RESEND_CONFIRMATION_REQUEST,
    hotelResendConfirmationAsync
  );
}

export function* hotelSagas() {
  yield all([
    call(getFullHotelDetailsFetchStart),
    call(getFullHotelListFetchStart),
    call(getHotelAminityListFetchStart),
    call(getFullHotelDetailsFetchStart),
    call(getFullHotelListFetchStart),
    call(addFavouriteHotelFetchStart),
    call(removeFavouriteHotelFetchStart),
    call(getAllFavouriteHotelListFetchStart),
    call(getBidCheckoutDetailsFetchStart),
    call(getHourlyCheckoutDetailsFetchStart),
    call(hotelBookingFetchStart),
    call(hotelBookingHistoryFetchStart),
    call(applyWalletFetchStart),
    call(applyPromoCodeFetchStart),
    call(bidYourAmountFetchStart),
    call(applyHotelOffersFetchStart),
    call(hotelWeatherAPIDataFetching),
    call(hotelResendConfirmationFetchStart),
  ]);
}
