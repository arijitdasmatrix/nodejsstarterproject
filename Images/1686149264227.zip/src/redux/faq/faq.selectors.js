import { createSelector } from 'reselect';

const selectFaq = state => state.faq;

//const selectLanguage = state => state.cms;

export const selectfaqData = createSelector(
[selectFaq],
(faq) => faq.faqData
);