import { createSelector } from 'reselect';

const selectCms = state => state.cms;

const selectLanguage = state => state.cms;

export const selectcmsData = createSelector(
[selectLanguage],
(cms) => cms.cmsData
);