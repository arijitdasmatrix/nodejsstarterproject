import { createSelector } from 'reselect';

const selectCurrency = state => state.currency;

export const selectcurrencyToShow = createSelector(
[selectCurrency],
(currency) => currency.currency
);