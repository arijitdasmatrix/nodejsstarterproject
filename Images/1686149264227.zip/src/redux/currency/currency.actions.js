import CurrencyActionTypes from './currency.types';

export const selectCurrency = currency => ({
type:CurrencyActionTypes.SELECT_DEFAULT_CURRENCY,
payload:currency
});