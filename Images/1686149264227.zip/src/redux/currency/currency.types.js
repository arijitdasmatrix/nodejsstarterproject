const CurrencyActionTypes = {
SELECT_DEFAULT_CURRENCY:'SELECT_DEFAULT_CURRENCY',
};
    
export default CurrencyActionTypes;