import { API } from "../config/api.config";
import { PathApi } from "../config/api.path.config";

const getAllBiding = (language) => {
 
    return API.get(PathApi.getAllBiding,language)
      .then((data) => {
        return data;
      })
      .catch((error) => {
        return {
          error,
        };
      });
  }



  const userAccountBidingService = {
    getAllBiding
  }

  export default userAccountBidingService;