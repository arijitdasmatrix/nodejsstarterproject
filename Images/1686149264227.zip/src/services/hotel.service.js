import { API } from "../config/api.config";
import { PathApi } from "../config/api.path.config";

const getFullHotelDetails = (data) => {
  // backendUrlEndPoint +
  // "/hotel/search?search_type=" +
  // data.search_type +
  // "&city=" +
  // data.city +
  // "&check_in_date=" +
  // data.check_in_date +
  // extraurl +
  // "&adults=" +
  // data.adults +
  // "&children=" +
  // data.children +
  // "&rooms=" +
  // data.rooms +
  // filter;
  const extraurl =
    data.searchedParams.search_type == "bid"
      ? "&check_out_date=" + data.searchedParams.check_out_date + ""
      : " &book_for=" + data.searchedParams.book_for + "";
  return API.get(
    PathApi.getFullHotelDetails +
      data.hotel_slug +
      "?search_type=" +
      data.searchedParams.search_type +
      "&city=" +
      data.searchedParams.city +
      "&check_in_date=" +
      data.searchedParams.check_in_date +
      extraurl +
      "&adults=" +
      data.searchedParams.adults +
      "&children=" +
      data.searchedParams.children +
      "&rooms=" +
      data.searchedParams.rooms,
    data
  )
    .then((data) => {
      return data;
    })
    .catch((error) => {
      return {
        error,
      };
    });
};

const addFavouriteHotel = (data) => {
  console.log("request", data);

  return API.post(PathApi.addFavouriteHotel, data.postData, data)
    .then((data) => {
      return data;
    })
    .catch((error) => {
      return {
        error,
      };
    });
};

const removeFavouriteHotel = (data) => {
  console.log("request", data);

  return API.post(PathApi.removeFavouriteHotel, data.postData, data)
    .then((data) => {
      return data;
    })
    .catch((error) => {
      return {
        error,
      };
    });
};

const getAllFavouriteHotelList = (paramsData) => {
  console.log("languages", paramsData);

  return API.get(PathApi.getAllFavouriteHotelList, paramsData)
    .then((data) => {
      return data;
    })
    .catch((error) => {
      return {
        error,
      };
    });
};

const hotelService = {
  getFullHotelDetails,
  addFavouriteHotel,
  removeFavouriteHotel,
  getAllFavouriteHotelList,
};

export default hotelService;
