import { API } from "../config/api.config";
import { PathApi } from "../config/api.path.config";

const SocialLogin = (request) => {
    console.log("request", request);
  
    return API.post(PathApi.socialLogin, request)
      .then((data) => {
        return data;
      })
      .catch((error) => {
        return {
          error,
        };
      });
  }

  const LoginUser = (request) => {
    console.log("login user");
  }


  const loginService = {
    SocialLogin,
    LoginUser
  }

  export default loginService;