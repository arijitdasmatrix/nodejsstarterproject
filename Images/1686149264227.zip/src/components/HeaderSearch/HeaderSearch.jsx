import React, { useEffect, useState, useRef, useMemo } from "react";
import { Button, Dropdown, Form, Tabs, Tab, Pagination } from "react-bootstrap";
import { createStructuredSelector } from "reselect";
import { useParams } from 'react-router-dom';
import {
  searchDataSave,
  getHotelListRequest,
  placeStateDataSave,
} from "./../../redux/hotels/hotel.actions";
import usePlacesAutocomplete from "use-places-autocomplete";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import useOnclickOutside from "react-cool-onclickoutside";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import TextField from "@mui/material/TextField";
import { AiOutlineMinusCircle } from "react-icons/ai";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import moment from "moment";
import dayjs from "dayjs";
import Autocomplete from "react-google-autocomplete";
import { errorToast } from "../../utils/toastHelper";
import {
  useNavigate,
  createSearchParams,
  useLocation,
  useSearchParams,
} from "react-router-dom";
import { BsPlusCircle } from "react-icons/bs";
import {
  searchFilterData,
  searchFilterAddOrNot,
  selectFavouriteHotelSearchData,
  selectHotelBidNowPageRouteData, 
  selectHotelDetailsPageRouteData
} from "./../../redux/hotels/hotel.selectors";
import {
  Combobox,
  ComboboxInput,
  ComboboxPopover,
  ComboboxList,
  ComboboxOption,
  ComboboxOptionText,
} from "@reach/combobox";
import "@reach/combobox/styles.css";


const HotelSearchForOthers = ({
  searchDataSave,
  getHotelListRequest,
  searchFilterData,
  languageToShow,
  searchFilterAddOrNot,
  placeStateDataSave,
  selectFavouriteHotelSearchData,
  selectHotelBidNowPageRouteData,
  selectHotelDetailsPageRouteData
}) => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [open, setOpen] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [checkoutTime, setCheckoutTime] = useState(false);
  let location = useLocation();
  console.log("hello",selectHotelBidNowPageRouteData == "BiddingDetails" );
  const [searchType, setSearchType] = useState( 
    selectHotelBidNowPageRouteData == "BiddingDetails" ? selectFavouriteHotelSearchData.searchType : searchParams.get("search_type") == null
      ? null
      : searchParams.get("search_type")
  );
  const [getHours, setGetHours] = useState(
    searchParams.get("book_for") == null ? 3 : searchParams.get("book_for")
  );
  const [longaddress, setLongaddress] = useState(
    searchParams.get("city") == null ? null : searchParams.get("city")
  );
  const [placeSearchError, setPlaceSearchError] = useState("");
  const [searchtypeShowButton, setSearchtypeShowButton] = useState(
    searchParams.get("search_type") == null
      ? null
      : searchParams.get("search_type")
  );
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [guestRomsPopup, setGuestRoomsPopup] = useState(false);
  const [guestRomsPopupsecond, setGuestRoomsPopupsecond] = useState(false);
  const [guestRoomData, setGuestRoomData] = useState({
    rooms: parseInt(
      searchParams.get("rooms") == null ? 1 : searchParams.get("rooms")
    ),
    child: parseInt(
      searchParams.get("children") == null ? 0 : searchParams.get("children")
    ),
    adults: parseInt(
      searchParams.get("adults") == null ? 1 : searchParams.get("adults")
    ),
  });
 
  // const [place, setPlace] = useState(
  //   searchParams.get("city") == null ? null : searchParams.get("city")
  // );
  const [checkIn, setCheckIn] = useState(false);
  if (searchParams.get("check_in_date") != null) {
    var dateHandle1 = searchParams.get("check_in_date").split("/");
  }
  if (searchParams.get("check_out_date") != null) {
    var dateHandle2 = searchParams.get("check_out_date").split("/");
  }
  const [checkInOutValue, setCheckInOutValue] = useState({
    checkInTime:
      searchParams.get("check_in_date") == null
        ? null
        : `${dateHandle1[2]}-${dateHandle1[1]}-${dateHandle1[0]}`,
    checkOutTime:
      searchParams.get("check_out_date") == null
        ? null
        : `${dateHandle2[2]}-${dateHandle2[1]}-${dateHandle2[0]}`,
  });  const {
    ready,
    value,
    suggestions: { status, data },
    setValue,
    clearSuggestions
  } = usePlacesAutocomplete({ callbackName: "initMap" });
   const ref1 = useRef(null);
   const ref2= useRef(null);
  var preference = {
    arrows: true,
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,

    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  var partner = {
    arrows: true,
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  var offerPromotion = {
    arrows: true,
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
        },
      },
      {
        breakpoint: 700,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  const populartoleasting = (citynamedetails) => {
    //console.log("Destinations", citynamedetails);
    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    let day = dateObj.getUTCDate();
    let year = dateObj.getUTCFullYear();
    window.scroll(0, 0);

    navigate({
      pathname: "listingbidnow",
      search: createSearchParams({
        search_type: "bid",
        city: citynamedetails,
        check_in_date: "" + year + "-" + month + "-" + day + "",
        check_out_date: "" + year + "-" + month + "-" + (day + 1) + "",
        adults: "1",
        children: "0",
        rooms: "1",
      }).toString(),
    });
  };

  // DatePicker
  // const [value, setValue] = useState(
  //   searchParams.get("check_in_date") == null
  //     ? null
  //     : dateHandle1[2] + "-" + dateHandle1[1] + "-" + dateHandle1[0]
  // );
  //    useEffect(() => {
  //    if (checkInOutValue.checkInTime != null && isOpen == false ) {
  //    handleOpen();
  //    }
  //    },[checkInOutValue.checkInTime,isOpen]);
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
  };
  // DatePicker
  const handleInput = (e) => {
    setValue(e.target.value);
  };

  const handleSelect = (e)=> {
  console.log("handlePlaceEvent",e);
  //setValue(val,false);
  //clearSuggestions();
  };
  const reference = useOnclickOutside(() => {
    // When user clicks outside of the component, call it to clear and reset the suggestions data
    clearSuggestions()
  });
  const renderSuggestions = () => {
    const suggestions = data.map(({ place_id, description }) =>   (
      <ComboboxOption key={place_id} value={description} />
    ));

    return (
      <>
       <div ref={reference}>
        {suggestions}
        <li className="logo">
          <img
            src="https://developers.google.com/maps/documentation/images/powered_by_google_on_white.png"
            alt="Powered by Google"
          />
        </li>
        </div>
      </>
    );
  };
  const guestAndRoom = () => {
    setGuestRoomsPopup(!guestRomsPopup);
  };
  const guestAndRoomsecond = () => {
    setGuestRoomsPopupsecond(!guestRomsPopupsecond);
  };
  //    console.log("Wordlsss",guestRomsPopupsecond);
  const handleClickOutside = (event) => {
    if (ref1.current && !ref1.current.contains(event.target)) {
      setGuestRoomsPopup(false);
    }
    if (ref2.current && !ref2.current.contains(event.target)) {
      setGuestRoomsPopupsecond(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, []);

  const handleHourscollect = (e) => {
    //  console.log("hours",e.target.value);
    setGetHours(e.target.value);
    handleClose();
  };

  const handleIncrease = (type) => {
    if (type == "room") {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        rooms: guestRoomData.rooms + 1,
      }));
    } else if (type == "adult") {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        adults: guestRoomData.adults + 1,
      }));
    } else {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        child: guestRoomData.child + 1,
      }));
    }
  };

  const handleDecrease = (type) => {
    console.log(type);
    if (type == "room" && guestRoomData.rooms >= 1) {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        rooms: guestRoomData.rooms - 1,
      }));
    } else if (type == "adult" && guestRoomData.adults >= 1) {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        adults: guestRoomData.adults - 1,
      }));
    } else if (type == "children" && guestRoomData.child >= 1) {
      setGuestRoomData((existingValues) => ({
        ...existingValues,
        child: guestRoomData.child - 1,
      }));
    } else {
    }
  };

  useEffect(() => {
    if (longaddress == "") {
     // setPlace("");
    }
  }, [longaddress]);
useEffect(() => {
 setValue(searchParams.get("city") == null ? null : searchParams.get("city"),false);
},[] )
  //  console.log("WWWW",location.pathname);
  const searchsubmit = (event) => {
    event.preventDefault();

    if (longaddress.length == 0 || value.length == 0) {
      setPlaceSearchError("Please Select The Place Your want to search");
      return;
    } else {
      if (location.pathname == "/listingbidnow") {
        //${place.address_components[0].long_name} place address

        const data = {
          language: languageToShow,
          filter: searchFilterAddOrNot,
          search_type: searchType,
          city: value != null ? value : "",
          book_for: getHours,
          check_in_date: moment(checkInOutValue.checkInTime.toString()).format(
            "DD/MM/YYYY"
          ),
          check_out_date:
            checkInOutValue.checkOutTime == null
              ? null
              : moment(checkInOutValue.checkOutTime.toString()).format(
                  "DD/MM/YYYY"
                ),
          adults: guestRoomData.adults,
          children: guestRoomData.child,
          rooms: guestRoomData.rooms,
          sort_by: "recommended",
          filters: encodeURIComponent(JSON.stringify(searchFilterData)),
        };
        const dataSearch = {
          place: value,
          roomdata: guestRoomData,
          getHours: getHours,
          searchType: searchType,
          searchButtonShow: searchType,
          checkInTime: moment(checkInOutValue.checkInTime.toString()).format(
            "DD/MM/YYYY"
          ),
          checkOutTime:
            checkInOutValue.checkOutTime != null
              ? moment(checkInOutValue.checkOutTime.toString()).format(
                  "DD/MM/YYYY"
                )
              : null,
        };
        placeStateDataSave(value);
        searchDataSave(dataSearch);
        getHotelListRequest(data);
      } else {
        //${place.address_components[0].long_name}
        navigate(
          {
            pathname: "/listingbidnow",
            search: createSearchParams({
              search_type: "hour",
              city: value != "" ? value : "",
              book_for: getHours,
              check_in_date: moment(
                checkInOutValue.checkInTime.toString()
              ).format("DD/MM/YYYY"),
              adults: guestRoomData.adults,
              children: guestRoomData.child,
              rooms: guestRoomData.rooms,
            }).toString(),
          },
          {
            state: {
              search_type: "hour",
              city: value != "" ? value : "",
              book_for: getHours,
              check_in_date: moment(
                checkInOutValue.checkInTime.toString()
              ).format("DD/MM/YYYY"),
              adults: guestRoomData.adults,
              children: guestRoomData.child,
              rooms: guestRoomData.rooms,
            },
          },
          { replace: true }
        );
      }
    }
  };

  const bidsearchnow = (event) => {
    event.preventDefault();
    var startDate = new Date(selectFavouriteHotelSearchData.checkInTime);
    var endDate = new Date(selectFavouriteHotelSearchData.checkOutTime);
    if (value.length == 0) {
      setPlaceSearchError("Please Select The Place Your want to search");
      return;
    }

    if (endDate.getTime() <= startDate.getTime()) {
      errorToast("The check out date must be bigger than the check in date");
      return;
    }

    if (location.pathname == "/listingbidnow") {
      const data = {
        language: languageToShow,
        filter: searchFilterAddOrNot,
        search_type: searchType,
        city: value != null ? value : "",
        book_for: getHours,
        check_in_date: moment(checkInOutValue.checkInTime.toString()).format(
          "DD/MM/YYYY"
        ),
        check_out_date: moment(
          (checkInOutValue.checkOutTime == null
            ? null
            : checkInOutValue.checkOutTime
          ).toString()
        ).format("DD/MM/YYYY"),
        adults: guestRoomData.adults,
        children: guestRoomData.child,
        rooms: guestRoomData.rooms,
        sort_by: "recommended",
        filters: encodeURIComponent(JSON.stringify(searchFilterData)),
      };
      //console.log("data-workig-on",data);
      const dataSearch = {
        place: value,
        roomdata: guestRoomData,
        getHours: getHours,
        searchType: searchType,
        searchButtonShow: searchType,
        checkInTime: moment(checkInOutValue.checkInTime.toString()).format(
          "DD/MM/YYYY"
        ),
        checkOutTime:
          checkInOutValue.checkOutTime != null
            ? moment(checkInOutValue.checkOutTime.toString()).format(
                "DD/MM/YYYY"
              )
            : null,
      };
      placeStateDataSave(value);
      searchDataSave(dataSearch);
      getHotelListRequest(data);

      // navigate({
      //     pathname: location.pathname,
      //     search: createSearchParams({
      //         search_type: "bid",
      //         city: `${"Dubai"}`,
      //         check_in_date: moment((checkInOutValue.checkInTime).toString()).format("DD/MM/YYYY"),
      //         check_out_date: moment((checkInOutValue.checkOutTime).toString()).format("DD/MM/YYYY"),
      //         adults: guestRoomData.adults,
      //         children: guestRoomData.child,
      //         rooms: guestRoomData.rooms
      //     }).toString()
      // },{ replace: true });
    } else {
      navigate(
        {
          pathname: "/listingbidnow",
          search: createSearchParams({
            search_type: "bid",
            city: value != "" ? value : "",
            check_in_date: moment(
              checkInOutValue.checkInTime.toString()
            ).format("DD/MM/YYYY"),
            check_out_date: moment(
              (checkInOutValue.checkOutTime == null
                ? null
                : checkInOutValue.checkOutTime
              ).toString()
            ).format("DD/MM/YYYY"),
            adults: guestRoomData.adults,
            children: guestRoomData.child,
            rooms: guestRoomData.rooms,
          }).toString(),
        },
        {
          state: {
            search_type: "bid",
            city: value != "" ? value : "",
            check_in_date: moment(
              checkInOutValue.checkInTime.toString()
            ).format("DD/MM/YYYY"),
            check_out_date: moment(
              (checkInOutValue.checkOutTime == null
                ? null
                : checkInOutValue.checkOutTime
              ).toString()
            ).format("DD/MM/YYYY"),
            adults: guestRoomData.adults,
            children: guestRoomData.child,
            rooms: guestRoomData.rooms,
          },
        },
        { replace: true }
      );
    }
  };
  const dateFormat = "YYYY-MM-DD";
  // console.log("getHours",getHours );
  // console.log("WWEERRR",guestRoomData);
  const handleSelectt = (key) => {
    //console.log(key, ';;', typeof key)
    if (key === "first") {
      setSearchType("hour");
    } else {
      setSearchType("bid");
    }
  };
  //console.log("WWEEEE",guestRoomData,getHours,searchParams.get('search_type'),searchType);
  useEffect(() => {
    
   if(selectHotelBidNowPageRouteData == "BiddingDetails" ) {
    console.log("hello world",selectHotelBidNowPageRouteData);
    } else {

    const dataSearch = {
      place: value,
      roomdata: guestRoomData,
      getHours: getHours,
      searchType: searchType,
      searchButtonShow: searchtypeShowButton,
      checkInTime: moment(checkInOutValue.checkInTime.toString()).format(
        "DD/MM/YYYY"
      ),
      checkOutTime:
        checkInOutValue.checkOutTime != null
          ? moment(checkInOutValue.checkOutTime.toString()).format("DD/MM/YYYY")
          : null,
    };
    searchDataSave(dataSearch);
    console.log("hello-world",selectHotelBidNowPageRouteData,dataSearch);
  }
  }, [
    guestRoomData,
    getHours,
    searchType,
    checkInOutValue,
    value,
    longaddress,
    selectHotelBidNowPageRouteData
  ]);
  // useMemo(() => {
  // console.log("Hellomultiple times",selectHotelBidNowPageRouteData,guestRoomData)
  // },[guestRoomData,
  //   getHours,
  //   searchType,
  //   checkInOutValue,
  //   value,
  //   longaddress,
  //   selectHotelBidNowPageRouteData])



  // useEffect(() => {
  // return () => {
  //   const dataSearch = {
  //     place: value,
  //     roomdata: guestRoomData,
  //     getHours: getHours,
  //     searchType: searchType,
  //     searchButtonShow: searchtypeShowButton,
  //     checkInTime: moment(checkInOutValue.checkInTime.toString()).format(
  //       "DD/MM/YYYY"
  //     ),
  //     checkOutTime:
  //       checkInOutValue.checkOutTime != null
  //         ? moment(checkInOutValue.checkOutTime.toString()).format("DD/MM/YYYY")
  //         : null,
  //   };
  //   searchDataSave(dataSearch); 
  // }  
  // },[]);
  return (
    <>
      <Tabs
        defaultActiveKey={
          searchParams.get("search_type") == "hour" ? "first" : "second"
        }
        onSelect={handleSelectt}
      >
        <Tab eventKey="first" title="Hourly Stay">
          <div className="tab-container hourly-stay">
            <form onSubmit={searchsubmit}>
              <div className="form-content">
                <div className="left">
                  <Form.Label>WHERE?</Form.Label>
                  <Form.Group className="form-box">
                    {/* <Autocomplete
                      className="location form-control"
                      defaultValue={""}
                      apiKey={process.env.REACT_APP_GoogleAPIKEY}
                      searchOptions={{ types: ['all'] }}
                      onPlaceSelected={(place) => {
                      console.log("place",place);
                        // setPlaceSearchError();
                        // setLongaddress(place.formatted_address);
                        // setPlace(
                        //   !!place.address_components
                        //     ? place.address_components[0].long_name
                        //     : place.name
                        // );
                      }}
                      onChange={(e) => setLongaddress(e.target.value)}
                      value={longaddress}
                    /> */}
      <Combobox onSelect={(e) => handleSelect(e)} aria-labelledby="demo">
        <ComboboxInput
        defaultChecked={"Riyad"}
          // style={{ width: 300, maxWidth: "90%" }}
          value={value}
          onChange={handleInput}
          disabled={!ready}
          className="location form-control"
        />
        <ComboboxPopover>
          <ComboboxList>{status === "OK" && renderSuggestions()}</ComboboxList>
        </ComboboxPopover>
      </Combobox>
                  </Form.Group>
                  <Form.Group className="form-box checkin">
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DatePicker
                        className="datepickercheck-in"
                        label="Check-in"
                        value={checkInOutValue.checkInTime}
                        onChange={(newValue) => {
                          setCheckInOutValue((checkInOutValue) => ({
                            ...checkInOutValue,
                            checkInTime: newValue,
                          }));
                        }}
                        disablePast
                        renderInput={(params) => <TextField {...params} />}
                        onClose={() => {
                          setIsOpen(false);
                          handleOpen();
                        }}
                        KeyboardButtonProps={{
                          onClick: (e) => {
                            setIsOpen(true);
                          },
                        }}
                        InputProps={{
                          onClick: () => {
                            setIsOpen(true);
                          },
                        }}
                        open={isOpen}
                        inputFormat="DD MMM YYYY"
                      />
                    </LocalizationProvider>
                    {/* <Modal className="newmodal"
                                                                open={open}
                                                                onClose={handleClose}
                                                                aria-labelledby="modal-modal-title"
                                                                aria-describedby="modal-modal-description"
                                                            >
                                                                <Box sx={style}>
                                                                     <Typography id="modal-modal-title" variant="h6" component="h2">
                                                                        Text in a modal
                                                                    </Typography> 
                                                                    <Typography id="modal-modal-description" sx={{ mt: 2 }} className="hourlybook" onChange={handleHourscollect}  >
                                                                     Book For
                                                                    <Form.Select aria-label="Default select example">
                                                                    <option>Hours</option>
                                                                    <option value="3">3 Hour</option>
                                                                    <option value="6">6 Hours</option>
                                                                    <option value="12">12 Hours</option>
                                                                    </Form.Select>
                                                                    </Typography>
                                                                </Box>
                                                            </Modal> */}
                    <div
                      className="pophours"
                      style={open ? { display: "block" } : { display: "none" }}
                    >
                      <Box sx={style}>
                        {/* <Typography id="modal-modal-title" variant="h6" component="h2">
                                                                        Text in a modal
                                                                    </Typography> */}
                        <Typography
                          id="modal-modal-description"
                          sx={{ mt: 2 }}
                          className="hourlybook"
                          onChange={handleHourscollect}
                        >
                          Book For
                          <Form.Select aria-label="Default select example">
                            <option>Hours</option>
                            <option value="3">3 Hour</option>
                            <option value="6">6 Hours</option>
                            <option value="12">12 Hours</option>
                          </Form.Select>
                        </Typography>
                      </Box>
                    </div>

                    {getHours != null && getHours > 0 ? (
                      <span className="hourlable">{getHours} Hours</span>
                    ) : null}
                  </Form.Group>
                  <Form.Group className="form-box pop-form">
                    <Form.Control
                      type="text"
                      className="room"
                      // placeholder={`${
                      //   guestRoomData.adults + guestRoomData.child
                      // } Guest / ${guestRoomData.rooms} Room`}

                      placeholder={`${
                        guestRoomData.adults + guestRoomData.child
                      } ${
                        guestRoomData.adults + guestRoomData.child > 1
                          ? "Guests"
                          : "Guest"
                      }  / ${guestRoomData.rooms} ${guestRoomData.rooms>1?"Rooms":"Room"}
                      
                      `}
                      onClick={guestAndRoom}
                    />
                    <div
                      className="guestpop"
                      ref={ref1}
                      style={
                        guestRomsPopup
                          ? { display: "block" }
                          : { display: "none" }
                      }
                    >
                      <h3>Add Guest(s) And Room(s)</h3>
                      <ul>
                        <li>
                          <h4>Room (s)</h4>
                          <div className="counting">
                            <Button
                              onClick={() => {
                                handleDecrease("room");
                              }}
                            >
                              <AiOutlineMinusCircle />
                            </Button>
                            {guestRoomData.rooms}
                            <Button
                              onClick={() => {
                                handleIncrease("room");
                              }}
                            >
                              <BsPlusCircle />
                            </Button>
                          </div>

                          {/* <Button
                              onClick={() => {
                                handleDecrease("room");
                              }}
                            >
                              <AiOutlineMinusCircle />
                            </Button>
                            {guestRoomData.rooms}
                            <div className="counting">
                            <Button
                              onClick={() => {
                                handleIncrease("room");
                              }}
                            >
                              <BsPlusCircle />
                            </Button> */}
                          {/* </div> */}
                        </li>
                        <li>
                          <h4>Adult (s) </h4>
                          <div className="counting">
                            <Button
                              onClick={() => {
                                handleDecrease("adult");
                              }}
                            >
                              <AiOutlineMinusCircle />
                            </Button>
                            {guestRoomData.adults}
                            <Button
                              onClick={() => {
                                handleIncrease("adult");
                              }}
                            >
                              <BsPlusCircle />
                            </Button>
                          </div>
                        </li>
                        <li>
                          <h4>
                            Children (s) <span>Max 11 years</span>
                          </h4>
                          <div className="counting">
                            <Button
                              onClick={() => {
                                handleDecrease("children");
                              }}
                            >
                              <AiOutlineMinusCircle />
                            </Button>
                            {guestRoomData.child}
                            <Button
                              onClick={() => {
                                handleIncrease("children");
                              }}
                            >
                              <BsPlusCircle />
                            </Button>
                          </div>
                        </li>
                      </ul>
                    </div>
                    {/* <Dialog
                                    open={true}
                                    onClose={handleClose}
                                    aria-labelledby="alert-dialog-title"
                                    aria-describedby="alert-dialog-description"
                                    PaperProps={{
                                        sx: {
                                            width: "30%",
                                            height: "50%",
                                            position: "absolute",
                                            top: 10,
                                            left: 10,
                                            m: 0
                                        }
                                    }}
                                ></Dialog> */}
                  </Form.Group>
                </div>
                <div className="right">
                  <button type="submit"></button>
                </div>
              </div>
            </form>
          </div>
        </Tab>
        <Tab
          eventKey="second"
          onClick={() => {
            setSearchType("bid");
          }}
          title="Bid Now"
        >
          <div className="tab-container bid-now">
            <form onSubmit={bidsearchnow}>
              <div className="form-content">
                <div className="left">
                  <Form.Label>WHERE?</Form.Label>
                  <Form.Group className="form-box">
                    {/* <Autocomplete
                      className="location form-control"
                      apiKey={process.env.REACT_APP_GoogleAPIKEY}
                      defaultValue={place}
                      onPlaceSelected={(place) => {
                        setPlaceSearchError();
                        setLongaddress(place.formatted_address);
                        setPlace(
                          !!place.address_components
                            ? place.address_components[0].long_name
                            : place.name
                        );
                      }}
                      onChange={(e) => setLongaddress(e.target.value)}
                      value={longaddress}
                    /> */}
                       <Combobox onSelect={(e) => handleSelect(e)} aria-labelledby="demo">
        <ComboboxInput
        defaultChecked={"Riyad"}
          // style={{ width: 300, maxWidth: "90%" }}
          value={value}
          onChange={handleInput}
          disabled={!ready}
          className="location form-control"
        />
        <ComboboxPopover>
          <ComboboxList>{status === "OK" && renderSuggestions()}</ComboboxList>
        </ComboboxPopover>
      </Combobox>
                  </Form.Group>
                  <div className="bidchecking">
                    <Form.Group className="form-box">
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          className="datepickercheck-in check-in"
                          label="Check-in"
                          value={checkInOutValue.checkInTime}
                          onChange={(newValue) => {
                            // setValue();
                            setCheckInOutValue((checkInOutValue) => ({
                              ...checkInOutValue,
                              checkInTime: newValue,
                            }));
                          }}
                          disablePast
                          renderInput={(params) => <TextField {...params} />}
                          onClose={() => setCheckIn(false)}
                          KeyboardButtonProps={{
                            onClick: (e) => {
                              setCheckIn(true);
                            },
                          }}
                          InputProps={{
                            onClick: () => {
                              setCheckIn(true);
                            },
                          }}
                          open={checkIn}
                          inputFormat="DD MMM YYYY"
                        />
                      </LocalizationProvider>
                    </Form.Group>
                    <Form.Group className="form-box check-out">
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          className="datepickercheck-in"
                          label="Check-out"
                          value={checkInOutValue.checkOutTime}
                          onChange={(newValue) => {
                            //setValue(moment(newValue).format("DD/MM/YYYY"));
                            setCheckInOutValue((checkInOutValue) => ({
                              ...checkInOutValue,
                              checkOutTime: newValue,
                            }));
                          }}
                          renderInput={(params) => <TextField {...params} />}
                          onClose={() => setCheckoutTime(false)}
                          KeyboardButtonProps={{
                            onClick: (e) => {
                              setCheckoutTime(true);
                            },
                          }}
                          disablePast
                          minDate={new Date(
                            checkInOutValue.checkInTime
                          ).setDate(
                            new Date(checkInOutValue.checkInTime).getDate() + 1
                          )}
                          InputProps={{
                            onClick: () => {
                              setCheckoutTime(true);
                            },
                          }}
                          open={checkoutTime}
                          inputFormat="DD MMM YYYY"
                        />
                      </LocalizationProvider>
                    </Form.Group>
                  </div>
                  <Form.Group className="form-box pop-form">
                    <Form.Control
                      type="text"
                      className="room"
                      // placeholder={`${
                      //   guestRoomData.adults + guestRoomData.child
                      // } Guests / ${guestRoomData.rooms} Room`}
                      placeholder={`${
                        guestRoomData.adults + guestRoomData.child
                      } ${
                        guestRoomData.adults + guestRoomData.child > 1
                          ? "Guests"
                          : "Guest"
                      }  / ${guestRoomData.rooms} ${guestRoomData.rooms>1?"Rooms":"Room"}`}
                      onClick={guestAndRoomsecond}
                    />
                    <div
                      className="guestpop"
                      ref={ref2}
                      style={
                        guestRomsPopupsecond
                          ? { display: "block" }
                          : { display: "none" }
                      }
                    >
                      <h3>Add Guest (s) And Room (s)</h3>
                      <ul>
                        <li>
                          <h4>Room (s)</h4>
                          <div className="counting">
                            <Button
                              onClick={() => {
                                handleDecrease("room");
                              }}
                            >
                              <AiOutlineMinusCircle />
                            </Button>
                            {guestRoomData.rooms}
                            <Button
                              onClick={() => {
                                handleIncrease("room");
                              }}
                            >
                              <BsPlusCircle />
                            </Button>
                          </div>
                        </li>
                        <li>
                          <h4>Adult (s) </h4>
                          <div className="counting">
                            <Button
                              onClick={() => {
                                handleDecrease("adult");
                              }}
                            >
                              <AiOutlineMinusCircle />
                            </Button>
                            {guestRoomData.adults}
                            <Button
                              onClick={() => {
                                handleIncrease("adult");
                              }}
                            >
                              <BsPlusCircle />
                            </Button>
                          </div>
                        </li>
                        <li>
                          <h4>
                            Children (s) <span>Max 11 years</span>
                          </h4>
                          <div className="counting">
                            <Button
                              onClick={() => {
                                handleDecrease("children");
                              }}
                            >
                              <AiOutlineMinusCircle />
                            </Button>
                            {guestRoomData.child}
                            <Button
                              onClick={() => {
                                handleIncrease("children");
                              }}
                            >
                              <BsPlusCircle />
                            </Button>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </Form.Group>
                </div>
                <div className="right">
                  <button type="submit">Search hotel</button>
                </div>
              </div>
            </form>
          </div>
        </Tab>
      </Tabs>
      <p style={{ color: "red1" }}>{placeSearchError}</p>
    </>
  );
};

const mapStateToProps = createStructuredSelector({
languageToShow: selectlanguageToShow,
searchFilterData: searchFilterData,
searchFilterAddOrNot: searchFilterAddOrNot,
selectFavouriteHotelSearchData: selectFavouriteHotelSearchData,
selectHotelDetailsPageRouteData:selectHotelDetailsPageRouteData,
selectHotelBidNowPageRouteData:selectHotelBidNowPageRouteData
});

const mapDispatchToProps = (dispatch) => ({
  searchDataSave: (data) => dispatch(searchDataSave(data)),
  getHotelListRequest: (data) => dispatch(getHotelListRequest(data)),
  placeStateDataSave: (data) => dispatch(placeStateDataSave(data)),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HotelSearchForOthers);
