import React, { useEffect, useTransition, useState } from "react";
import Pagination from "@mui/material/Pagination";
/*
This is a common component which has pagination with display.
The props you can pass are:
page:{
  required: true,
  description:It is an object which has all the page information like page no,total,page size(no of elements needed for per page)
}

handleChangePage:{
  required: true,
  description:It is a function which will call the main api of it's mother component after page change
}
displayShow:{
  required: false,
  description:It is a boolean value which will show the 'display' portion
}

*/
const PaginationWithDisplay = (props) => {
  return (
    <div className="col-md-12" >
      <div className="pagination-div">
        {props.displayShow ? (
          <div className="display-div-p-right">
            <label>Display</label> &nbsp;&nbsp;
            <select
              className="display-select-height"
              value={props.page.per_page_limit}
              onChange={(e) => {
                props.handleChangePage(e,props.page.page_no,e.target.value)
              }}
            >
              <option value={3}>3</option>
              <option value={10}>10</option>
              <option value={15}>15</option>
            </select>
          </div>
        ) : (
          ""
        )}

        {props.page.total > props.page.per_page_limit ? (
          <div>
            <Pagination
              boundaryCount={1}
              count={Math.ceil(props.page.total / props.page.per_page_limit)}
              defaultPage={1}
              onChange={(e, newPage)=>props.handleChangePage(e,newPage,props.page.per_page_limit)}
              page={props.page.page_no}
              showFirstButton={true}
              showLastButton={true}
            />
          </div>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default PaginationWithDisplay;
