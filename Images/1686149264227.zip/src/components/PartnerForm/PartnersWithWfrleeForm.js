import React, { useEffect, useState } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import validator from "validator";
import { connect } from "react-redux";

import { selectUserLoginData } from "../../redux/user/user.selectors";
import InputMask from "react-input-mask";
import {
  addPartnerRequest,
  stateClearAfterTask,
} from "../../redux/useraccount/useraccount.actions";
import { selectAddPartnerData } from "../../redux/useraccount/useraccount.selectors";
import { createStructuredSelector } from "reselect";
import axios from "axios";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const PartnersWithWfrleeForm = ({
  addPartnerRequest,
  partnerData,
  stateClear,
}) => {
  const [userData, setUserData] = useState({
    suppliername: "",
    firstname: "",
    lastname: "",
    email: "",
    mobileNo: "",
  });
  const [userDataError, setuserDataError] = useState({
    suppliernameErr: "",
    firstnameErr: "",
    lastnameErr: "",
    emailErr: "",
    mobileNoErr: "",
  });
  const [countryCode, setCountryCode] = React.useState("");
  const [countryCodeErr, setCountryCodeErr] = React.useState("");

  const navigate = useNavigate();

  /*** Country Code Selection   ***/
  const handleCountryCodeChange = (value, data, event, formattedValue) => {
    console.log("data.dialCode", data.dialCode);
    if (data.dialCode == "") {
      setCountryCode("");
    } else {
      setCountryCode(formattedValue);
      // setCountryCode("");
      setCountryCodeErr("");
    }
  };

  const handleChange = (e) => {
    console.log("eerrrww", e.target.name, e.target.value);
    if (e.target.name == "suppliername") {
      setuserDataError({
        ...userDataError,
        suppliernameErr: "",
      });
    } else if (e.target.name == "firstname") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "",
      });
    } else if (e.target.name == "lastname") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "",
      });
    } else if (e.target.name == "mobileNo") {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "",
      });
    } else {
      setuserDataError({
        ...userDataError,
        emailErr: "",
      });
    }
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const regex = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
    console.log("Hello wrld my start", userData.mobileNo.length);
    if (userData.suppliername == "") {
      setuserDataError({
        ...userDataError,
        suppliernameErr: "Please Enter Supplier Name",
      });
      return;
    } else if (userData.firstname == "") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "Please Enter Your First Name",
      });
      return;
    } else if (userData.lastname == "") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "Please Enter Your Last Name",
      });
      return;
    } else if (countryCode == "") {
      // countryCodeRef.current.focus();
      setCountryCodeErr("Please Select Your country code");
      return;
    } else if (userData.mobileNo == "") {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "Please Enter Your Mobile Number",
      });
      return;
    } else if (userData.mobileNo.length < 10 || userData.mobileNo.length > 10) {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "Atleast 10 Digits Required",
      });
      return;
    } else if (!validator.isEmail(userData.email)) {
      setuserDataError({
        ...userDataError,
        emailErr: "Please Enter a Valid Email Address",
      });
      return;
    } else {
      const data = {
        first_name: userData.firstname,
        last_name: userData.lastname,
        country_code: countryCode,
        contact_number: userData.mobileNo,
        email: userData.email,
      };
      const contact_person = [];
      contact_person.push(data);
      const dataToPost = {
        hotel_name: userData.suppliername,
        contact_person: contact_person,
      };

      console.log("data", dataToPost, contact_person);
      addPartnerRequest(dataToPost);
      setUserData({
        suppliername: "",
        firstname: "",
        lastname: "",
        email: "",
        mobileNo: "",
      });
    }
  };
  useEffect(() => {
    if (partnerData != null) {
      if (partnerData.success == true) {
        navigate("/");
      } else {
      }
      stateClear();
    }
  }, [JSON.stringify(partnerData)]);

  return (
    <>
      <>{console.log("partnerData", partnerData)}</>
      <Form onSubmit={handleSubmit} className={"careerForm"}>
        <h5 className="WL_partners_labelboldtext">Supplier Name *</h5>
        <Form.Group controlId="formPartnersSupplier">
          <Form.Control
            type="text"
            placeholder="Enter Supplier name"
            aria-label=""
            onChange={handleChange}
            value={userData.suppliername}
            name="suppliername"
          />
          <Form.Text className="text-muted">
            {userDataError.suppliernameErr}
          </Form.Text>
        </Form.Group>

        <h5 className="WL_partners_labelboldtext Wl_gap20">
          Contact Person’s Details
        </h5>
        <div className="form50">
          <Form.Group controlId="formPartnersFirstname">
            <Form.Label>Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="First Name"
              onChange={handleChange}
              value={userData.firstname}
              name="firstname"
            />
            <Form.Text className="text-muted">
              {userDataError.firstnameErr}
            </Form.Text>
          </Form.Group>
          <Form.Group className="lastname" controlId="formPartnersLastname">
            <Form.Label>Last Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="Last Name"
              name="lastname"
              onChange={handleChange}
              value={userData.lastname}
            />
            <Form.Text className="text-muted">
              {userDataError.lastnameErr}
            </Form.Text>
          </Form.Group>
        </div>
        <div className="form50">
          <Form.Group controlId="formPartnersPhone">
            <Form.Label>Mobile Number *</Form.Label>
            <Form.Group
              controlId="formCheckoutPhone"
              className="phoneWithCountryCode"
            >
              <Form.Group controlId="formCheckoutCountryCode">
                <PhoneInput
                  // defaultCountry="IN"
                  autoFormat={false}
                  enableSearch={true}
                  // country={"in"}
                  value={countryCode}
                  onChange={handleCountryCodeChange}
                  name="countryCode"
                  placeholder={"+91"}
                  className="checkoutcountryCodeInput"
                />
              </Form.Group>
              <Form.Group
                controlId="formCheckoutPoneNumber"
                className="checkoutPhoneNumber"
              >
                <Form.Control
                  type="Number"
                  placeholder="Mobile Number"
                  name="mobileNo"
                  value={userData.mobileNo}
                  onChange={handleChange}
                />
              </Form.Group>
            </Form.Group>
            <Form.Text className="text-muted">
              {userDataError.mobileNoErr} {countryCodeErr}
            </Form.Text>
          </Form.Group>
          <Form.Group controlId="formPartnersEmail">
            <Form.Label>E-mail *</Form.Label>
            <Form.Control
              type="email"
              placeholder="E-mail address"
              name="email"
              value={userData.email}
              onChange={handleChange}
            />
            <Form.Text className="text-muted">
              {userDataError.emailErr}
            </Form.Text>
          </Form.Group>
        </div>

        <Button variant="" type="submit" className="formsubmit">
          Send
        </Button>
      </Form>
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  partnerData: selectAddPartnerData,
  userAuthData: selectUserLoginData,
});

const mapDispatchToProps = (dispatch) => ({
  addPartnerRequest: (data) => dispatch(addPartnerRequest(data)),
  stateClear: () => dispatch(stateClearAfterTask()),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PartnersWithWfrleeForm);
