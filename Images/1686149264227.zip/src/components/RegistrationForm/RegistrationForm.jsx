import React, { useEffect, useState } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { AiOutlineEye } from "react-icons/ai";
import { Link, useNavigate } from "react-router-dom";
import { AiOutlineEyeInvisible } from "react-icons/ai";
import validator from "validator";
import { connect } from "react-redux";
import {
  signUpStart,
  stateClearAfterTask,
} from "./../../redux/user/user.actions";
import {
  selectSignUpMessage,
  selectSignupLoader,
} from "./../../redux/user/user.selectors";
import { createStructuredSelector } from "reselect";
import InputMask from "react-input-mask";
import Countries from "./../../assets/country-data/countrydata.json";
import { useSearchParams, useLocation } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
const RegistrationForm = ({
  signUpStart,
  signUpmessage,
  stateClear,
  selectSignupLoader,
  handleCloseLoginPopup,
  search_type,
}) => {
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState("");
  const [dropDownOpen, setDropDownOpen] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState(null);
  const currentLocation = useLocation();
  const [userData, setUserData] = useState({
    firstname: "",
    lastname: "",
    phoneno: "",
    // country_code: "",
    email: "",
    password: "",
    confirmpassword: "",
    referralcode:
      searchParams.get("referral_code") == null
        ? ""
        : searchParams.get("referral_code"),
    termsandConditions: false,
  });

  const [eyes, setEyes] = useState({
    password: false,
    confirmpassword: false,
  });
  const [userDataError, setuserDataError] = useState({
    firstnameErr: "",
    lastnameErr: "",
    // countrycodeErr: "",
    phonenoErr: "",
    emailErr: "",
    passwordErr: "",
    conformpasswordErr: "",
    referralcodeErr: "",
    termsmessage: "",
  });
  const [countryCode, setCountryCode] = React.useState("");
  const [countryCodeErr, setCountryCodeErr] = React.useState("");

  const navigate = useNavigate();
  const handletermspolicy = (e) => {
    if (e.target.checked) {
      setUserData({
        ...userData,
        termsandConditions: true,
      });
      setuserDataError({
        ...userDataError,
        termsmessage: "",
      });
    } else {
      setUserData({
        ...userData,
        termsandConditions: false,
      });
    }
  };

  /*** Country Code Selection   ***/
  const handleCountryCodeChange = (value, data, event, formattedValue) => {
    if (data.dialCode == "") {
      setCountryCode("");
    } else {
      setCountryCode(formattedValue);
      // setCountryCode("");
      setCountryCodeErr("");
    }
  };

  const handleChange = (e) => {
    if (e.target.name == "firstname") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "",
      });
    } else if (e.target.name == "lastname") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "",
      });
      // } else if (e.target.name == "country_code") {
      //   setuserDataError({
      //     ...userDataError,
      //     countrycodeErr: "",
      //   });
    } else if (e.target.name == "phoneno") {
      setuserDataError({
        ...userDataError,
        phonenoErr: "",
      });
    } else if (e.target.name == "email") {
      setuserDataError({
        ...userDataError,
        emailErr: "",
      });
    } else if (e.target.name == "password") {
      setuserDataError({
        ...userDataError,
        passwordErr: "",
      });
    } else {
      setuserDataError({
        ...userDataError,
        conformpasswordErr: "",
      });
    }
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const regex = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
    //console.log("Hello wrld my start",userData.phoneno.length);
    console.log("phone Digits", !isNaN(userData.phoneno));
    if (userData.firstname == "") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "Please Enter Your First Name",
      });
      return;
    } else if (userData.lastname == "") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "Please Enter Your Last Name",
      });
      return;
      // } else if (userData.country_code == "") {
      //   setuserDataError({
      //     ...userDataError,
      //     countrycodeErr: "Please Enter Your Country Code",
      //   });
    } else if (countryCode == "") {
      // countryCodeRef.current.focus();
      setCountryCodeErr("Please Select Your country code");
      return;
    } else if (userData.phoneno == "") {
      setuserDataError({
        ...userDataError,
        phonenoErr: "Please Enter Your Phone Number",
      });
      return;
    } else if (isNaN(userData.phoneno)) {
      setuserDataError({
        ...userDataError,
        phonenoErr: "Please Enter Your Phone Number Digit",
      });
      return;
    } else if (userData.phoneno.length < 10 || userData.phoneno.length > 10) {
      setuserDataError({
        ...userDataError,
        phonenoErr: "10 digit number allow only",
      });
      return;
    } else if (!validator.isEmail(userData.email)) {
      setuserDataError({
        ...userDataError,
        emailErr: "Please Enter a Valid Email Address",
      });
      return;
    } else if (userData.password.length < 8) {
      setuserDataError({
        ...userDataError,
        passwordErr: "Atleast 8 characters are required",
      });
      return;
    } else if (userData.password !== userData.confirmpassword) {
      setuserDataError({
        ...userDataError,
        conformpasswordErr: "Password and Confirm Password Not Same",
      });
      return;
    } else if (userData.termsandConditions === false) {
      setuserDataError({
        ...userDataError,
        termsmessage: "Please checked terms and conditions",
      });
    } else if (userData.termsandConditions === false) {
      setuserDataError({
        ...userDataError,
        termsmessage: "Please checked terms and conditions",
      });
    } else {
      const data = {
        first_name: userData.firstname,
        last_name: userData.lastname,
        email: userData.email,
        contact_no: userData.phoneno,
        password: userData.password,
        country_code: countryCode,
      };
      signUpStart(data);
    }
  };
  useEffect(() => {
    if (signUpmessage != null) {
      if (signUpmessage.success == true) {
        setUserData({
          firstname: "",
          lastname: "",
          country_code: "",
          phoneno: "",
          email: "",
          password: "",
          confirmpassword: "",
          referralcode: "",
          termsandConditions: false,
        });
        if (currentLocation.pathname == "/login" || currentLocation.pathname == "/sign-up") {
          navigate("/");
        } else {
          handleCloseLoginPopup();
        }
      } else {
      }
      stateClear();
    }
  }, [JSON.stringify(signUpmessage)]);

  const handleeyeshowhide = (number) => {
    if (number == 2) {
      setEyes({
        ...eyes,
        confirmpassword: !eyes.confirmpassword,
      });
    } else {
      setEyes({
        ...eyes,
        password: !eyes.password,
      });
    }
  };
  console.log("search", search);

  return (
    <>
      <Form onSubmit={handleSubmit}>
        <div className="form50">
          <Form.Group controlId="formBasicFirstname">
            <Form.Label>First Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="First Name"
              onChange={handleChange}
              value={userData.firstname}
              name="firstname"
            />
            <Form.Text className="text-muted errorformmessage">
              {userDataError.firstnameErr}
            </Form.Text>
          </Form.Group>
          <Form.Group controlId="formBasicLastname">
            <Form.Label>Last Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="Last Name"
              name="lastname"
              onChange={handleChange}
              value={userData.lastname}
            />
            <Form.Text className="text-muted errorformmessage">
              {userDataError.lastnameErr}
            </Form.Text>
          </Form.Group>
        </div>
        <div className="form50 countryCodePhoneDiv">
          <Form.Group controlId="formBasicPhone">
            <Form.Label>Country Code *</Form.Label>
            <PhoneInput
              // country={"us"}
              name="country_code"
              placeholder={"+91"}
              enableSearch={true}
              onKeyDown={(phone) => console.log("test", phone.target.value)}
              className="countryCodeInput"
              // value={userData.country_code}
              // onChange={handleChange}
              value={countryCode}
              onChange={handleCountryCodeChange}
            />
            {/*}  <Form.Select aria-label="Default select example" name="country_code" onChange={handleChange} className="form-control">
<option value={""} selected={userData.country_code == "" ? true : false} >Select Country Code</option>
{
 Countries.map((country) => { 
  return (
    <option value={country.phone_code}><img src={`http://demoyourprojects.com:5083/public/image/country_list/${String(country.iso2).toLocaleLowerCase()}.png`} /> {country.name} </option>
  )
 } )       
}  
</Form.Select>  
            {/* <input type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value.toLowerCase());
                setDropDownOpen(true);
              }} />
              <img src={`http://demoyourprojects.com:5083/public/image/country_list/${String(search).toLocaleLowerCase()}.png`}  />  */}
            {/* <Form.Button
              type="button"
              onClick={(e) => {
                setDropDownOpen((prevState) => !prevState);
                setSelectedCountry(null);
                setSearch("");
              }}
            >
              {dropDownOpen ? "^" : "v"}
            </Form.Button> */}
            {/* <button
              onClick={(e) => {
                setDropDownOpen((prevState) => !prevState);
                setSelectedCountry(null);
                setSearch("");
              }}
            >
              {
                dropDownOpen ? "^" : "v"
              }
            </button> */}

            {/* {dropDownOpen && (
              <div className="country-list">
                {Countries
                  .filter((_c) => _c.name.toLowerCase().includes(search))
                  .map((_c) => (
                    <div
                      className="country"
                      key={_c.id}
                      id={_c.id}
                      onClick={() => {
                        setSelectedCountry(_c);
                        setSearch(_c.iso2.toLowerCase());
                        setDropDownOpen(false);
                      }}
                    >
                      <img
                        alt=""
                        src={`http://demoyourprojects.com:5083/public/image/country_list/${String(_c.iso2).toLocaleLowerCase()}.png`}
                      />
                      <h4>{_c.name}</h4>
                    </div>
                  ))}
              </div>
            )} */}
            <Form.Text className="text-muted errorformmessage">
              {countryCodeErr}
            </Form.Text>
          </Form.Group>
          {/* <Dropdown className="form-control">
      <Dropdown.Toggle variant="secondary"  id="dropdown-basic">
        Select Country Code
      </Dropdown.Toggle>
       <Dropdown.Menu  style={{overflow:"scroll",height:"200px",width:"100%"}} name="countrycode" onSelect={handleChange}>
     
      </Dropdown.Menu>
    </Dropdown> */}

          <Form.Group controlId="formBasicPhone">
            <Form.Label>Phone Number *</Form.Label>
            <Form.Control
              type="tel"
              className="form-control"
              placeholder="Phone number"
              name="phoneno"
              value={userData.phoneno}
              onChange={handleChange}
            />
            <Form.Text className="text-muted errorformmessage">
              {userDataError.phonenoErr}
            </Form.Text>
          </Form.Group>
        </div>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>E-mail *</Form.Label>
          <Form.Control
            type="email"
            placeholder="Email address"
            name="email"
            value={userData.email}
            onChange={handleChange}
          />
          <Form.Text className="text-muted errorformmessage">
            {userDataError.emailErr}
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formBasicPassword">
          <Form.Label>Password *</Form.Label>
          <div className="passwordsec">
            <Form.Control
              type={eyes.password ? "text" : "password"}
              placeholder="Password"
              name="password"
              value={userData.password}
              onChange={handleChange}
            />
            {eyes.password ? (
              <AiOutlineEye
                onClick={() => {
                  handleeyeshowhide();
                }}
              />
            ) : (
              <AiOutlineEyeInvisible
                onClick={() => {
                  handleeyeshowhide();
                }}
              />
            )}
          </div>
          <Form.Text className="text-muted errorformmessage">
            {userDataError.passwordErr}
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formBasicPassword">
          <Form.Label>Confirm Password *</Form.Label>
          <div className="passwordsec">
            <Form.Control
              type={eyes.confirmpassword ? "text" : "password"}
              name="confirmpassword"
              placeholder="Confirm password"
              value={userData.confirmpassword}
              onChange={handleChange}
            />
            {eyes.confirmpassword ? (
              <AiOutlineEye
                onClick={() => {
                  handleeyeshowhide(2);
                }}
              />
            ) : (
              <AiOutlineEyeInvisible
                onClick={() => {
                  handleeyeshowhide(2);
                }}
              />
            )}
          </div>
          <Form.Text className="text-muted errorformmessage">
            {userDataError.conformpasswordErr}
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formBasicReferral">
          <Form.Label>Referral Code</Form.Label>
          <div className="passwordsec">
            <Form.Control
              type="text"
              placeholder="Referral code"
              name="referralcode"
              value={userData.referralcode}
              onChange={handleChange}
            />
          </div>
        </Form.Group>
        <Form.Group className="form-checkbox" controlId="formBasicCheckbox">
          <Form.Check
            type="checkbox"
            checked={userData.termsandConditions}
            onClick={handletermspolicy}
            label=""
          />
          I agree all the{" "}
          <Link to="/terms&conditions" target="_blank">
            terms and conditions
          </Link>{" "}
          &{" "}
          <Link to="/privacy-policy" target="_blank">
            privacy policy
          </Link>
          <Form.Text className="text-muted errorformmessage">
            {userDataError.termsmessage}
          </Form.Text>
        </Form.Group>
        <Button variant="primary" type="submit" className="formsubmit">
          {selectSignupLoader ? (
            <Spinner animation="border" variant="light" />
          ) : (
            "SIGNUP"
          )}
        </Button>
      </Form>
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  signUpmessage: selectSignUpMessage,
  selectSignupLoader: selectSignupLoader,
});
const mapDispatchToProps = (dispatch) => ({
  signUpStart: (data) => dispatch(signUpStart(data)),
  stateClear: () => dispatch(stateClearAfterTask()),
});

export default connect(mapStateToProps, mapDispatchToProps)(RegistrationForm);
