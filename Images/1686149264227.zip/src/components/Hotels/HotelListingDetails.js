import React, { useState } from "react";
import {
  Button,
  Dropdown,
  Form,
  Tabs,
  Tab,
  Pagination,
  Modal,
} from "react-bootstrap";
import { Link } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import addressIcon from "../../assets/images/icon-list-map.svg";
import starIcon from "../../assets/images/icon-review-star.svg";
import shareIcon from "../../assets/images/icon-share.svg";
import HotelSearchForOthers from "./../../components/HeaderSearch/HeaderSearch";
// import Link from '@mui/material/Link';
import Fade from "@mui/material/Fade";

import {
  selectUserLoginData,
  selectSocialLoginUser,
} from "../../redux/user/user.selectors";
import slideImage1 from "../../assets/images/details-popup-slide-1.jpg";
import slideImage2 from "../../assets/images/details-popup-slide-2.jpg";
import slideImage3 from "../../assets/images/details-slide-1.jpg";
import { stateClearAfterTask } from "../../redux/hotels/hotel.actions";

import moment from "moment";
import { ReactComponent as FavouriteIcon } from "../../assets/images/icon-list-favourite.svg";
import {
  addFavouriteHotelRequest,
  removeFavouriteHotelRequest,
  // getAllFavouriteHotelListRequest,
  getFullHotelDetailsRequest,
  hotelWheatherApiRequest,
} from "../../redux/hotels/hotel.actions";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import {
  selectFavouriteHotel,
  // selectFavouriteHotelList,
  selectFavouriteHotelSearchData,
} from "../../redux/hotels/hotel.selectors";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { selectHotelData } from "./../../redux/hotels/hotel.selectors";
import { errorToast, successToast } from "../../utils/toastHelper";
import ShareModal from "../../utils/ShareModal";
import GoogleMaps from "../googleMaps/googleMaps";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import Skeleton from "react-loading-skeleton";
import "react-loading-skeleton/dist/skeleton.css";
import { selectcurrencyToShow } from "../../redux/currency/currency.selectors";
import Tooltip from "@mui/material/Tooltip";

const HotelListingDetails = ({
  languageToShow,
  selectHotelData,
  addFavouriteHotelRequest,
  removeFavouriteHotelRequest,
  // selectFavouriteHotelList,
  // getAllFavouriteHotelListRequest,
  favouriteHotel,
  hotel_slug,
  userAuthData,
  userSocialAuthData,
  searchsavedData,
  currencyToShow,
  stateClearAfterTask,
  hotelWheatherApiRequest,
}) => {
  var [show, setShow] = useState(false);
  var handleClose = () => setShow(false);
  var handleShow = () => setShow(true);
  const [isReadMore, setIsReadMore] = useState(true);
  const [isAddedFavourite, setIsAddedFavourite] = useState();
  const [openSharePopup, setOpenSharePopup] = React.useState(false);
  const [isCopied, setIsCopied] = React.useState(false);
  const [shareCode, setShareCode] = React.useState();
  const [nav1, setNav1] = useState();
  const [nav2, setNav2] = useState();
  const [count, setCount] = useState(2);

  const [showMoreAmenities, setShowMoreAmenities] = useState(true);
  // const stateParams = useLocation();
  // const { searchData } = stateParams.state;
  const [searchParams] = useSearchParams();
  const [hovered, setHovered] = useState(false);
  const [timeSlotIndex, setTimeSlotIndex] = useState();
  const location = useLocation();
  console.log("currencyToShow-->", currencyToShow);
  console.log("sss", selectHotelData);
  const navigate = useNavigate();
  const toggleReadMore = () => {
    setIsReadMore(!isReadMore);
  };

  const toggleShowMore = () => {
    setShowMoreAmenities(!showMoreAmenities);
  };
  var customerreview = {
    arrows: true,
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 575,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  var hotellistSlide = {
    arrows: true,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
  };

  var detailsSlider = {
    arrows: true,
    dots: false,
    infinite: true,
    autoplay: true,
    speed: 500,
    slidesToScroll: 1,
    autoplaySpeed: 2000,
  };

  var sideSlider = {
    arrows: false,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
    focusOnSelect: true,
    centerMode: false,
    autoplay: true,
    autoplaySpeed: 2000,
    slidesToShow: 2,
    vertical: true,
    // centerPadding: 10,
    // afterChange: (indexOfCurrentSlide) => indexOfCurrentSlide + 1,
  };

  var popSlider = {
    arrows: true,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToScroll: 1,
  };

  React.useEffect(() => {
    console.log("searchParams", searchParams);
    if (searchParams.get("search_type") == "bid") {
      const searchedParams = {
        search_type: searchParams.get("search_type"),
        city: searchParams?.get("city"),
        check_in_date: searchParams.get("check_in_date"),
        check_out_date: searchParams.get("check_out_date"),
        adults: searchParams.get("adults"),
        children: searchParams.get("children"),
        rooms: searchParams.get("rooms"),
      };

      const fullHotelDetailsParam = {
        hotel_slug: hotel_slug,
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        searchedParams: searchedParams,
      };
      stateClearAfterTask();

      getFullHotelDetailsRequest(fullHotelDetailsParam);
    }

    if (searchParams.get("search_type") == "hour") {
      const searchedParams = {
        search_type: searchParams.get("search_type"),
        book_for: searchParams?.get("book_for"),
        city: searchParams?.get("city"),
        // hotel_id: selectHotelData?.data?.id,
        // room_type_id: room._id,
        check_in_date: searchParams.get("check_in_date"),
        // check_out_date: searchParams.get("check_out_date"),
        adults: searchParams.get("adults"),
        children: searchParams.get("children"),
        rooms: searchParams.get("rooms"),
        // slot_id: slot.slot_id,
      };
      const fullHotelDetailsParam = {
        hotel_slug: hotel_slug,
        languageToShow: languageToShow,
        token: userAuthData != null ? userAuthData.token : "",
        searchedParams: searchedParams,
      };
      stateClearAfterTask();

      getFullHotelDetailsRequest(fullHotelDetailsParam);
    }
  }, [languageToShow]);

  React.useEffect(() => {
    setIsAddedFavourite(selectHotelData?.data?.is_favourite);
    hotelWheatherApiRequest(searchParams?.get("city"));
  }, [selectHotelData]);

  const handleFavourite = (hotel_id) => {
    const postData = {
      hotel_id: hotel_id,
    };

    const data = {
      postData,
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };

    if (userAuthData != null || userSocialAuthData != null) {
      if (hotel_id && isAddedFavourite === true) {
        removeFavouriteHotelRequest(data);
        setIsAddedFavourite(!isAddedFavourite);
        if (searchParams.get("search_type") == "bid") {
          const searchedParams = {
            search_type: searchParams.get("search_type"),
            city: searchParams?.get("city"),
            check_in_date: searchParams.get("check_in_date"),
            check_out_date: searchParams.get("check_out_date"),
            adults: searchParams.get("adults"),
            children: searchParams.get("children"),
            rooms: searchParams.get("rooms"),
          };

          const fullHotelDetailsParam = {
            hotel_slug: hotel_slug,
            languageToShow: languageToShow,
            token: userAuthData != null ? userAuthData.token : "",
            searchedParams: searchedParams,
          };
          getFullHotelDetailsRequest(fullHotelDetailsParam);
        }
        if (searchParams.get("search_type") == "hour") {
          const searchedParams = {
            search_type: searchParams.get("search_type"),
            book_for: searchParams?.get("book_for"),
            city: searchParams?.get("city"),
            // hotel_id: selectHotelData?.data?.id,
            // room_type_id: room._id,
            check_in_date: searchParams.get("check_in_date"),
            // check_out_date: searchParams.get("check_out_date"),
            adults: searchParams.get("adults"),
            children: searchParams.get("children"),
            rooms: searchParams.get("rooms"),
            // slot_id: slot.slot_id,
          };
          const fullHotelDetailsParam = {
            hotel_slug: hotel_slug,
            languageToShow: languageToShow,
            token: userAuthData != null ? userAuthData.token : "",
            searchedParams: searchedParams,
          };
          getFullHotelDetailsRequest(fullHotelDetailsParam);
        }
        // getFullHotelDetailsRequest(fullHotelDetailsParam);
      } else {
        addFavouriteHotelRequest(data);
        setIsAddedFavourite(!isAddedFavourite);

        if (searchParams.get("search_type") == "bid") {
          const searchedParams = {
            search_type: searchParams.get("search_type"),
            city: searchParams?.get("city"),
            check_in_date: searchParams.get("check_in_date"),
            check_out_date: searchParams.get("check_out_date"),
            adults: searchParams.get("adults"),
            children: searchParams.get("children"),
            rooms: searchParams.get("rooms"),
          };

          const fullHotelDetailsParam = {
            hotel_slug: hotel_slug,
            languageToShow: languageToShow,
            token: userAuthData != null ? userAuthData.token : "",
            searchedParams: searchedParams,
          };
          getFullHotelDetailsRequest(fullHotelDetailsParam);
        }
        if (searchParams.get("search_type") == "hour") {
          const searchedParams = {
            search_type: searchParams.get("search_type"),
            book_for: searchParams?.get("book_for"),
            city: searchParams?.get("city"),
            // hotel_id: selectHotelData?.data?.id,
            // room_type_id: room._id,
            check_in_date: searchParams.get("check_in_date"),
            // check_out_date: searchParams.get("check_out_date"),
            adults: searchParams.get("adults"),
            children: searchParams.get("children"),
            rooms: searchParams.get("rooms"),
            // slot_id: slot.slot_id,
          };
          const fullHotelDetailsParam = {
            hotel_slug: hotel_slug,
            languageToShow: languageToShow,
            token: userAuthData != null ? userAuthData.token : "",
            searchedParams: searchedParams,
          };
          getFullHotelDetailsRequest(fullHotelDetailsParam);
        }
      }
    } else {
      errorToast("Please login first");
    }
  };

  const handleSharePopup = (shareData) => {
    if (shareData) {
      setShareCode(shareData);
      setOpenSharePopup(!openSharePopup);
    } else {
      setShareCode("");
    }
  };

  const onCopy = React.useCallback((value) => {
    setIsCopied(value);
    setOpenSharePopup(false);
  }, []);

  // const {
  //   adults,
  //   check_in_date,
  //   check_out_date,
  //   children,
  //   city,
  //   hour,
  //   rooms,
  //   search_type,
  // } = location.state;

  const handleMouseHover = (index) => {
    setTimeSlotIndex(index);
    setHovered(true);
  };
  const handleMouseLeave = (index) => {
    setTimeSlotIndex(index);
    setHovered(false);
  };

  return selectHotelData !== null ? (
    <React.Fragment>
      {/* inner banner start */}
      <div className="inner-banner">
        <div className="container">
          {/* search hotel start */}
          <div className="row">
            <div className="col-lg-12">
              <div className="search-hotel">
                <HotelSearchForOthers />
              </div>
            </div>
          </div>
          {/* search hotel start */}
        </div>
      </div>
      {/* inner banner end */}

      {/* breadcrumb start */}
      <div className="breadcrumb">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <ul>
                <li>
                  <Link to="/">Home</Link>
                </li>
                <li>
                  <Link to={-1}>Hotels {searchParams?.get("city")}</Link>
                </li>
                {/* <li>Mansard Dubai, a Radisson Collection Hotel</li> */}
                <li>{selectHotelData?.data?.name}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* breadcrumb end */}

      {/* listing details page start */}

      <div className="listing-details">
        <div className="container">
          {/* listing details header start */}
          <div className="row">
            <div className="col-lg-12">
              <div className="listing-details-header">
                <div className="left-txt flex-column">
                  <div className="top-part">
                    <div className="title">
                      {selectHotelData?.data?.name}
                      <span className="star-rating">
                        {[...Array(selectHotelData?.data?.star)].map((e, i) => (
                          <img src={starIcon} key={i} alt="star" />
                        ))}
                      </span>
                    </div>
                    {/* <div className="star-rating">
                      <Rating
                        direction="ltr"
                        readonly={true}
                        initialRating={selectHotelData?.star}
                        emptySymbol={
                          <img
                            src={"./img/icon-review-star-empty.svg"}
                            alt=""
                          />
                        }
                        fullSymbol={
                          <img src={"./img/icon-review-star.svg"} alt="" />
                        }
                      />
                      {[...Array(selectHotelData?.data?.star)].map((e, i) => (
                        <img src={starIcon} key={i} alt="star" />
                      ))}
                    </div> */}
                  </div>

                  <div className="address">
                    <div className="icon">
                      <img src={addressIcon} alt="" />
                    </div>
                    <p>
                      <span>
                        {selectHotelData?.data?.address.address_line1}
                      </span>
                      ,{" "}
                      {selectHotelData?.data?.address.address_line2 && (
                        <span>
                          {selectHotelData?.data?.address.address_line2},{" "}
                        </span>
                      )}{" "}
                      {selectHotelData?.data?.address.city_village && (
                        <span>
                          {selectHotelData?.data?.address.city_village}
                        </span>
                      )}
                      {selectHotelData?.data?.address.pincode && (
                        <span>
                          - {selectHotelData?.data?.address.pincode} ,
                        </span>
                      )}
                      {/* {selectHotelData?.address.district}, */}
                      {/* {selectHotelData?.address.state}, */}
                      {/* {selectHotelData?.address.post_office} */}
                      <span>{selectHotelData?.data?.address.country}</span>
                    </p>
                  </div>
                </div>

                {/* Customer feedback static for now */}
                <div className="rating-content">
                  <div className="icon-list">
                    <Button
                      onClick={() => {
                        handleSharePopup(selectHotelData?.data?.share_link);
                      }}
                      className={"onClickBtn"}
                    >
                      <img src={shareIcon} alt="" />
                    </Button>
                    <Button
                      className={
                        // selectHotelData?.is_favourite === true
                        isAddedFavourite == true
                          ? "activeFavourite onClickBtn"
                          : "onClickBtn"
                      }
                      onClick={() =>
                        handleFavourite(
                          selectHotelData?.data?.id,
                          selectHotelData?.data?.is_favourite
                        )
                      }
                    >
                      <FavouriteIcon />
                    </Button>
                  </div>
                  <div className="comment">
                    <div className="feedback">Very Good</div>
                    <div className="reviews">292 Guest Reviews</div>
                  </div>
                  <div className="rating-txt">8.9</div>
                </div>
              </div>
            </div>
          </div>

          {/* listing details header end */}

          {/* listing details slider start */}
          <div className="listing-details-slider">
            <div className="details-slider">
              <Slider
                {...detailsSlider}
                asNavFor={nav2}
                ref={(slider1) => setNav1(slider1)}
              >
                {selectHotelData?.data?.images.map((image, index) => {
                  return (
                    <div className="slide-item" key={index}>
                      <img src={image} alt="" />
                    </div>
                  );
                })}
              </Slider>
            </div>
            <div className="popup-slider popupSliderHD ">
              {selectHotelData?.data?.images.length > 2 && (
                <div
                  className="caption"
                  style={{
                    position: "absolute",
                    right: "7%",
                    fontWeight: "600",
                    fontSize: "24px",
                    lineHeight: "29px",
                    top: "82%",
                    color: "#fff",
                    cursor: "pointer",
                    zIndex: 1,
                  }}
                  onClick={
                    // index == index + 1 &&
                    // selectHotelData?.data?.images.length > 2
                    //   ?
                    handleShow
                    // : null
                  }
                >
                  +{selectHotelData?.data?.images.length - 2} Photos{" "}
                </div>
              )}
              <Slider
                {...sideSlider}
                asNavFor={nav1}
                ref={(slider2) => setNav2(slider2)}
              >
                {selectHotelData?.data?.images.map((image, index) => {
                  return (
                    <>
                      <div key={index} className="popSlider-item">
                        <img src={image} alt="" />
                      </div>
                    </>
                  );
                })}
              </Slider>
              {/* <ul>
                {selectHotelData?.data?.images.map((image, index) => {
                  return (
                    <li
                      onClick={
                        index == 1 && selectHotelData?.data?.images.length > 2
                          ? handleShow
                          : null
                      }
                      key={index}
                    >
                      <img src={image} alt="" />

                      {index == 1 &&
                        selectHotelData?.data?.images.length > 2 && (
                          <div className="caption">
                            +{selectHotelData?.data?.images.length - 2} Photos{" "}
                          </div>
                        )}
                    </li>
                  );
                })}
              </ul>
           */}
            </div>
          </div>

          {/* listing details slider end */}

          {/* hotel wrapper start */}
          <div className="hotel-wrapper">
            <div className="row">
              <div className="col-lg-9">
                {/* Hotel Amenities start */}
                <div className="hotel-amenities">
                  <div className="title">Hotel Amenities</div>
                  <ul>
                    {selectHotelData?.data?.hotel_amenities.map(
                      (amenity, index) => {
                        return (
                          <li key={index}>
                            <span className="icon">
                              <img src={amenity.amenity_icon} alt="" />
                            </span>
                            {amenity.amenity_name}
                          </li>
                        );
                      }
                    )}
                  </ul>
                </div>
                {/* Hotel Amenities end */}
                {/* Hotel List start */}
                {selectHotelData?.data?.room_type_data.map((room, index) => {
                  return (
                    <div className="hotel-listing-box" key={index}>
                      <div className="hlb-top-bar">
                        <div className="room_title">
                          <div className="title">{room.name}</div>
                          <div
                            className="title-sm"
                            contentEditable="false"
                            dangerouslySetInnerHTML={{
                              __html: `${
                                selectHotelData != null
                                  ? room.description
                                  : null
                              }`,
                            }}
                          ></div>
                        </div>
                        <div className="time-slot">
                          <ul>
                            {(
                              room?.hourly_availabilities_data?.slots || []
                            ).map((slot, index) => {
                              return (
                                <li
                                  key={index}
                                  className={
                                    searchParams.get("search_type") == "hour" &&
                                    searchParams?.get("book_for") == slot.hour
                                      ? "active"
                                      : hovered &&
                                        timeSlotIndex === slot.slot_id
                                      ? "hoveredTimeSlot"
                                      : ""
                                  }
                                  onMouseEnter={() =>
                                    handleMouseHover(slot.slot_id)
                                  }
                                  onMouseLeave={() =>
                                    handleMouseLeave(slot.slot_id)
                                  }
                                >
                                  {/* {moment(`${slot.start_time}`, [
                                    "hh:mm",
                                  ]).format("hh A")}{" "}
                                  -{" "}
                                  {moment(`${slot.end_time}`, ["hh:mm"]).format(
                                    "hh A"
                                  )} */}
                                  {moment(`${slot.start_time}`, [
                                    "hh:mm",
                                  ]).format("hh:mm A")}{" "}
                                  -{" "}
                                  {moment(`${slot.end_time}`, ["hh:mm"]).format(
                                    "hh:mm A"
                                  )}
                                </li>
                              );
                            })}
                          </ul>
                        </div>
                      </div>
                      <div className="hotel-listing-box-content">
                        <div className="slide-box">
                          {/* <div className="title">{room.name}</div>
                          <div
                            className="title-sm"
                            contentEditable="false"
                            dangerouslySetInnerHTML={{
                              __html: `${
                                selectHotelData != null
                                  ? room.description
                                  : null
                              }`,
                            }}
                          ></div> */}

                          {room.images.length > 0 ? (
                            <Slider {...hotellistSlide}>
                              {room.images.map((image, index) => {
                                return (
                                  <div className="slide-item" key={index}>
                                    <img src={image} alt="" />
                                  </div>
                                );
                              })}
                            </Slider>
                          ) : (
                            <Slider {...hotellistSlide}>
                              <div className="slide-item">
                                <img
                                  src="./img/hotel-list-slide-1.jpg"
                                  alt=""
                                />
                              </div>
                              <div className="slide-item">
                                <img
                                  src="./img/hotel-list-slide-2.jpg"
                                  alt=""
                                />
                              </div>
                              <div className="slide-item">
                                <img
                                  src="./img/hotel-list-slide-3.jpg"
                                  alt=""
                                />
                              </div>
                            </Slider>
                          )}
                        </div>
                        <div className="middle">
                          {/* <div className="time-slot">
                            <ul>
                              {(
                                room?.hourly_availabilities_data?.slots || []
                              ).map((slot, index) => {
                                return (
                                  <li
                                    key={index}
                                    className={
                                      searchParams.get("search_type") ==
                                        "hour" &&
                                      searchParams?.get("book_for") == slot.hour
                                        ? "active"
                                        : hovered &&
                                          timeSlotIndex === slot.slot_id
                                        ? "hoveredTimeSlot"
                                        : ""
                                    }
                                    onMouseEnter={() =>
                                      handleMouseHover(slot.slot_id)
                                    }
                                    onMouseLeave={() =>
                                      handleMouseLeave(slot.slot_id)
                                    }
                                  >
                                    {moment(`${slot.start_time}`, [
                                      "hh:mm",
                                    ]).format("hh:mm A")}{" "}
                                    -{" "}
                                    {moment(`${slot.end_time}`, [
                                      "hh:mm",
                                    ]).format("hh:mm A")}
                                  </li>
                                );
                              })}
                            </ul>
                          </div> */}
                          <div className="amenities-item">
                            <div className="title">Room Amenities</div>
                            <ul>
                              {showMoreAmenities
                                ? room.room_amenities
                                    .slice(0, 6)
                                    .map((amenity, i) => {
                                      return (
                                        <li key={i}>
                                          <span className="icon">
                                            <img
                                              src={amenity.amenity_icon}
                                              alt=""
                                            />
                                          </span>
                                          {amenity.amenity_name}
                                        </li>
                                      );
                                    })
                                : room.room_amenities.map((amenity, i) => {
                                    return (
                                      <li key={i}>
                                        <span className="icon">
                                          <img
                                            src={amenity.amenity_icon}
                                            alt=""
                                          />
                                        </span>
                                        {amenity.amenity_name}
                                      </li>
                                    );
                                  })}
                            </ul>

                            {room.room_amenities.length > 6 && (
                              <p onClick={toggleShowMore}>
                                {showMoreAmenities ? (
                                  <p className="link-more">Show More</p>
                                ) : (
                                  <p className="link-more">Show Less</p>
                                )}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="price-content">
                          <div>
                            <ul>
                              {(
                                room.hourly_availabilities_data.slots || []
                              ).map((slot, slotIndex) => {
                                return (
                                  <li
                                    key={slotIndex}
                                    // className={slotIndex === 0 ? "active" : ""}
                                    className={
                                      searchParams.get("search_type") ==
                                        "hour" &&
                                      searchParams?.get("book_for") == slot.hour
                                        ? "active"
                                        : hovered &&
                                          timeSlotIndex === slot.slot_id
                                        ? "hoveredHourPriceSlot"
                                        : ""
                                    }
                                    onMouseEnter={() =>
                                      handleMouseHover(slot.slot_id)
                                    }
                                    onMouseLeave={() =>
                                      handleMouseLeave(slot.slot_id)
                                    }
                                  >
                                    <Tooltip
                                      title={
                                        slot.is_booked == true
                                          ? "Slot not available"
                                          : ""
                                      }
                                      placement="top"
                                      arrow
                                    >
                                      <div>
                                        <Link
                                          className="text-white"
                                          style={{
                                            pointerEvents:
                                              slot.is_booked == true
                                                ? "none"
                                                : "visible",
                                          }}
                                          state={{
                                            search_type: searchParams.get(
                                              "search_type"
                                            ),
                                            hotel_id: selectHotelData?.data?.id,
                                            room_type_id: room._id,
                                            check_in_date: searchParams.get(
                                              "check_in_date"
                                            ),
                                            check_out_date: searchParams.get(
                                              "check_out_date"
                                            ),
                                            adults: searchParams.get("adults"),
                                            children: searchParams.get(
                                              "children"
                                            ),
                                            rooms: searchParams.get("rooms"),
                                            slot_id: slot.slot_id,
                                            book_for: searchParams?.get(
                                              "book_for"
                                            ),
                                            city: searchParams?.get("city"),
                                          }}
                                          to={"/hourlyguestuser"}
                                        >
                                          <span className="hrs">
                                            {slot.hour} hrs
                                          </span>
                                          <span className="rates">
                                            {/* {
                                          room.hourly_availabilities_data
                                            .currency
                                        }{" "} */}
                                            {currencyToShow.current}
                                            {" " +
                                              parseInt(
                                                slot.actual_price *
                                                  currencyToShow.convertedRates
                                              )}
                                          </span>
                                        </Link>
                                      </div>
                                    </Tooltip>
                                  </li>
                                );
                              })}
                            </ul>

                            {searchParams.get("search_type") == "bid" ? (
                              <Tooltip
                                title={
                                  room.bid_availabilities_data?.is_booked ==
                                  true
                                    ? "Room not available"
                                    : ""
                                }
                                placement="top"
                                arrow
                              >
                                <div>
                                  <Link
                                    className="bid-now"
                                    style={{
                                      pointerEvents:
                                        room.bid_availabilities_data
                                          ?.is_booked == true
                                          ? "none"
                                          : "visible",
                                    }}
                                    state={{
                                      search_type: searchParams.get(
                                        "search_type"
                                      ),
                                      hotel_id: selectHotelData?.data?.id,
                                      room_type_id: room._id,
                                      check_in_date: searchParams.get(
                                        "check_in_date"
                                      ),
                                      check_out_date: searchParams.get(
                                        "check_out_date"
                                      ),
                                      adults: searchParams.get("adults"),
                                      children: searchParams.get("children"),
                                      rooms: searchParams.get("rooms"),
                                      slot_id: "",
                                      book_for: searchParams?.get("book_for"),
                                      city: searchParams?.get("city"),
                                    }}
                                    to={"/bidguestuser"}
                                  >
                                    BID now
                                  </Link>
                                </div>
                              </Tooltip>
                            ) : null}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Hotel List end */}
              </div>
              <div className="col-lg-3">
                <div className="nearby-location-map nearby-google-location-map">
                  {/* <Link to="#" className="view-map">
                    View Map
                  </Link> */}

                  {/* {selectHotelData != null ? (
                    <GoogleMaps listingData={selectHotelData?.data} />
                  ) : null} */}
                </div>

                <div className="nearby-location-item ">
                  <div className="title">Nearby Locations</div>
                  <ul>
                    {(selectHotelData?.data?.nearby_landmarks || []).map(
                      (nbLocation, index) => {
                        return (
                          <li key={index}>
                            <span className="item">
                              {nbLocation.nearby_landmarks_name}
                            </span>
                            <span className="distance">
                              {nbLocation.nearby_landmarks_distance}
                            </span>
                          </li>
                        );
                      }
                    )}
                  </ul>
                </div>
                <div className="nearby-location-description">
                  <div className="title">{selectHotelData?.data?.name}</div>
                  <p
                    contentEditable="false"
                    dangerouslySetInnerHTML={{
                      __html: `${
                        isReadMore
                          ? selectHotelData?.data?.description.slice(0, 450) +
                            (selectHotelData?.data?.description.length > 450
                              ? "..."
                              : "")
                          : selectHotelData?.data?.description
                      }`,
                    }}
                  ></p>
                  {/* condition that will render 'read more' only if the
                    description.length is greated than 450 chars */}
                  {selectHotelData?.data?.description.length > 450 && (
                    <p onClick={toggleReadMore}>
                      {isReadMore ? (
                        <p className="link-more">Read more</p>
                      ) : (
                        <p className="link-more">Show less</p>
                      )}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
          {/* hotel wrapper end */}
          {/* Customer Rating start */}
          <div className="customer-rating">
            <div className="row">
              <div className="col-lg-12">
                <div className="title">Customer Rating</div>
                <div className="rating-container">
                  <div className="rating-box">8.9</div>
                  <div className="comment">Very Good</div>
                  <div className="reviews">292 Guest Reviews</div>
                </div>

                <div className="categories">
                  <h4>Categories</h4>
                  <ul>
                    <li>
                      <div className="top-item">
                        <div className="item-name">Staff</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                    <li>
                      <div className="top-item">
                        <div className="item-name">Comfort</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                    <li>
                      <div className="top-item">
                        <div className="item-name">WiFi</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                    <li>
                      <div className="top-item">
                        <div className="item-name">Amenities</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                    <li>
                      <div className="top-item">
                        <div className="item-name">Location</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                    <li>
                      <div className="top-item">
                        <div className="item-name">Cleanliness</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                    <li>
                      <div className="top-item">
                        <div className="item-name">Staff</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                    <li>
                      <div className="top-item">
                        <div className="item-name">Value for Money</div>
                        <div className="item-icon">
                          <img src="./img/icon-uparrow.svg" alt="" />
                        </div>
                        <div className="item-rating">9.3</div>
                      </div>
                      <div className="progress-bar">
                        <div
                          className="progess green"
                          style={{ width: "90.3%" }}
                        ></div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          {/* Customer Rating end */}

          {/* Customer Review start */}
          <div className="customer-review">
            <div className="row">
              <div className="col-lg-12">
                <div className="title">Customer Review</div>
                <Slider {...customerreview}>
                  <div className="customerreview">
                    <div className="content-box">
                      <p>
                        Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                      </p>
                      <div className="start-rating">
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                      </div>
                      <div className="author">Abdullah</div>
                    </div>
                  </div>

                  <div className="customerreview">
                    <div className="content-box">
                      <p>
                        Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                      </p>
                      <div className="start-rating">
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                      </div>
                      <div className="author">Abdullah</div>
                    </div>
                  </div>

                  <div className="customerreview">
                    <div className="content-box">
                      <p>
                        Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                      </p>
                      <div className="start-rating">
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                      </div>
                      <div className="author">Abdullah</div>
                    </div>
                  </div>

                  <div className="customerreview">
                    <div className="content-box">
                      <p>
                        Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                      </p>
                      <div className="start-rating">
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                      </div>
                      <div className="author">Abdullah</div>
                    </div>
                  </div>

                  <div className="customerreview">
                    <div className="content-box">
                      <p>
                        Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                      </p>
                      <div className="start-rating">
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                        <img src="./img/star.svg" alt="" />
                      </div>
                      <div className="author">Abdullah</div>
                    </div>
                  </div>
                </Slider>
              </div>
            </div>
          </div>

          {/* Customer Review end */}

          {/* House Rules start */}
          <div className="house-rules">
            <div className="row">
              <div className="col-lg-12">
                <div className="title">House Rules</div>

                <div className="content-box">
                  <div className="content-row">
                    <div className="left">
                      <label>Check in</label>
                    </div>
                    <div
                      className="right"
                      contentEditable="false"
                      dangerouslySetInnerHTML={{
                        __html: `${
                          selectHotelData?.data?.hotel_rules?.check_in !== "" ||
                          selectHotelData?.data?.hotel_rules?.check_in != null
                            ? selectHotelData?.data?.hotel_rules?.check_in
                            : "..."
                        }`,
                      }}
                    ></div>
                  </div>
                  <div className="content-row">
                    <div className="left">
                      <label>Check out</label>
                    </div>

                    <div className="right">
                      <p
                        className="right"
                        contentEditable="false"
                        dangerouslySetInnerHTML={{
                          __html: `${
                            selectHotelData?.data?.hotel_rules?.check_out !== ""
                              ? selectHotelData?.data?.hotel_rules?.check_out
                              : "..."
                          }`,
                        }}
                      ></p>
                      {/* <p>{selectHotelData?.data?.hotel_rules?.check_out}</p> */}
                    </div>
                  </div>

                  <div className="content-row">
                    <div className="left">
                      <label>Cancellation and Repayment</label>
                    </div>
                    <div className="right">
                      <p
                        className="right"
                        contentEditable="false"
                        dangerouslySetInnerHTML={{
                          __html: `${
                            selectHotelData?.data?.hotel_rules
                              ?.cancellation_and_policy !== ""
                              ? selectHotelData?.data?.hotel_rules
                                  ?.cancellation_and_policy
                              : "..."
                          }`,
                        }}
                      ></p>
                    </div>
                  </div>
                  <div className="content-row">
                    <div className="left">
                      <label>Children & Beds</label>
                    </div>
                    <div className="right">
                      <p
                        className="right"
                        contentEditable="false"
                        dangerouslySetInnerHTML={{
                          __html: `${
                            selectHotelData?.data?.hotel_rules
                              ?.children_and_beds !== ""
                              ? selectHotelData?.data?.hotel_rules
                                  ?.children_and_beds
                              : "..."
                          }`,
                        }}
                      ></p>
                      {/* <p>
                        {selectHotelData?.data?.hotel_rules
                          ?.children_and_beds !== ""
                          ? selectHotelData?.data?.hotel_rules
                              ?.children_and_beds
                          : "..."}
                      </p> */}
                    </div>
                  </div>
                  <div className="content-row">
                    <div className="left">
                      <label>Age Restriction</label>
                    </div>
                    <div className="right">
                      <p
                        className="right"
                        contentEditable="false"
                        dangerouslySetInnerHTML={{
                          __html: `${
                            selectHotelData?.data?.hotel_rules
                              ?.age_restriction !== ""
                              ? selectHotelData?.data?.hotel_rules
                                  ?.age_restriction
                              : "..."
                          }`,
                        }}
                      ></p>
                    </div>
                  </div>
                  <div className="content-row">
                    <div className="left">
                      <label>Pets</label>
                    </div>
                    <div className="right">
                      <p
                        className="right"
                        contentEditable="false"
                        dangerouslySetInnerHTML={{
                          __html: `${
                            selectHotelData?.data?.hotel_rules?.pets !== ""
                              ? selectHotelData?.data?.hotel_rules?.pets
                              : "..."
                          }`,
                        }}
                      ></p>
                    </div>
                  </div>
                  <div className="content-row">
                    <div className="left">
                      <label>Payment Acceptance</label>
                    </div>
                    <div className="right">
                      <p
                        className="right"
                        contentEditable="false"
                        dangerouslySetInnerHTML={{
                          __html: `${
                            selectHotelData?.data?.hotel_rules
                              ?.payment_acceptance !== ""
                              ? selectHotelData?.data?.hotel_rules
                                  ?.payment_acceptance
                              : "..."
                          }`,
                        }}
                      ></p>
                    </div>
                  </div>
                  <div className="content-row">
                    <div className="left">
                      <label>Remarks</label>
                    </div>
                    <div className="right">
                      <p
                        className="right"
                        contentEditable="false"
                        dangerouslySetInnerHTML={{
                          __html: `${
                            selectHotelData?.data?.hotel_rules?.remarks !== ""
                              ? selectHotelData?.data?.hotel_rules?.remarks
                              : "..."
                          }`,
                        }}
                      ></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* House Rules end */}
        </div>
      </div>

      {/* listing details page end */}

      {/* Share popup start */}
      <ShareModal
        setOpenSharePopup={setOpenSharePopup}
        openSharePopup={openSharePopup}
        shareCode={shareCode}
        setShareCode={setShareCode}
        onCopy={onCopy}
        isCopied={isCopied}
        setIsCopied={setIsCopied}
      />
      {/* Share popup end */}
      {/* popup slide start */}
      <Modal
        dialogClassName="modal-lg gen-modal hotel-details-modal-slider"
        show={show}
        onHide={handleClose}
      >
        <Modal.Header closeButton></Modal.Header>
        <Modal.Body>
          <div className="pop-slide-content">
            <Slider {...popSlider}>
              {selectHotelData?.data?.images.map((image, index) => {
                return (
                  <div className="slide-item" key={index}>
                    <img src={image} alt="" />
                  </div>
                );
              })}

              {/* <div className="slide-item">
                <img src="./img/details-popup-slide-2.jpg" alt="" />
              </div> */}
            </Slider>
          </div>
        </Modal.Body>
      </Modal>
      {/* popup slide end */}
    </React.Fragment>
  ) : null;
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  selectHotelData: selectHotelData,
  favouriteHotel: selectFavouriteHotel,
  userAuthData: selectUserLoginData,
  userSocialAuthData: selectSocialLoginUser,
  searchsavedData: selectFavouriteHotelSearchData,
  currencyToShow: selectcurrencyToShow,
});
const mapDispatchToProps = (dispatch) => ({
  addFavouriteHotelRequest: (data) => dispatch(addFavouriteHotelRequest(data)),
  removeFavouriteHotelRequest: (data) =>
    dispatch(removeFavouriteHotelRequest(data)),
  getFullHotelDetailsRequest: (data) =>
    dispatch(getFullHotelDetailsRequest(data)),
  stateClearAfterTask: () => dispatch(stateClearAfterTask()),
  // selectLanguage: (data) => dispatch(selectLanguage(data)),
  hotelWheatherApiRequest: (data) => dispatch(hotelWheatherApiRequest(data)),
});
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(HotelListingDetails);
