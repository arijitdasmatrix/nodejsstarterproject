import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { ReactComponent as FavouriteIcon } from "../../assets/images/icon-list-favourite.svg";
import {
  Link,
  useLocation,
  useNavigate,
  createSearchParams,
} from "react-router-dom";
import {
  getAllFavouriteHotelListRequest,
  removeFavouriteHotelRequest,
} from "../../redux/hotels/hotel.actions";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import {
  selectFavouriteHotelList,
  selectFavouriteHotel,
} from "../../redux/hotels/hotel.selectors";
import { selectUserLoginData } from "../../redux/user/user.selectors";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { errorToast } from "../../utils/toastHelper";
import moment from "moment";
import { Button } from "react-bootstrap";

const MyFavouriteHotelList = ({
  myFavouriteHotelList,
  favouriteHotel,
  // handleFavourite,
  // isAddedFavourite,
  getAllFavouriteHotelListRequest,
  removeFavouriteHotelRequest,
  languageToShow,
  userAuthData,
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isAddedFavourite, setIsAddedFavourite] = React.useState();

  var collecSlider = {
    arrows: true,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  const gotoHotelDetails = (slug, cityname) => {
    var checkinDate = new Date();
    checkinDate.setDate(checkinDate.getDate() + 1);
    var checkoutDate = new Date();
    checkoutDate.setDate(checkoutDate.getDate() + 2);

    let dateObj = new Date();
    let month = dateObj.getUTCMonth() + 1; //months from 1-12
    let day = dateObj.getUTCDate();
    let year = dateObj.getUTCFullYear();
    if (location.pathname == `/hotel-details/${slug}`) {
      navigate({
        pathname: location.pathname,
        search: createSearchParams({
          search_type: "bid",
          city: cityname,
          check_in_date: moment(checkinDate).format("DD/MM/YYYY"),
          check_out_date: moment(checkoutDate).format("DD/MM/YYYY"),
          // check_in_date: "" + year + "-" + month + "-" + (day + 1) + "",
          // check_out_date: "" + year + "-" + month + "-" + (day + 2) + "",
          adults: "1",
          children: "1",
          rooms: "1",
        }).toString(),
      });
    } else {
      navigate(
        {
          pathname: `/hotel-details/${slug}`,
          search: createSearchParams({
            search_type: "bid",
            city: cityname,
            check_in_date: moment(checkinDate).format("DD/MM/YYYY"),
            check_out_date: moment(checkoutDate).format("DD/MM/YYYY"),
            // check_in_date: "" + year + "-" + month + "-" + (day + 1) + "",
            // check_out_date: "" + year + "-" + month + "-" + (day + 2) + "",
            adults: "1",
            children: "1",
            rooms: "1",
          }).toString(),
        },
        { replace: false }
      );
    }
  };

  const handleFavourite = (hotel_id) => {
    const data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };
    const postData = {
      hotel_id: hotel_id,
    };

    const hotelFavouritesParam = {
      postData,
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };

    if (userAuthData != null) {
      if (hotel_id) {
        removeFavouriteHotelRequest(hotelFavouritesParam);
        setIsAddedFavourite(!isAddedFavourite);
        // getAllFavouriteHotelListRequest(data);
      }
    } else {
      errorToast("Please login first");
    }
  };

  React.useEffect(() => {
    const data = {
      languageToShow: languageToShow,
      token: userAuthData != null ? userAuthData.token : "",
    };
    if (favouriteHotel != null) {
      if (favouriteHotel.success == true) {
        getAllFavouriteHotelListRequest(data);
      } else {
      }
    }
  }, [favouriteHotel]);

  // console.log(date);

  return (
    <div className="WL_right_rivewbox">
      {/* ///left section start/// */}
      <div className="WL_collection_left WL_collection_myfavlist_left">
        <div className="WL_review_mwrp">
          {/* ///slider start/// */}
          <div className="WL_coll_slider myFavColl_Slider">
            <Slider {...collecSlider}>
              {myFavouriteHotelList.images.length > 0 ? (
                myFavouriteHotelList.images.map((image, index) => (
                  <img
                    src={image}
                    alt=""
                    className="WL_coll_slider_img"
                    key={index}
                  />
                ))
              ) : (
                <img
                  src="./img/collec_img1.png"
                  alt=""
                  className="WL_coll_slider_img"
                />
              )}
            </Slider>
            <span className="favourite myfavlist_heartIcon">
              {/* <img src="./img/favwhite.svg" alt="" /> */}
              <Button
                className={
                  isAddedFavourite == true
                    ? "activeFavourite onClickBtn"
                    : "activeFavourite onClickBtn"
                }
                onClick={() => handleFavourite(myFavouriteHotelList?.hotel_id)}
              >
                <FavouriteIcon />
              </Button>
            </span>
          </div>
          {/* ///slider end/// */}
          {/* ///review text container Start/// */}
          <div className="WL_inner_review_cont">
            {/* ///review text Start/// */}
            <div className="WL_reviewtext_cont favreviewtext_cont myFavTextmiddle">
              <h3
                onClick={() => {
                  gotoHotelDetails(
                    myFavouriteHotelList.slug,
                    myFavouriteHotelList.address.city_village
                  );
                }}
              >
                {myFavouriteHotelList.name}
              </h3>
              <div className="address">
                <div className="icon">
                  <img src="./img/icon-address.svg" alt="" />
                </div>
                {/* 22nd St, PO Box 39 39 71, Dubai, Dubai PO Box 39 */}
                <p>
                  <span>{myFavouriteHotelList.address.address_line1}</span>,{" "}
                  {myFavouriteHotelList.address.address_line2 && (
                    <span>{myFavouriteHotelList.address.address_line2}, </span>
                  )}{" "}
                  {myFavouriteHotelList.address.city_village && (
                    <span>{myFavouriteHotelList.address.city_village} -</span>
                  )}
                  {myFavouriteHotelList.address.pincode}
                  {/* {myFavouriteHotelList?.address.district}, 
              {myFavouriteHotelList?.address.state},
               {myFavouriteHotelList?.address.post_office} */}
                  <br />
                  {myFavouriteHotelList.address.country}
                </p>
              </div>
            </div>
            {/* ///review text end/// */}
          </div>
          {/* ///review text container end/// */}
        </div>
      </div>
      {/* ///left section end/// */}
      {/* ///right section start/// */}
      <div className="WL_collection_right favright myFavRight">
        <div className="reviewstar">
          {[...Array(myFavouriteHotelList.star)].map((e, i) => (
            <img src="./img/star.svg" key={i} alt="" />
          ))}
        </div>
        <div className="favguest d-flex">
          <div className="WL_revw_left">
            <p className="WL_revw_text1">Very Good</p>
            <p className="WL_revw_text2">292 Guest Reviews</p>
          </div>
          <div className="WL_revw_right">8.9</div>
        </div>
      </div>
      {/* ///right section end/// */}
    </div>
  );
};

const mapStateToProps = createStructuredSelector({
  languageToShow: selectlanguageToShow,
  selectFavouriteHotelList: selectFavouriteHotelList,
  favouriteHotel: selectFavouriteHotel,
  userAuthData: selectUserLoginData,
});
const mapDispatchToProps = (dispatch) => ({
  getAllFavouriteHotelListRequest: (data) =>
    dispatch(getAllFavouriteHotelListRequest(data)),
  removeFavouriteHotelRequest: (data) =>
    dispatch(removeFavouriteHotelRequest(data)),
  // selectLanguage: (data) => dispatch(selectLanguage(data)),
  
});
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(MyFavouriteHotelList);
