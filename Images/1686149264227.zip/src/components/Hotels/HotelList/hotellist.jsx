import React, { useState } from "react";
import { json, Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import {
useNavigate,
useSearchParams,
createSearchParams,
useLocation,
} from "react-router-dom";
import { createStructuredSelector } from "reselect";
import { connect } from "react-redux";
import { addFavouriteHotelRequest , removeFavouriteHotelRequest } from "./../../../redux/hotels/hotel.actions";
import { selectCurrentUser } from "../../../redux/user/user.selectors";
import { selectFavouriteHotelSearchData } from "./../../../redux/hotels/hotel.selectors";
import { selectlanguageToShow } from "../../../redux/language/language.selectors";
import { selectcurrencyToShow } from "../../../redux/currency/currency.selectors";
import Slider from "react-slick";
var listSlide = {
  arrows: true,
  dots: false,
  infinite: true,
  speed: 500,
  slidesToScroll: 1,
};

const HotelList = ({
  hotelList,
  addFavouriteHotelRequest,
  selectCurrentUser,
  selectlanguageToShow,
  searchsavedData,
  removeFavouriteHotelRequest,
  currencyToShow
}) => {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [aminityDetailsShow, setAminityDetailsShow] = useState(true);
  const gotoHotelDetails = (slug, searchedType,hourSlot) => {
    console.log("searchsavedData-->",searchsavedData)
    console.log("searchParams-->",searchParams)
  //  console.log(searchsavedData.checkInTime);
    if(searchsavedData != null) {
     
    var searchData = {
      search_type:searchedType!=null? searchedType : (searchsavedData.searchType != "null") ? searchsavedData.searchType :  (searchParams != null) ? searchParams?.get("search_type") : searchedType,
      book_for: hourSlot!=null? hourSlot:(searchsavedData.getHours != "null") ? searchsavedData.getHours : (searchParams != null) ? searchParams?.get("book_for") : "",
      city:  (searchsavedData.place != null) ? searchsavedData.place : searchParams != null ? searchParams?.get("city") : "" ,
      check_in_date: (searchsavedData.checkInTime != "Invalid date") ? searchsavedData.checkInTime : (searchParams != null) ? searchParams?.get("check_in_date") : "",
      check_out_date:(searchsavedData.checkOutTime != "Invalid date") ? searchsavedData.checkOutTime : (searchParams != null) ? searchParams?.get("check_out_date") : "",
      adults:(searchsavedData.roomdata!=null) ? searchsavedData.roomdata.adults : (searchParams != null) ? searchParams?.get("adults") : "",
      children:(searchsavedData.roomdata!=null)? searchsavedData.roomdata.child : (searchParams != null) ? searchParams?.get("children") : "",
      rooms:(searchsavedData.roomdata!=null)? searchsavedData.roomdata.rooms : (searchParams != null) ? searchParams?.get("rooms") : "",
    };
    } else {
      var searchData = {
        search_type: searchedType!=null? searchedType: searchParams != null?searchParams?.get("search_type"):"",
        book_for: hourSlot!=null? hourSlot:searchParams != null ? searchParams?.get("book_for") : "",
        city:searchParams != null ? searchParams?.get("city") : "",
        check_in_date:
          searchParams != null ? searchParams?.get("check_in_date") : "",
        check_out_date:
          searchParams != null ? searchParams?.get("check_out_date") : "",
        adults: searchParams != null ? searchParams?.get("adults") : "",
        children: searchParams != null ? searchParams?.get("children") : "",
        rooms: searchParams != null ? searchParams?.get("rooms") : "",
      };
    }
 
  
    if (location.pathname == `/hotel-details/${slug}`) {
      navigate({
        pathname: location.pathname,
        search: createSearchParams(searchData).toString(),
      },{state:searchData});
    } 
    else {
      navigate(
        {
          pathname: `/hotel-details/${slug}`,
          search: createSearchParams(searchData).toString(),
        },
        {state:searchData},
        { replace: true }
      );
    }
  };

  const handleShow = () => {
    setAminityDetailsShow(!aminityDetailsShow);
  };
 
  const addfavrites = (hotelList) => {
    //console.log("Hello wolrd",hotelList._id,selectCurrentUser.token,selectlanguageToShow);
    const postData = {
      hotel_id: hotelList._id,
    };
    const data = {
      postData,
      languageToShow: selectlanguageToShow,
      token: selectCurrentUser != null ? selectCurrentUser.token : "",
    };

    addFavouriteHotelRequest(data);
  };
  const removefavrites = (hotelList) => {
    const postData = {
      hotel_id: hotelList._id,
    };
    const data = {
      postData,
      languageToShow: selectlanguageToShow,
      token: selectCurrentUser != null ? selectCurrentUser.token : "",
    };
    removeFavouriteHotelRequest(data);
  }
 

 // console.log("Hello Current User",hotelList.is_favourite);
 //console.log("Hello",hotelList);
  return (
    <>
      <div className="listing-box">
        <div className="slide-box">
          <Slider {...listSlide}>
            {hotelList.images.length > 0 ? (
              hotelList.images.map((hotels, index) => (
                
                <div className="slide-item" key={index}>
                  <img src={hotels} alt="" />
                  <span className={hotelList.is_favourite ? "favourite likefavourite" : "favourite"}>
                    
                    <img
                      src="./img/icon-favourite.svg"
                     
                      onClick={() => {
                        hotelList.is_favourite ?  removefavrites(hotelList) : addfavrites(hotelList)
                      }}
                      alt=""
                    />
                  </span>
                </div>
              ))
            ) : (
              <div className="slide-item">
                <img src="./img/list-slide-3.jpg" alt="" />
                <span className="favourite">
                  <img src="./img/icon-favourite.svg" alt="" />
                </span>
              </div>
            )}
          </Slider>
        </div>
        <div className="right">
          <div className="top-bar">
            <div className="left-txt">
              <div
                className="title"
                onClick={() => {
                  gotoHotelDetails(hotelList.slug);
                }}
              >
                {hotelList.name}
                <span className="star-rating">
                  {[...Array(hotelList.star)].map((e, i) => (
                    <img src="./img/icon-review-star.svg" key={i} alt="" />
                  ))}
                </span>
              </div>
              {/* <div className="star-rating">
                {[...Array(hotelList.star)].map((e, i) => (
                  <img src="./img/icon-review-star.svg" key={i} alt="" />
                ))}
              </div> */}
            </div>

            <div className="rating-content">
              <div className="comment">
                <div className="feedback">Very Good</div>
                <div className="reviews">292 Guest Reviews</div>
                <div className="reviews">{hotelList.recomended ? "Recomended" : null }</div>
              </div>
              <div className="rating-txt">8.9</div>
            </div>
          </div>
          <div className="address">
            <div className="icon">
              <img src="./img/icon-address.svg" alt="" />
            </div>
            {hotelList.address.address_line1},{hotelList.address.city_village},
            {hotelList.address.country},{hotelList.address.state}
            {hotelList.address.post_office}
          </div>
          <div className="amenities">
            <div className="amenities-item">
              <ul>
                {aminityDetailsShow
                  ? hotelList.hotel_amenity.length > 0
                    ? hotelList.hotel_amenity.slice(0, 8).map((item) => {
                        return (
                          <li>
                            <span className="icon">
                              <img src={item.icon} alt="" />
                            </span>
                            {item.name}
                          </li>
                        );
                      })
                    : null
                  : hotelList.hotel_amenity.length > 0
                  ? hotelList.hotel_amenity.map((item) => {
                      return (
                        <li>
                          <span className="icon">
                            <img src={item.icon} alt="" />
                          </span>
                          {item.name}
                        </li>
                      );
                    })
                  : null}
                {/* <li>
                  <span className="icon">
                    <img src="./img/icon-cash.svg" alt="" />
                  </span>
                  Accepts Cash
                </li> */}
                {/* <li>
                  <span className="icon">
                    <img src="./img/icon-air-conditioning.svg" alt="" />
                  </span>
                  Air Conditioning
                </li>
                <li>
                  <span className="icon">
                    <img src="./img/icon-baggage.svg" alt="" />
                  </span>
                  Baggage Storage
                </li>
                <li>
                  <span className="icon">
                    <img src="./img/icon-parking.svg" alt="" />
                  </span>
                  Free Car Parking
                </li>
                <li>
                  <span className="icon">
                    <img src="./img/icon-pool.svg" alt="" />
                  </span>
                  Pool and Spa
                </li>
                <li>
                  <span className="icon">
                    <img src="./img/icon-dry-cleaning.svg" alt="" />
                  </span>
                  Dry Cleaning
                </li>
                <li>
                  <span className="icon">
                    <img src="./img/icon-food.svg" alt="" />
                  </span>
                  Food and Breveges
                </li>
                <li>
                  <span className="icon">
                    <img src="./img/icon-beach.svg" alt="" />
                  </span>
                  Beach View
                </li>*/}
              </ul>
              { hotelList.hotel_amenity.length > 8 ? (
               <p
                 className="link-more"
                 onClick={handleShow}
                 style={{ cursor: "pointer" }}
               >
               { aminityDetailsShow ?  "see more amenities" : "less" }
               </p>
             ) : null}

            </div>
            <div className="price-content">
              <ul>
                {hotelList.slots.length > 0
                  ? hotelList.slots.map((item) => {
                      return (
                        <li
                          onClick={() => {
                            gotoHotelDetails(hotelList.slug,selectFavouriteHotelSearchData.searchType,selectFavouriteHotelSearchData.getHours);
                          }}
                          style={{ cursor: "pointer" }}
                        >
                          <span className="hrs">{item.hour} hrs</span>
                          <span className="rates">{currencyToShow.current} {parseInt(item.actual_price*currencyToShow.convertedRates)}</span>
                        </li>
                      );
                    })
                  : null}
              </ul>
              { searchsavedData.searchButtonShow == "bid" ?
              <button
                className="bid-now"
                onClick={() => {
                  gotoHotelDetails(hotelList.slug,  selectFavouriteHotelSearchData.searchType);
                }}
              >
                BID now
              </button>
              : 
              null
              }
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
const mapStateToProps = createStructuredSelector({
  selectCurrentUser: selectCurrentUser,
  selectlanguageToShow: selectlanguageToShow,
  searchsavedData:selectFavouriteHotelSearchData,
  currencyToShow:selectcurrencyToShow
});
const mapDispatchToProps = (dispatch) => ({
  addFavouriteHotelRequest: (data) => dispatch(addFavouriteHotelRequest(data)),
  removeFavouriteHotelRequest:(data) => dispatch(removeFavouriteHotelRequest(data))
});
export default connect(mapStateToProps, mapDispatchToProps)(HotelList);
