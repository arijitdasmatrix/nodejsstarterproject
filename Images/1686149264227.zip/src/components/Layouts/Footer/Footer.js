import React from "react";
import { Button } from "react-bootstrap";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

const Footer = () => {
const navigate = useNavigate();
const handleChangeLink = (data) => {
  window.scroll(0,0);
  console.log(data);
if(data == "/safety-security") {
  navigate("/safety-security");  
} else if (data == "/terms&conditions") {
  navigate("/terms&conditions");
} else if (data == "/privacy-policy") {
  navigate("/privacy-policy");
} else {

}
  
}
  return (
    <>
      <footer>
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <img src="./img/logo-white.svg" alt="" className="footerlogo" />
              <ul className="footlocation">
                <li>
                  <img src="./img/location.svg" alt="" /> 123 address st.{" "}
                </li>
                <li>
                  <img src="./img/call-calling.svg" alt="" />{" "}
                  <a href="tel:+971-589706050">+971-589706050</a>{" "}
                </li>
                <li>
                  <img src="./img/send-2.svg" alt="" />{" "}
                  
                 
                  <a  href="mailto:someone@example.com">
                    wfrlee.com@gmail.com
                  </a>
                  
                  {" "}
                </li>
              </ul>
            </div>
            <div className="col-md-4">
              <div className="footerpadding">
                <h3>Company</h3>
                <ul>
                  <li>
                    <Link to="/"> Home</Link>
                  </li>
                  <li>
                    <Link to="/login">Register</Link>
                  </li>
                  <li>
                    <Link to="/aboutus">About us</Link>
                  </li>
                  <li>
                    <Link to="/career">Careers</Link>
                  </li>
                  <li>
                    <Link to="/contactus">Contact us</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-4">
              <div className="footerpadding">
                <h3>Other Links</h3>
                <ul>
                  <li>
                   <button onClick={()  =>  handleChangeLink("/safety-security")} > Safety and Security </button>
                  </li>
                  <li>
                    <Button onClick={()  => handleChangeLink("/terms&conditions")} >Terms & Conditions</Button>
                  </li>
                  <li>
                    <Button onClick={()  => handleChangeLink("/privacy-policy")}  >Privacy Policy</Button>
                  </li>
                  <li>
                    <Link to="/myreferrals">Referral Page</Link>
                  </li>
                  <li>
                    <Link to="/partnerswithwfrlee">Partner with wfrlee.com</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="whiteborder"></div>
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="footer-socialarea">
                <Link to="#">
                  <GrFacebookOption />
                </Link>
                <Link to="#">
                  <GrTwitter />
                </Link>
                <Link to="#">
                  <GrLinkedinOption />
                </Link>
                <Link to="#">
                  <GrInstagram />
                </Link>
                <Link to="#">
                  <GrYoutube />
                </Link>
              </div>
            </div>
            <div className="col-md-6">
              <div className="copyright">
                Copyright @ Techit LLC. All Rights Reserved
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* <footer>
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <img src="./img/logo-white.svg" alt="" className="footerlogo" />
              <ul className="footlocation">
                <li>
                  <img src="./img/location.svg" alt="" /> 123 address st.{" "}
                </li>
                <li>
                  <img src="./img/call-calling.svg" alt="" />{" "}
                  <Link to="#">+971-589706050</Link>{" "}
                </li>
                <li>
                  <img src="./img/send-2.svg" alt="" />{" "}
                  <Link to="mailto:wfrlee.com@gmail.com">
                    wfrlee.com@gmail.com
                  </Link>{" "}
                </li>
              </ul>
            </div>
            <div className="col-md-4">
              <div className="footerpadding">
                <h3>Company</h3>
                <ul>
                  <li>
                    <Link to="/"> Home</Link>
                  </li>
                  <li>
                    <Link to="#">Register</Link>
                  </li>
                  <li>
                    <Link to="/aboutus">About us</Link>
                  </li>
                  <li>
                    <Link to="#">Careers</Link>
                  </li>
                  <li>
                    <Link to="#">Contact us</Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-md-4">
              <div className="footerpadding">
                <h3>Other Links</h3>
                <ul>
                  <li>
                    <Link to="#">Safety and Security</Link>
                  </li>
                  <li>
                    <Link to="#">Terms & Conditions</Link>
                  </li>
                  <li>
                    <Link to="#">Privacy Policy</Link>
                  </li>
                  <li>
                    <Link to="#">Referral Page</Link>
                  </li>
                  <li>
                    <Link to="#">Partner with wfrlee.com</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="whiteborder"></div>
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <div className="footer-socialarea">
                <Link to="#">
                  <GrFacebookOption />
                </Link>
                <Link to="#">
                  <GrTwitter />
                </Link>
                <Link to="#">
                  <GrLinkedinOption />
                </Link>
                <Link to="#">
                  <GrInstagram />
                </Link>
                <Link to="#">
                  <GrYoutube />
                </Link>
              </div>
            </div>
            <div className="col-md-6">
              <div className="copyright">
                Copyright @ Techit LLC. All Rights Reserved
              </div>
            </div>
          </div>
        </div>
      </footer>
     */}
    </>
  );
};

export default Footer;
