import React, { useEffect, useState } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import profilePic from "../../../assets/images/ProfilePic.png";
import Topnav from "../../../assets/images/topnav.svg";
import {
  // getUserFromLocalStorage,
  setUserLocal,
} from "../../../config/common.api";
import { createStructuredSelector } from "reselect";
import {
  selectSocialLoginUser,
  selectUserLoginData,
} from "../../../redux/user/user.selectors";
import { UserLogoutStart } from "../../../redux/user/user.actions";
import { connect } from "react-redux";
import { selectLanguage } from "./../../../redux/language/language.actions";
import { selectlanguageToShow } from "./../../../redux/language/language.selectors";
import { selectCurrency } from "./../../../redux/currency/currency.actions";
import { selectcurrencyToShow } from "./../../../redux/currency/currency.selectors";
import { selectHotelWhetherData } from "./../../../redux/hotels/hotel.selectors";
import wfrleeLogo from "../../../assets/images/logo.svg";
import { CurrencyConverterHook } from "../../../utils/CurrencyConverter";
import { useLocation, useNavigate } from "react-router-dom";
import { selectSaveGuestUserCheckoutData } from "../../../redux/hotels/hotel.selectors";
import {
  saveGuestUserCheckoutDataRequest,
  stateClearAfterTask,
  getHourlyCheckoutDetailsRequest,
  getBidCheckoutDetailsRequest,
} from "../../../redux/hotels/hotel.actions";
import LoginModal from "../../../components/checkout/LoginModal";
import LoginPage from "../../../pages/Login/Login";

const Header = ({
  userData,
  selectLanguage,
  languageToShow,
  selectCurrency,
  currencyToShow,
  userAuthData,
  UserLogoutStart,
  selectHotelWhetherData,
  saveGuestUserCheckoutDataRequest,
  stateClearAfterTask,
  saveGuestUserCheckoutData,
  getBidCheckoutDetailsRequest,
  getHourlyCheckoutDetailsRequest,
}) => {
  // const [username, setUsername] = React.useState();
  const { currencyConverted } = CurrencyConverterHook();
  const navigate = useNavigate();
  var [showLoginPopup, setShowLoginPopup] = useState(false);
  // const user = getUserFromLocalStorage();
  // React.useEffect(() => {
  //   if (user !== null) {
  //     setUsername(userData.first_name);
  //   }
  // }, []);
  const location = useLocation();
  const currentLocation = useLocation();

  const handleLogout = () => {
    const data = null;
    setUserLocal("");
    localStorage.clear();
    UserLogoutStart();
    saveGuestUserCheckoutDataRequest(data);
    stateClearAfterTask();
    navigate("/");
    // window.location.href = "/";
  };

  const handleSelect = (e) => {
    selectLanguage(e);
  };

  const handleSelectCurrency = async (e, prev) => {
    let setCur = { current: e, prev: prev };
    const getConvertedCurrencyValue = await currencyConverted(setCur);
    console.log("getConvertedCurrencyValue", getConvertedCurrencyValue);
    if (
      "status" in getConvertedCurrencyValue &&
      getConvertedCurrencyValue.status === 200 &&
      "data" in getConvertedCurrencyValue &&
      "rates" in getConvertedCurrencyValue.data
    ) {
      setCur.convertedRates = getConvertedCurrencyValue.data.rates[e];
    }
    selectCurrency(setCur);
  };

  useEffect(() => {
    console.log("Arabic", languageToShow);
    if (languageToShow == "ar") {
      document.body.classList.add("arabic-lang");
    } else {
      document.body.classList.remove("arabic-lang");
    }
  }, [languageToShow]);

  // console.log("hello", userAuthData, selectHotelWhetherData);
  const handleCloseLoginPopup = () => {
    setShowLoginPopup(false);
  };
  // useEffect(() => {}, [showLoginPopup]);

  React.useEffect(() => {
    if (userAuthData != null) {
      if (
        saveGuestUserCheckoutData != null &&
        saveGuestUserCheckoutData?.request_data?.search_type === "bid" &&
        location?.pathname === "/bidguestuser"
      ) {
        const postData = {
          hotel_id: saveGuestUserCheckoutData?.request_data?.hotel_id,
          room_type_id: saveGuestUserCheckoutData?.request_data?.room_type_id,
          check_in_date: saveGuestUserCheckoutData?.request_data?.check_in_date,
          check_out_date:
            saveGuestUserCheckoutData?.request_data?.check_out_date,
          adults: saveGuestUserCheckoutData?.request_data?.adults,
          children: saveGuestUserCheckoutData?.request_data?.children,
          no_of_rooms: saveGuestUserCheckoutData?.request_data?.no_of_rooms,
        };
        const data = {
          postData,
          languageToShow: languageToShow,
          token: userAuthData != null ? userAuthData.token : "",
        };
        getBidCheckoutDetailsRequest(data);
      } else {
        const postData = {
          hotel_id: saveGuestUserCheckoutData?.request_data?.hotel_id,
          room_type_id: saveGuestUserCheckoutData?.request_data?.room_type_id,
          slot_id: saveGuestUserCheckoutData?.request_data?.slot_id,
          check_in_date: saveGuestUserCheckoutData?.request_data?.check_in_date,
          adults: saveGuestUserCheckoutData?.request_data?.adults,
          children: saveGuestUserCheckoutData?.request_data?.children,
          no_of_rooms: saveGuestUserCheckoutData?.request_data?.no_of_rooms,
        };

        const data = {
          postData,
          languageToShow: languageToShow,
          token: userAuthData != null ? userAuthData.token : "",
        };
        getHourlyCheckoutDetailsRequest(data);
      }
    }
  }, [showLoginPopup, languageToShow]);

  return (
    <>
      {/* Header Section */}
      <>
        {console.log(
          "selectHotelWhetherData",
          selectHotelWhetherData,
          location.pathname
        )}
      </>
      <header>
        <div className="container">
          <div className="row">
            <div className="col-md-3">
              <div className="logo">
                <Link to="/">
                  <img src={wfrleeLogo} alt="" />
                </Link>
              </div>
            </div>
            <div className="col-md-9">
              <div className="toprightsec">
                {(selectHotelWhetherData != null &&
                  location.pathname.includes("/listingbidnow")) ||
                (selectHotelWhetherData != null &&
                  location.pathname.includes("hotel-details")) ||
                (selectHotelWhetherData != null &&
                  location.pathname.includes("bidguestuser")) ||
                (selectHotelWhetherData != null &&
                  location.pathname.includes("hourlyguestuser")) ? (
                  <div class="topweather">
                    <span>{selectHotelWhetherData.location.name}</span>{" "}
                    <img src="./img/weathermeter.svg" alt="" />{" "}
                    <span>{selectHotelWhetherData.current.temp_c} &deg;C</span>
                  </div>
                ) : (
                  ""
                )}
                <ul>
                  {userAuthData != null ?             
                   <>
                      <li>
                        <span
                          className="header_login_link"
                        >
                          {/* <Link
                          to="/login"
                          // state={{
                          //   RenderedPageName:
                          //     location.pathname === "/bidguestuser"
                          //       ? "checkout-day-book-bid-guest-user"
                          //       : location.pathname === "/bidguestuser"
                          //       ? "checkout-day-book-hourly-guest-user"
                          //       : "",
                          // }}
                        > */}
                          <img
                            src="./img/profile-circle.svg"
                            alt=""
                            width={23}
                          />{" "}
                          {userAuthData.first_name}
                          {/* </Link> */}
                          {/* </Link> */}
                        </span>
                      </li></> : (
                    <>
                      <li>
                        <span
                          onClick={() => {
                            if (
                              currentLocation.pathname == "/bidguestuser" ||
                              currentLocation.pathname == "/hourlyguestuser"
                            ) {
                              setShowLoginPopup(true);
                            } else {
                              navigate("/login");
                            }
                          }}
                          className="header_login_link"
                        >
                          {/* <Link
                          to="/login"
                          // state={{
                          //   RenderedPageName:
                          //     location.pathname === "/bidguestuser"
                          //       ? "checkout-day-book-bid-guest-user"
                          //       : location.pathname === "/bidguestuser"
                          //       ? "checkout-day-book-hourly-guest-user"
                          //       : "",
                          // }}
                        > */}
                          <FiLogIn /> Login
                          {/* </Link> */}
                        </span>
                      </li>
                      <li>
                        <span
                          onClick={() => {
                            if (
                              currentLocation.pathname == "/bidguestuser" ||
                              currentLocation.pathname == "/hourlyguestuser"
                            ) {
                              setShowLoginPopup(true);
                            } else {
                              navigate("/sign-up");
                            }
                          }}
                          className="header_login_link"
                        >
                          {/* <Link
                          to="/sign-up"
                          // state={{
                          //   RenderedPageName:
                          //     location.pathname === "/bidguestuser"
                          //       ? "checkout-day-book-bid-guest-user"
                          //       : location.pathname === "/bidguestuser"
                          //       ? "checkout-day-book-hourly-guest-user"
                          //       : "",
                          // }}
                        > */}
                          <img
                            src="./img/profile-circle.svg"
                            alt=""
                            width={23}
                          />{" "}
                          Register
                          {/* </Link> */}
                        </span>
                      </li>
                    </>
                  )}
                  <li>
                    <Dropdown onSelect={handleSelect}>
                      <Dropdown.Toggle variant="success" id="dropdown-basic">
                        {languageToShow == "en" ? "English" : "العربية"}{" "}
                        <img src="./img/belowarrow.svg" alt="" />
                      </Dropdown.Toggle>

                      <Dropdown.Menu>
                      {languageToShow == "en" ? 
                        <Dropdown.Item eventKey="ar">العربية</Dropdown.Item>
                        : 
                        <Dropdown.Item eventKey="en">English</Dropdown.Item>
                      }
                      </Dropdown.Menu>
                    </Dropdown>
                  </li>
                  <li>
                    <Dropdown
                      onSelect={(e) =>
                        handleSelectCurrency(e, currencyToShow.current)
                      }
                    >
                      <Dropdown.Toggle variant="success" id="dropdown-basic">
                        {currencyToShow.current == "AED"
                          ? "AED"
                          : currencyToShow.current}{" "}
                        <img src="./img/belowarrow.svg" alt="" />
                      </Dropdown.Toggle>

                      <Dropdown.Menu>
                        <Dropdown.Item eventKey="AED">AED</Dropdown.Item>
                        <Dropdown.Item eventKey="INR">INR</Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </li>
                  <li>
                    {userAuthData != null ? (
                      <Dropdown>
                        <Dropdown.Toggle variant="success" id="dropdown-basic">
                          <img src={Topnav} alt="" />
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                          <Dropdown.Item>
                            <Link to="/myaccount">My Account</Link>
                          </Dropdown.Item>
                          <Dropdown.Item href="/">Hotels </Dropdown.Item>
                          <Dropdown.Item href="#/action-3">
                            Rewards
                          </Dropdown.Item>
                          <Dropdown.Item href="/contactus">
                            Contact Us
                          </Dropdown.Item>
                          <Dropdown.Item href="/faq">FAQ </Dropdown.Item>
                          <Dropdown.Item onClick={handleLogout}>
                            Sign Out{" "}
                          </Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    ) : null}
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <LoginModal show={showLoginPopup} handleClose={handleCloseLoginPopup}>
            <LoginPage handleCloseLoginPopup={handleCloseLoginPopup} />
          </LoginModal>
        </div>
      </header>
    </>
  );
};
const mapStateToProps = createStructuredSelector({
  userData: selectSocialLoginUser,
  languageToShow: selectlanguageToShow,
  currencyToShow: selectcurrencyToShow,
  userAuthData: selectUserLoginData,
  selectHotelWhetherData: selectHotelWhetherData,
  saveGuestUserCheckoutData: selectSaveGuestUserCheckoutData,
});
const mapDispatchToProps = (dispatch) => ({
  selectLanguage: (data) => dispatch(selectLanguage(data)),
  selectCurrency: (data) => dispatch(selectCurrency(data)),
  UserLogoutStart: () => dispatch(UserLogoutStart()),
  saveGuestUserCheckoutDataRequest: (data) =>
    dispatch(saveGuestUserCheckoutDataRequest(data)),
  stateClearAfterTask: () => dispatch(stateClearAfterTask()),
  getBidCheckoutDetailsRequest: (data) =>
    dispatch(getBidCheckoutDetailsRequest(data)),
  getHourlyCheckoutDetailsRequest: (data) =>
    dispatch(getHourlyCheckoutDetailsRequest(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Header);
