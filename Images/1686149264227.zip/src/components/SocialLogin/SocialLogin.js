import React, { useEffect } from "react";
// import { useDispatch } from "react-redux";
import { requestSocialLogin } from "../../redux/user/user.actions";
import FacebookLogin from "react-facebook-login/dist/facebook-login-render-props";
import GoogleLogin from "react-google-login";
import { useNavigate, useLocation } from "react-router-dom";
import AppleLogin from "react-apple-login";
import { getUserFromLocalStorage } from "../../config/common.api";
import Config from "../../constants/Config.env";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import {
  selectSocialLoginUser,
  selectSaveGuestUserCheckoutData,
} from "../../redux/user/user.selectors";
import { gapi } from "gapi-script";
// import { config } from "@fortawesome/fontawesome-svg-core";

const SocialLogin = ({
  requestSocialLogin,
  userData,
  saveGuestUserCheckoutData,
  handleCloseLoginPopup,
  search_type,
}) => {
  // const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = getUserFromLocalStorage();
  const location = useLocation();
  const currentLocation = useLocation();

  // React.useEffect(()=>{
  //  gapi.load("clientId:auth2",()=>{
  //    gapi.auth2.init({clientId:Config.Google_clientID})
  //  })

  // },[])

  const googleLogin = async (credentialResponse) => {
    console.log("Google Data", credentialResponse, credentialResponse.googleId);

    if (credentialResponse?.profileObj?.email) {
      const splitFullname = credentialResponse?.profileObj.name.split(" ");
      const postData = {
        first_name: splitFullname[0],
        last_name: splitFullname[1],
        email: credentialResponse?.profileObj.email,
        social_platform: "google",
        social_login_id: credentialResponse.googleId,
        social_login_token: credentialResponse.tokenId,
      };
      requestSocialLogin(postData);
    } else {
      console.log("Something went wrong..");
    }
  };

  const facebookLogin = async (data) => {
    console.log("facebook data", data);
    if (data?.email) {
      const splitFullname = data.name.split(" ");
      const postData = {
        first_name: splitFullname[0],
        last_name: splitFullname[1],
        email: data.email,
        social_platform: "facebook",
        social_login_id: data.id,
        social_login_token: data.accessToken,
      };
      requestSocialLogin(postData);
    } else {
      console.log("Something went wrong..");
    }
  };

  const appleLoginClick = (data) => {
    //   data.auth.init({
    //     clientId : Config.Apple_ClientID,
    //     scope : Config.Apple_Scope,
    //     redirectURI : Config.Apple_RedirectURI,
    //     // state : '[STATE]',
    //     // nonce : '[NONCE]',
    //     usePopup : true
    // });
    // resolve();
    /* after getting all config properties write code same as written for fb and google integration */
    // alert("apple clicked");
    alert("clicked");
    console.log("apple response", data);
    if (data?.email) {
      const splitFullname = data.name.split(" ");
      const postData = {
        first_name: splitFullname[0],
        last_name: splitFullname[1],
        email: data.email,
        social_platform: "apple",
        social_login_id: data.id,
        social_login_token: data.accessToken,
      };
      requestSocialLogin(postData);
    } else {
      console.log("Something went wrong..");
    }
  };

  useEffect(() => {
    if (userData != null) {
      if (userData.success == true) {
        if (currentLocation.pathname == "/login") {
          navigate("/");
        } else {
          handleCloseLoginPopup();
        }

        // if (
        //   saveGuestUserCheckoutData != null &&
        //   saveGuestUserCheckoutData?.request_data?.search_type === "bid" &&
        //   location?.state?.RenderedPageName ===
        //     "checkout-day-book-bid-guest-user"
        // ) {
        //   navigate("/bidguestuser", {
        //     state: {
        //       search_type: saveGuestUserCheckoutData?.request_data?.search_type,
        //       hotel_id: saveGuestUserCheckoutData?.request_data?.hotel_id,
        //       room_type_id:
        //         saveGuestUserCheckoutData?.request_data?.room_type_id,
        //       check_in_date:
        //         saveGuestUserCheckoutData?.request_data?.check_in_date,
        //       check_out_date:
        //         saveGuestUserCheckoutData?.request_data?.check_out_date,
        //       adults: saveGuestUserCheckoutData?.request_data?.adults,
        //       children: saveGuestUserCheckoutData?.request_data?.children,
        //       rooms: saveGuestUserCheckoutData?.request_data?.no_of_rooms,
        //       slot_id: saveGuestUserCheckoutData?.slot_id,
        //       hour: saveGuestUserCheckoutData?.hour,
        //       city: saveGuestUserCheckoutData?.city,
        //     },
        //   });
        // } else if (
        //   saveGuestUserCheckoutData != null &&
        //   saveGuestUserCheckoutData?.request_data?.search_type === "hour" &&
        //   location?.state?.RenderedPageName ===
        //     "checkout-day-book-hourly-guest-user"
        // ) {
        //   navigate("/hourlyguestuser", {
        //     state: {
        //       search_type: saveGuestUserCheckoutData?.request_data?.search_type,
        //       hotel_id: saveGuestUserCheckoutData?.request_data?.hotel_id,
        //       room_type_id:
        //         saveGuestUserCheckoutData?.request_data?.room_type_id,
        //       check_in_date:
        //         saveGuestUserCheckoutData?.request_data?.check_in_date,
        //       check_out_date:
        //         saveGuestUserCheckoutData?.request_data?.check_out_date,
        //       adults: saveGuestUserCheckoutData?.request_data?.adults,
        //       children: saveGuestUserCheckoutData?.request_data?.children,
        //       rooms: saveGuestUserCheckoutData?.request_data?.no_of_rooms,
        //       slot_id: saveGuestUserCheckoutData?.request_data?.slot_id,
        //       hour: saveGuestUserCheckoutData?.hour,
        //       city: saveGuestUserCheckoutData?.city,
        //     },
        //   });
        // } else {
        //   navigate("/");
        // }
      } else {
      }
    }
  }, [JSON.stringify(userData)]);

  return (
    <>
      <div className="social-log">
        {/* <>{console.log("userData", userData)}</> */}
        <ul>
          {/* Here dummy config values need to replace by official clientId */}
          <li>
            <GoogleLogin
              clientId={Config.Google_clientID}
              // redirectUri={"http://localhost:3000"}
              // redirectUri={Config.RedirectURI}
              // uxMode="redirect"
              buttonText="Login"
              onSuccess={googleLogin}
              onFailure={googleLogin}
              cookiePolicy={"single_host_origin"}
              render={(renderProps) => (
                <button
                  onClick={renderProps.onClick}
                  disabled={renderProps.disabled}
                  className="SignIn-Social SignIn-google"
                >
                  <img src="./img/google-log.svg" alt="" />
                </button>
              )}
            />
          </li>
          {/* Here dummy config values need to replace by official appId */}
          <li>
            <FacebookLogin
              appId={Config.FB_APP_ID}
              // redirectURI={Config.RedirectURI}
              fields="name,email,picture"
              callback={facebookLogin}
              render={(renderProps) => (
                <button
                  className="SignIn-Social SignIn-facebook"
                  onClick={() => renderProps.onClick()}
                  disabled={renderProps.isDisabled}
                >
                  <img src="./img/facebook-log.svg" alt="" />
                </button>
              )}
            />
          </li>
          {/* Here dummy config values need to replace by official client id, scopes, redirect URL, and state */}
          <li>
            <AppleLogin
              clientId={Config.Apple_ClientID}
              redirectURI={Config.Apple_RedirectURI}
              usePopup={false}
              callback={appleLoginClick}
              scope={Config.Apple_Scope}
              render={(renderProps) => (
                <button
                  className="SignIn-Social SignIn-apple"
                  onClick={() => renderProps.onClick()}
                  disabled={renderProps.isDisabled}
                >
                  <img src="./img/apple-log.svg" alt="" />
                </button>
              )}
            />
            {/* <AppleLogin
              clientId={`${Config.Apple_ClientID}`}
              redirectURI={`${Config.Apple_RedirectURI}`}
              callback={appleLoginClick}
              // scope={Config.Apple_Scope}
               responseType={"code"} 
               responseMode={"query"}  
               usePopup={true} 
              render={(renderProps) => (
                <button
                  className="SignIn-Social SignIn-apple"
                  onClick={() => renderProps.onClick()}
                  // disabled={renderProps.isDisabled}
                >
                  <img src="./img/apple-log.svg" alt="" />
                </button>
              )}
            /> */}
          </li>
        </ul>
      </div>
    </>
  );
};
const mapStateToProps = createStructuredSelector({
  userData: selectSocialLoginUser,
  saveGuestUserCheckoutData: selectSaveGuestUserCheckoutData,
});
const mapDispatchToProps = (dispatch) => ({
  requestSocialLogin: (data) => dispatch(requestSocialLogin(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(SocialLogin);
