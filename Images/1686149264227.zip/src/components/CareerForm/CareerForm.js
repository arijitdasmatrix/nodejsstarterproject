import React, { useEffect, useState, useCallback, useRef } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { AiOutlineEye } from "react-icons/ai";
import { Link, useNavigate } from "react-router-dom";
import { AiOutlineEyeInvisible } from "react-icons/ai";
import validator from "validator";
import { connect } from "react-redux";

import { selectUserLoginData } from "./../../redux/user/user.selectors";
import InputMask from "react-input-mask";
import {
  addCareerRequest,
  stateClearAfterTask,
} from "./../../redux/useraccount/useraccount.actions";
import {
  careerFileUploadRequest,
  resetFileStore,
} from "./../../redux/common/fileUpload.actions";
import {
  selectFileUploadData,
  selectFileLoading,
} from "./../../redux/common/fileUpload.selectors";

import {
  selectAddCareerData,
  selectCareerLoading,
} from "./../../redux/useraccount/useraccount.selectors";
import { createStructuredSelector } from "reselect";
import axios from "axios";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import Spinner from "react-bootstrap/Spinner";
import { BiUpload } from "react-icons/bi";

const CareerForm = ({
  addCareerRequest,
  careerData,
  stateClearAfterTask,
  careerFileUploadRequest,
  fileData,
  resetFileStore,
  fileLoading,
  careerLoading,
}) => {
  const [fileName, setFileName] = useState([]);

  const [userData, setUserData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    mobileNo: "",
    subject: "",
    message: "",
    attachments: [],
  });

  const [userDataError, setuserDataError] = useState({
    firstnameErr: "",
    lastnameErr: "",
    emailErr: "",
    mobileNoErr: "",
    subjectErr: "",
    messageErr: "",
    termsmessage: "",
  });
  const [countryCode, setCountryCode] = React.useState("");
  const [countryCodeErr, setCountryCodeErr] = React.useState("");
  const [fileSize, setFileSize] = React.useState("");
  const [documentFileObj, setDocumentFileObj] = React.useState({
    document: "",
  });

  const navigate = useNavigate();
  const inputRef = useRef();

  const handleChangeFile = (e) => {
    // setFileName([inputRef.current.files[0].name]);
    // const fileUploadData = inputRef.current.files[0];
    setFileName([e.target.files[0].name]);
    const fileUploadData = e.target.files[0];
    setFileSize(parseFloat(fileUploadData.size / 1048576).toFixed(1));
    const postedData = {
      document: fileUploadData,
    };
    // console.log(postedData);
    setDocumentFileObj({
      ...documentFileObj,
      document: fileUploadData,
    });
  };

  const uploadFile = () => {
    if (documentFileObj.document != "") {
      console.log(documentFileObj);
      careerFileUploadRequest(documentFileObj);

      setDocumentFileObj({
        document: "",
      });
      setFileName([]);
      setFileSize("");
    }
  };
  const removeFile = useCallback(() => {
    setDocumentFileObj({ document: "" });
    setFileName([]);
    setFileSize("");
    resetFileStore();
  }, [documentFileObj, fileName, fileSize]);

  /*** Country Code Selection   ***/
  const handleCountryCodeChange = (value, data, event, formattedValue) => {
    console.log("data.dialCode", data.dialCode);
    if (data.dialCode == "") {
      setCountryCode("");
    } else {
      setCountryCode(formattedValue);
      // setCountryCode("");
      setCountryCodeErr("");
    }
  };

  const handleChange = (e) => {
    console.log("eerrrww", e.target.name, e.target.value);
    if (e.target.name == "firstname") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "",
      });
    } else if (e.target.name == "lastname") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "",
      });
    } else if (e.target.name == "email") {
      setuserDataError({
        ...userDataError,
        emailErr: "",
      });
    } else if (e.target.name == "mobileNo") {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "",
      });
    } else if (e.target.name == "subject") {
      setuserDataError({
        ...userDataError,
        subjectErr: "",
      });
    } else {
      setuserDataError({
        ...userDataError,
        messageErr: "",
      });
    }
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (userData.firstname == "") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "Please Enter Your First Name",
      });
      return;
    } else if (userData.lastname == "") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "Please Enter Your Last Name",
      });
      return;
    } else if (!validator.isEmail(userData.email)) {
      setuserDataError({
        ...userDataError,
        emailErr: "Please Enter a Valid Email Address",
      });
      return;
    } else if (countryCode == "") {
      setCountryCodeErr("Please Select Your country code");
      return;
    } else if (userData.mobileNo == "") {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "Please Enter Your Mobile Number",
      });
      return;
    } else if (userData.mobileNo.length < 10 || userData.mobileNo.length > 10) {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "Atleast 10 Digits Required",
      });
      return;
    } else if (userData.subject == "") {
      setuserDataError({
        ...userDataError,
        subjectErr: "Please Select Your subject",
      });
      return;
    } else if (userData.message == "") {
      setuserDataError({
        ...userDataError,
        messageErr: "Please Enter Your message",
      });
      return;
    } else {
      let formData = new FormData();
      formData.append(userData.attachments, fileName);
      const attachmentsFileArr = [];
      attachmentsFileArr.push(fileData?.data.file_link);
      const data = {
        first_name: userData.firstname,
        last_name: userData.lastname,
        email: userData.email,
        country_code: countryCode,
        contact_number: userData.mobileNo,
        subject: userData.subject,
        message: userData.message,
        attachments: attachmentsFileArr,
      };

      addCareerRequest(data);
      setUserData({
        firstname: "",
        lastname: "",
        email: "",
        mobileNo: "",
        subject: "",
        message: "",
        attachments: [],
      });
    }
  };

  useEffect(() => {
    if (careerData != null) {
      if (careerData.success == true) {
        const timeout = setTimeout(() => {
          navigate("/");
          stateClearAfterTask();
          resetFileStore();
        }, 5001);
        return () => clearTimeout(timeout);
      } else {
      }
      stateClearAfterTask();
      resetFileStore();
    }
  }, [JSON.stringify(careerData)]);

  React.useEffect(() => {
    if (fileData != null) {
      if (fileData.success == true) {
        resetFileStore();
      } else {
      }
      resetFileStore();
    }
  }, [JSON.stringify(fileData)]);

  return (
    <>
      <Form onSubmit={handleSubmit} className={"careerForm"}>
        <div className="form50">
          <Form.Group controlId="formCareerFirstname">
            <Form.Label>Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="First Name"
              onChange={handleChange}
              value={userData.firstname}
              name="firstname"
            />
            <Form.Text className="text-muted">
              {userDataError.firstnameErr}
            </Form.Text>
          </Form.Group>
          <Form.Group className="lastname" controlId="formCareerLastname">
            <Form.Label>Last Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="Last Name"
              name="lastname"
              onChange={handleChange}
              value={userData.lastname}
            />
            <Form.Text className="text-muted">
              {userDataError.lastnameErr}
            </Form.Text>
          </Form.Group>
        </div>
        <Form.Group controlId="formCareerEmail">
          <Form.Label>E-mail *</Form.Label>
          <Form.Control
            type="email"
            placeholder="E-mail address"
            name="email"
            value={userData.email}
            onChange={handleChange}
          />
          <Form.Text className="text-muted">{userDataError.emailErr}</Form.Text>
        </Form.Group>
        <div className="form50">
          <Form.Group controlId="formCareerPhone">
            <Form.Label>Mobile Number *</Form.Label>
            <Form.Group
              controlId="formCheckoutPhone"
              className="phoneWithCountryCode"
            >
              <Form.Group controlId="formCheckoutCountryCode">
                <PhoneInput
                  autoFormat={false}
                  // country={"in"}
                  enableSearch={true}
                  value={countryCode}
                  onChange={handleCountryCodeChange}
                  name="countryCode"
                  placeholder={"+91"}
                  className="checkoutcountryCodeInput"
                />
              </Form.Group>
              <Form.Group
                controlId="formCheckoutPoneNumber"
                className="checkoutPhoneNumber"
              >
                <Form.Control
                  type="Number"
                  placeholder="Mobile Number"
                  name="mobileNo"
                  value={userData.mobileNo}
                  onChange={handleChange}
                />
              </Form.Group>
            </Form.Group>
            <Form.Text className="text-muted">
              {userDataError.mobileNoErr} {countryCodeErr}
            </Form.Text>
            {/* <Form.Control
            type="Number"
            placeholder="Mobile Number"
            name="mobileNo"
            value={userData.mobileNo}
            onChange={handleChange}
          />
          <Form.Text className="text-muted">
            {userDataError.mobileNoErr}
          </Form.Text> */}
          </Form.Group>
          <Form.Group controlId="formCareerSubject">
            <Form.Label>Subject *</Form.Label>
            <Form.Select
              value={userData.subject}
              name="subject"
              onChange={handleChange}
            >
              <option disabled selected value="">
                Select subject
              </option>
              <option value="Position Appy for">Position Appy for</option>
              <option value="General Instruction">General Instruction</option>
            </Form.Select>
            <Form.Text className="text-muted">
              {userDataError.subjectErr}
            </Form.Text>
          </Form.Group>
        </div>

        <Form.Group controlId="formCareerMessage">
          <Form.Label>Message *</Form.Label>
          <Form.Control
            as="textarea"
            placeholder="Your message"
            value={userData.message}
            name="message"
            onChange={handleChange}
          />
          <Form.Text className="text-muted">
            {userDataError.messageErr}
          </Form.Text>
        </Form.Group>

        <Form.Group controlId="formCareerattachment" className="WL-fileuplaod">
          <Form.Label>Attachment</Form.Label>
          <Form.Control
            type="file"
            aria-label="Attachment"
            // accept=".pdf,.PDF"
            accept="image/jpeg,image/gif,image/png,application/pdf,image/x-eps"
            onChange={handleChangeFile}
            ref={inputRef}
            key={fileName}
          />
        </Form.Group>

        <>
          {fileName.length == 0 ? (
            ""
          ) : (
            <p>
              {fileName} &nbsp;&nbsp; {fileSize == "" ? "" : `${fileSize} MB`}
            </p>
          )}
          {fileName.length > 0 ? (
            <div className="d-flex gap-1 careerBtnBox">
              {fileData == null && (
                <Button className="gen-btn" onClick={removeFile}>
                  Remove File
                </Button>
              )}
              {fileData == null && (
                <Button
                  className="gen-btn"
                  onClick={uploadFile}
                  // disabled={fileData != null ? true : false}
                >
                  {fileLoading ? (
                    <Spinner animation="border" variant="light" />
                  ) : (
                    <>
                      <BiUpload className="uploadIcon" /> Upload File
                    </>
                  )}
                </Button>
              )}
            </div>
          ) : (
            ""
          )}
        </>

        <Button variant="" type="submit" className="formsubmit">
          {careerLoading ? (
            <Spinner animation="border" variant="light" />
          ) : (
            "Send"
          )}
        </Button>
      </Form>
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  careerData: selectAddCareerData,
  userAuthData: selectUserLoginData,
  fileData: selectFileUploadData,
  fileLoading: selectFileLoading,
  careerLoading: selectCareerLoading,
});

const mapDispatchToProps = (dispatch) => ({
  addCareerRequest: (data) => dispatch(addCareerRequest(data)),
  stateClearAfterTask: () => dispatch(stateClearAfterTask()),
  careerFileUploadRequest: (data) => dispatch(careerFileUploadRequest(data)),
  resetFileStore: () => dispatch(resetFileStore()),
});

export default connect(mapStateToProps, mapDispatchToProps)(CareerForm);
