import React, { useState } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { Link } from "react-router-dom";
import { FiLogIn } from "react-icons/fi";
import { BiUserCircle } from "react-icons/bi";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import validator from "validator";
import { connect } from "react-redux";

import { selectUserLoginData } from "./../../redux/user/user.selectors";

import {
  addContactUsRequest,
  stateClearAfterTask,
} from "./../../redux/useraccount/useraccount.actions";
import { careerFileUploadRequest } from "./../../redux/common/fileUpload.actions";
import { selectFileUploadData } from "./../../redux/common/fileUpload.selectors";

import { selectAddContactData } from "./../../redux/useraccount/useraccount.selectors";
import { createStructuredSelector } from "reselect";

const ContactusForm = ({
  addContactUsRequest,
  stateClearAfterTask,
  fileData,
  contactusData,
}) => {
  const location = useLocation();
  const [fileName, setFileName] = useState([]);

  const [userData, setUserData] = useState({
    firstname: "",
    lastname: "",
    email: "",
    mobileNo: "",
    subject: "",
    message: "",
    // attachments: [],
  });

  const [userDataError, setuserDataError] = useState({
    firstnameErr: "",
    lastnameErr: "",
    emailErr: "",
    mobileNoErr: "",
    subjectErr: "",
    messageErr: "",
  });
  const [countryCode, setCountryCode] = React.useState("");
  const [countryCodeErr, setCountryCodeErr] = React.useState("");

  useEffect(() => {
    window.scroll(0, 0);
  }, []);

  const navigate = useNavigate();

  const uploadFile = (data) => {
    const fileUploadData = data[0];

    const postedData = {
      document: fileUploadData,
    };
    console.log(postedData);
    // careerFileUploadRequest(postedData);
    // console.log("selectFileUploadData",selectFileUploadData)
  };

  /*** Country Code Selection   ***/
  const handleCountryCodeChange = (value, data, event, formattedValue) => {
    console.log("data.dialCode", data.dialCode);
    if (data.dialCode == "") {
      setCountryCode("");
    } else {
      setCountryCode(formattedValue);
      // setCountryCode("");
      setCountryCodeErr("");
    }
  };
  const handleChange = (e) => {
    console.log("eerrrww", e.target.name, e.target.value);
    if (e.target.name == "firstname") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "",
      });
    } else if (e.target.name == "lastname") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "",
      });
    } else if (e.target.name == "email") {
      setuserDataError({
        ...userDataError,
        emailErr: "",
      });
    } else if (e.target.name == "mobileNo") {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "",
      });
    } else if (e.target.name == "subject") {
      setuserDataError({
        ...userDataError,
        subjectErr: "",
      });
    } else {
      setuserDataError({
        ...userDataError,
        messageErr: "",
      });
    }
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (userData.firstname == "") {
      setuserDataError({
        ...userDataError,
        firstnameErr: "Please Enter Your First Name",
      });
      return;
    } else if (userData.lastname == "") {
      setuserDataError({
        ...userDataError,
        lastnameErr: "Please Enter Your Last Name",
      });
      return;
    } else if (!validator.isEmail(userData.email)) {
      setuserDataError({
        ...userDataError,
        emailErr: "Please Enter a Valid Email Address",
      });
      return;
    } else if (countryCode == "") {
      // countryCodeRef.current.focus();
      setCountryCodeErr("Please Select Your country code");
      return;
    } else if (userData.mobileNo == "") {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "Please Enter Your Mobile Number",
      });
      return;
    } else if (userData.mobileNo.length < 10 || userData.mobileNo.length > 10) {
      setuserDataError({
        ...userDataError,
        mobileNoErr: "Atleast 10 Digits Required",
      });
      return;
    } else if (userData.subject == "") {
      setuserDataError({
        ...userDataError,
        subjectErr: "Please Select Your subject",
      });
      return;
    } else if (userData.message == "") {
      setuserDataError({
        ...userDataError,
        messageErr: "Please Enter Your message",
      });
      return;
    } else {
      //   let formData = new FormData();
      //   formData.append(userData.attachments, fileName);
      //   const attachmentsFileArr = [];
      //   attachmentsFileArr.push(fileData?.data.file_link);
      const data = {
        first_name: userData.firstname,
        last_name: userData.lastname,
        email: userData.email,
        country_code: countryCode,
        contact_no: userData.mobileNo,
        subject: userData.subject,
        message: userData.message,
        // attachments: attachmentsFileArr,
      };
      console.log("contactus data", data);
      addContactUsRequest(data);
      setUserData({
        firstname: "",
        lastname: "",
        email: "",
        mobileNo: "",
        subject: "",
        message: "",
        // attachments: [],
      });
      setCountryCode("");
    }
  };

  useEffect(() => {
    if (contactusData != null) {
      if (contactusData.success == true) {
        const timeout = setTimeout(() => {
          navigate("/");
          stateClearAfterTask();
        }, 5001);
        return () => clearTimeout(timeout);
      } else {
      }
      stateClearAfterTask();
    }
  }, [JSON.stringify(contactusData)]);

  return (
    <>
      <Form onSubmit={handleSubmit}>
        <div className="form50">
          <Form.Group controlId="formContactFirstname">
            <Form.Label>Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="First Name"
              onChange={handleChange}
              value={userData.firstname}
              name="firstname"
            />
            <Form.Text className="text-muted errorformmessage">
              {userDataError.firstnameErr}
            </Form.Text>
          </Form.Group>
          <Form.Group className="lastname" controlId="formContactLastname">
            <Form.Label>Last Name *</Form.Label>
            <Form.Control
              type="text"
              placeholder="Last Name"
              name="lastname"
              onChange={handleChange}
              value={userData.lastname}
            />
            <Form.Text className="text-muted errorformmessage">
              {userDataError.lastnameErr}
            </Form.Text>
          </Form.Group>
        </div>
        <Form.Group controlId="formCareerEmail">
          <Form.Label>E-mail *</Form.Label>
          <Form.Control
            type="email"
            placeholder="E-mail address"
            name="email"
            value={userData.email}
            onChange={handleChange}
          />
          <Form.Text className="text-muted errorformmessage">
            {userDataError.emailErr}
          </Form.Text>
        </Form.Group>
        <div className="form50">
          <Form.Group controlId="formCareerPhone">
            <Form.Label>Mobile Number *</Form.Label>
            <Form.Group
              controlId="formCheckoutPhone"
              className="phoneWithCountryCode"
            >
              <Form.Group controlId="formCheckoutCountryCode">
                <PhoneInput
                  autoFormat={false}
                  // country={"in"}
                  enableSearch={true}
                  value={countryCode}
                  onChange={handleCountryCodeChange}
                  name="countryCode"
                  placeholder={"+91"}
                  className="checkoutcountryCodeInput"
                />
              </Form.Group>
              <Form.Group
                controlId="formCheckoutPoneNumber"
                className="checkoutPhoneNumber"
              >
                <Form.Control
                  type="Number"
                  placeholder="Mobile Number"
                  name="mobileNo"
                  value={userData.mobileNo}
                  onChange={handleChange}
                />
              </Form.Group>
            </Form.Group>
            <Form.Text className="text-muted errorformmessage">
              {userDataError.mobileNoErr} {countryCodeErr}
            </Form.Text>
          </Form.Group>
          <Form.Group controlId="formContactSubject">
            <Form.Label>Subject *</Form.Label>
            <Form.Select
              value={userData.subject}
              name="subject"
              onChange={handleChange}
              placeholder="Select subject"
            >
              <option disabled selected value="">
                Select subject
              </option>
              <option value="General Enquiry">General enquiry</option>
              <option value="General Instruction">General Instruction</option>
            </Form.Select>
            <Form.Text className="text-muted errorformmessage">
              {userDataError.subjectErr}
            </Form.Text>
          </Form.Group>
        </div>
        <Form.Group controlId="formContactMessage">
          <Form.Label>Message *</Form.Label>
          <Form.Control
            as="textarea"
            placeholder="Your message"
            value={userData.message}
            name="message"
            onChange={handleChange}
          />
          <Form.Text className="text-muted errorformmessage">
            {userDataError.messageErr}
          </Form.Text>
        </Form.Group>

        {/* <Form.Group controlId="formContactattachment" className="WL-fileuplaod">
          <Form.Label>Attachment</Form.Label>
          <Form.Control
            type="file"
            aria-label="Attachment"
            accept="application/pdf"
            onChange={(e) => {
              console.log(e);
              uploadFile(e.target.files);
              setFileName([e.target.files[0].name]);
            }}
          />
        </Form.Group> */}

        <Button variant="" type="submit" className="formsubmit">
          Send
        </Button>
      </Form>
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  contactusData: selectAddContactData,
  userAuthData: selectUserLoginData,
  fileData: selectFileUploadData,
});

const mapDispatchToProps = (dispatch) => ({
  addContactUsRequest: (data) => dispatch(addContactUsRequest(data)),
  stateClearAfterTask: () => dispatch(stateClearAfterTask()),
  careerFileUploadRequest: (data) => dispatch(careerFileUploadRequest(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ContactusForm);
