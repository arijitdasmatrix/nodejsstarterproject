import React from "react";
import Slider from "react-slick";
import { Link } from "react-router-dom";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { getAllFavouriteHotelListRequest } from "../../redux/hotels/hotel.actions";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { selectFavouriteHotelList } from "../../redux/hotels/hotel.selectors";

import { selectlanguageToShow } from "../../redux/language/language.selectors";
import moment from "moment";

const MyNotificationsList = ({ myNotificationsList }) => {
  var collecSlider = {
    arrows: true,
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  return (
    <div className="bookingbox">
      <div className="bookingboxlft">
        <p>
          {" "}
          Date{" "}
          <span>
            {moment(myNotificationsList.expiry_timestamp).format("ll")}
          </span>
        </p>
        <h3>
          {myNotificationsList.notification_title
            ? myNotificationsList.notification_title
            : "New Points Added"}
        </h3>
        <p>
          {myNotificationsList.notification_title
            ? myNotificationsList.notification_description
            : "Points added to your account. Redeem for best deal."}
        </p>
      </div>

      {/* <div className="bookingboxrgt">
        <Link to="#" className="gen-btn">
          Use
        </Link>
        <Link to="#" className="gen-btn">
          Redeem
        </Link>
      </div> */}
    </div>
  );
};

export default MyNotificationsList;
