import { makeStyles } from "@mui/styles";

export const useConfirmDialogStyles = makeStyles(
  {
    dialogPopup: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      "& .MuiDialog-paper": {
        // padding: "20px 40px",
        borderRadius: "10px",
        overflowX: "hidden",
      },
      "& .css-yiavyu-MuiBackdrop-root-MuiDialog-backdrop": {
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        zIndex: "-1",
      },

    //   "& .MuiDialogTitle-root": {
    //     paddingBottom: "24px",
    //     paddingLeft: "16px",
    //     paddingRight: "16px",
    //   },
    },
    dialogContent: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      padding: "20px 40px",
      borderTop: "1px solid lightgrey",
    },
    dialogText: {
      display: "flex",
      justifyContent: "center",
      flexDirection: "column",
      alignItems: "center",
    },
    buttonBox: {
      display: "flex",
      justifyContent: "center",
      flexDirection: "row",
      padding: "20px 40px !important",
    },

    yesBtn: {
      //   border: "1px solid #5287b3",
      background: "linear-gradient(180deg, #75a0c3 0%, #5287b3 100%)",
      color: "#fff !important",
      borderRadius: "8px",
      fontSize: "16px",
      fontWeight: "500",
      width: "100%",
      outline: "none",
      boxShadow: "none",
      textTransform: "capitalize !important",
      display: "flex",
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      padding: "12px",
      width: "250px",
      "&:hover": {
        background: "#42588b !important",
        color: "#fff",
      },
    },
    noBtn: {
      background: "linear-gradient(180deg, #75a0c3 0%, #5287b3 100%)",
      borderRadius: "8px",
      fontSize: "16px",
      fontWeight: "500",
      //   border: "1px solid #5287b3",
      color: "#fff !important",
      width: "100%",
      outline: "none",
      boxShadow: "none",
      textTransform: "capitalize !important",
      display: "flex",
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      padding: "12px",
      width: "250px",
      "&:hover": {
        background: "#42588b !important",
        color: "#fff !important",
      },
    },
    heading: {
      fontWeight: "500",
      fontSize: "16px",
      lineHeight: "140%",
      textAlign: "center",
      padding: "20px 0",
    },
    text: {
      fontWeight: "400",
      fontSize: "14px",
      lineHeight: "140%",
      textAlign: "center",
      padding: "20px 0",
    },
    notifyText: {
      fontWeight: "400",
      fontSize: "12px",
    },

    "& .css-hlj6pa-MuiDialogActions-root>:not(:first-of-type)": {
      transition: "none",
    },
    checkIcon: {
        "& svg": {
            color: "#5fb85f",
            fontSize: "70px",
        },
    },
  },
  { index: 1 }
);
