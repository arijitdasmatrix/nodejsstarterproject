import React, { useState, useEffect } from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import { AiOutlineEye } from "react-icons/ai";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { AiOutlineEyeInvisible } from "react-icons/ai";
import {
  emailSignInStart,
  stateClearAfterTask,
} from "./../../redux/user/user.actions";
import {
  selectCurrentUser,
  selectSignInError,
  selectSinInLoading,
  selectSaveGuestUserCheckoutData,
} from "../../redux/user/user.selectors";
// import {selectSaveGuestUserCheckoutData} from "../../redux/hotels/hotel.selectors"
import { createStructuredSelector } from "reselect";
import Spinner from "react-bootstrap/Spinner";

import { connect } from "react-redux";
const LoginForm = ({
  currentUser,
  emailSignInStart,
  signinerror,
  stateClear,
  signInLoading,
  saveGuestUserCheckoutData,
  handleCloseLoginPopup,
  search_type,
}) => {
  const navigate = useNavigate();
  const location = useLocation();
  const currentLocation = useLocation();
  const [eye, seteye] = useState(false);
  const [userData, setUserData] = useState({
    email: "",
    password: "",
  });
  const [userDataError, setuserDataError] = useState({
    emailErr: "",
    passwordErr: "",
  });
  console.log("currentUser", currentUser);
  useEffect(() => {
    if (signinerror != null) {
      stateClear();
    }
  }, [signinerror]);


  const handleChange = (e) => {
    // console.log("eerrrww",e.target.name,e.target.value)
    if (e.target.name == "email") {
      setuserDataError({
        ...userDataError,
        emailErr: "",
      });
    } else if (e.target.name == "password") {
      setuserDataError({
        ...userDataError,
        passwordErr: "",
      });
    }
    setUserData({
      ...userData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    var phoneno = /^\d{11}$/;
    if (userData.email == "") {
      setuserDataError({
        ...userDataError,
        emailErr: "Please Enter Your Email / Phone No",
      });
      return;
    } else if (userData.password == "") {
      setuserDataError({
        ...userDataError,
        passwordErr: "Please Enter Your Password",
      });
      return;
    } else {
      if (userData.email.match(phoneno)) {
        var data = {
          contact_no: userData.email,
          password: userData.password,
        };
      } else {
        var data = {
          email: userData.email,
          password: userData.password,
        };
      }
      emailSignInStart(data);
    }
  };

  const handlepasswordhideshow = () => {
    seteye(!eye);
  };

  useEffect(() => {
    // if (currentUser != null) {
    //   if (
    //     saveGuestUserCheckoutData != null &&
    //     // saveGuestUserCheckoutData?.request_data?.search_type === "bid" &&
    //     // location?.state?.RenderedPageName === "checkout-day-book-bid-guest-user"
    //     search_type === "bid" &&
    //     location?.pathname === "/bidguestuser"
    //   ) {
    //     // navigate("/bidguestuser", {
    //     //   state: {
    //     //     search_type: saveGuestUserCheckoutData?.request_data?.search_type,
    //     //     hotel_id: saveGuestUserCheckoutData?.request_data?.hotel_id,
    //     //     room_type_id: saveGuestUserCheckoutData?.request_data?.room_type_id,
    //     //     check_in_date:
    //     //       saveGuestUserCheckoutData?.request_data?.check_in_date,
    //     //     check_out_date:
    //     //       saveGuestUserCheckoutData?.request_data?.check_out_date,
    //     //     adults: saveGuestUserCheckoutData?.request_data?.adults,
    //     //     children: saveGuestUserCheckoutData?.request_data?.children,
    //     //     rooms: saveGuestUserCheckoutData?.request_data?.no_of_rooms,
    //     //     slot_id: saveGuestUserCheckoutData?.slot_id,
    //     //     hour: saveGuestUserCheckoutData?.hour,
    //     //     city: saveGuestUserCheckoutData?.city,
    //     //   },
    //     // });
    //     handleCloseLoginPopup();
    //   } else if (
    //     saveGuestUserCheckoutData != null &&
    //     // saveGuestUserCheckoutData?.request_data?.search_type === "hour" &&
    //     // location?.state?.RenderedPageName ===
    //     //   "checkout-day-book-hourly-guest-user"
    //     search_type === "hour" &&
    //     location.pathname === "/hourlyguestuser"
    //   ) {
    //     // navigate("/hourlyguestuser", {
    //     //   state: {
    //     //     search_type: saveGuestUserCheckoutData?.request_data?.search_type,
    //     //     hotel_id: saveGuestUserCheckoutData?.request_data?.hotel_id,
    //     //     room_type_id: saveGuestUserCheckoutData?.request_data?.room_type_id,
    //     //     check_in_date:
    //     //       saveGuestUserCheckoutData?.request_data?.check_in_date,
    //     //     check_out_date:
    //     //       saveGuestUserCheckoutData?.request_data?.check_out_date,
    //     //     adults: saveGuestUserCheckoutData?.request_data?.adults,
    //     //     children: saveGuestUserCheckoutData?.request_data?.children,
    //     //     rooms: saveGuestUserCheckoutData?.request_data?.no_of_rooms,
    //     //     slot_id: saveGuestUserCheckoutData?.request_data?.slot_id,
    //     //     hour: saveGuestUserCheckoutData?.hour,
    //     //     city: saveGuestUserCheckoutData?.city,
    //     //   },
    //     // });
    //     handleCloseLoginPopup();
    //   } else {
    //     navigate("/");
    //   }
    // }
    if (currentUser != null) {
      if (currentLocation.pathname == "/login") {
        navigate("/");
      } else {
        handleCloseLoginPopup();
      }
    }
  }, [currentUser]);


  return (
    <>
      <>
        {console.log(
          "saveGuestUserCheckoutData",
          saveGuestUserCheckoutData,
          location,
          "pathname",
          location.pathname
        )}
      </>
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>E-mail / Mobile Number *</Form.Label>
          <Form.Control
            type="text"
            placeholder="Email address"
            onChange={handleChange}
            name="email"
            value={userData.email}
          />
          {/* <Form.Text className="text-muted">
We'll never share your email with anyone else.
</Form.Text> */}
          <Form.Text className="text-muted errorformmessage">
            {userDataError.emailErr}
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formBasicPassword">
          <Form.Label>Password *</Form.Label>
          <div className="passwordsec">
            <Form.Control
              type={eye ? "text" : "password"}
              placeholder="Password"
              onChange={handleChange}
              name="password"
              value={userData.password}
            />
            {eye ? (
              <AiOutlineEye onClick={handlepasswordhideshow} />
            ) : (
              <AiOutlineEyeInvisible onClick={handlepasswordhideshow} />
            )}
            <Form.Text className="text-muted errorformmessage">
              {userDataError.passwordErr}
            </Form.Text>
          </div>
          <div className="forgetpass">
            <Link to="/forgot-password">Forgot Password</Link>
          </div>
        </Form.Group>
        <Button variant="primary" type="submit" className="formsubmit">
          {signInLoading ? (
            <Spinner animation="border" variant="light" />
          ) : (
            "LOGIN"
          )}
        </Button>
      </Form>
    </>
  );
};

const mapStateToProps = createStructuredSelector({
  currentUser: selectCurrentUser,
  signinerror: selectSignInError,
  signInLoading: selectSinInLoading,
  saveGuestUserCheckoutData: selectSaveGuestUserCheckoutData,
});
const mapDispatchToProps = (dispatch) => ({
  emailSignInStart: (data) => dispatch(emailSignInStart(data)),
  stateClear: () => dispatch(stateClearAfterTask()),
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginForm);
