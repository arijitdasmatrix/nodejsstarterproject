import React from "react";
import { Modal } from "react-bootstrap";

const InfoModal = ({ show, handleClose, biddingRule }) => {
  return (
    <Modal
      dialogClassName="modal-lg gen-modal infoModal"
      show={show}
      onHide={handleClose}
    >
      <Modal.Header closeButton><span>Bidding Rules</span></Modal.Header>
      <Modal.Body>
        <div className="pop-info-content">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem
            doloribus explicabo nemo ad! Dolor soluta
          </p>
         
        </div>
      </Modal.Body>
    </Modal>
  );
};
export default InfoModal;
