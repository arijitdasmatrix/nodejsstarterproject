import React from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import validator from "validator";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { selectUserLoginData } from "./../../redux/user/user.selectors";
import TextField from "@mui/material/TextField";
import InputMask from "react-input-mask";
import { errorToast } from "../../utils/toastHelper";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const CheckoutCardDetailsForm = ({
  cardData,
  cardDataError,
  handleCardDetailsChange,
  handleChangeCardNumber,
  handleChangeExpiryDate,
  handleChangeCardType,
  cardnumberRef,
  nameoncardRef,
  expirydateRef,
  securitycodeRef,
  selectedCardTypeRef,
  zipcodeRef,
}) => {
  return (
    <>
      <Form.Group controlId="formCheckoutCardnum">
        <Form.Label>Card number *</Form.Label>

        <Form.Control
          type="text"
          placeholder="*****************"
          // onChange={handleCardDetailsChange}
          onChange={handleChangeCardNumber}
          // value={cardData.cardnumber}
          value={cardData.cardnumber}
          name="cardnumber"
          ref={cardnumberRef}
          // maxLength={19}
        />
        <Form.Text className="text-muted">
          {cardDataError.cardnumberErr}
        </Form.Text>
      </Form.Group>

      <Form.Group controlId="formCheckoutCardname">
        <Form.Label>Name on card *</Form.Label>
        <Form.Control
          type="text"
          placeholder="I.e  Ali Mohammad"
          onChange={handleCardDetailsChange}
          value={cardData.nameoncard}
          name="nameoncard"
          ref={nameoncardRef}
        />
        <Form.Text className="text-muted">
          {cardDataError.nameoncardErr}
        </Form.Text>
      </Form.Group>

      <div className="form50">
        <Form.Group controlId="formCheckoutMonth">
          <Form.Label>Exp. date (MM/YY) *</Form.Label>
          <Form.Control
            type="text"
            placeholder="MM/YY"
            onChange={handleChangeExpiryDate}
            value={cardData.expirydate}
            name="expirydate"
            maxLength="5"
            format={"MM/YY"}
            ref={expirydateRef}
          />
          <Form.Text className="text-muted">
            {cardDataError.expirydateErr}
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formCheckoutSecurity">
          <Form.Label>Security code *</Form.Label>
          <Form.Control
            type="text"
            placeholder="Doe"
            onChange={handleCardDetailsChange}
            value={cardData.securitycode}
            name="securitycode"
            ref={securitycodeRef}
            maxLength={3}
          />
          <Form.Text className="text-muted">
            {cardDataError.securitycodeErr}
          </Form.Text>
        </Form.Group>
      </div>

      <div className="form50">
        <Form.Group controlId="formCheckoutCardtype">
          <Form.Label>Card type </Form.Label>

          <div className="WL_cardType_selectbox">
            <Form.Select
              aria-label="cardType"
              value={cardData.selectedCardType}
              onChange={handleChangeCardType}
              name="selectedCardType"
              size={"lg"}
              ref={selectedCardTypeRef}
            >
              <option>i.e Credit card or Debit card</option>
              <option value="debit">Debit Card</option>
              <option value="credit">Credit Card</option>
            </Form.Select>
          </div>
          {/* <Form.Text className="text-muted">
            {cardDataError.selectedCardTypeErr}
          </Form.Text> */}
        </Form.Group>
        <Form.Group controlId="formCheckoutZip">
          <Form.Label>Zip code </Form.Label>
          <Form.Control
            type="text"
            placeholder="xxxxxxxxx"
            onChange={handleCardDetailsChange}
            value={cardData.zipcode}
            name="zipcode"
            ref={zipcodeRef}
            maxLength={9}

            // pattern="[0-9]"
          />
          <Form.Text className="text-muted">
            {cardDataError.zipcodeErr}
          </Form.Text>
        </Form.Group>
      </div>
    </>
  );
};

export default CheckoutCardDetailsForm;
