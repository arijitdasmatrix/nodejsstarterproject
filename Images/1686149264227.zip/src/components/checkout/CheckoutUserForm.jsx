import React from "react";
import { Button, Dropdown, Form, Tabs, Tab } from "react-bootstrap";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import validator from "validator";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { selectlanguageToShow } from "./../../redux/language/language.selectors";
import { selectUserLoginData } from "./../../redux/user/user.selectors";
import TextField from "@mui/material/TextField";
import InputMask from "react-input-mask";
import { errorToast } from "../../utils/toastHelper";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

const CheckoutUserForm = ({
  userData,
  userDataError,
  handlePersonalDetailsChange,
  handleCountryCodeChange,
  countryCode,
  countryCodeErr,
  firstnameRef,
  confirmEmailRef,
  emailRef,
  countryCodeRef,
  mobileNoRef,
  chandleChangeExpectedTime,
  expectedTimeArrRef,
  handleCheckExistingUser,
  isEmailExits
}) => {
  return (
    <div className="WL_persnal_wrap customform">
      <h4 className="WL_personalheading">Fill Your Personal details </h4>
      {/* <Form> */}
      <div className="form50">
        <Form.Group controlId="formCheckoutFirstname">
          <Form.Label>Name *</Form.Label>
          <Form.Control
            type="text"
            placeholder="First Name"
            // required
            onChange={handlePersonalDetailsChange}
            value={userData.firstname}
            name="firstname"
            ref={firstnameRef}
          />
          <Form.Text className="text-muted">
            {userDataError.firstnameErr}
          </Form.Text>
        </Form.Group>
        <Form.Group controlId="formCheckoutLastname">
          <Form.Label>Last Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Last Name"
            // required
            name="lastname"
            onChange={handlePersonalDetailsChange}
            value={userData.lastname}
          />
        </Form.Group>
      </div>

      <div className="form50">
        <Form.Group controlId="formCheckoutEmail">
          <Form.Label>Email Address *</Form.Label>
          <Form.Control
            type="email"
            placeholder="Email address"
            // required
            name="email"
            onChange={handlePersonalDetailsChange}
            // value={userData.email}
            value={userData.email}
            ref={emailRef}
            onBlur={handleCheckExistingUser}
            // style={{border:isEmailExits==true?"1px solid red": ""}}
          />
          <Form.Text className="text-muted">{userDataError.emailErr}</Form.Text>
        </Form.Group>
        <Form.Group controlId="formCheckoutEmailadd">
          <Form.Label>Confirm Email Address *</Form.Label>
          <Form.Control
            type="email"
            placeholder="Confirm Email address"
            // required
            name="confirmEmail"
            onChange={handlePersonalDetailsChange}
            value={userData.confirmEmail}
            ref={confirmEmailRef}
          />
          <Form.Text className="text-muted">
            {userDataError.confirmEmailErr}
          </Form.Text>
        </Form.Group>
      </div>

      <div className="form50">
        <Form.Group controlId="formCheckoutPhone">
          <Form.Label>Phone number *</Form.Label>

          <div className="phoneWithCountryCode">
            <Form.Group
              controlId="formCheckoutCountryCode"
              className="checkoutcountryCode"
            >
              <PhoneInput
                // defaultCountry="IN"
                autoFormat={false}
                enableSearch={true}
                // country={"in"}
                value={countryCode}
                onChange={handleCountryCodeChange}
                name="countryCode"
                placeholder={"+91"}
                className="checkoutcountryCodeInput"
                ref={countryCodeRef}
              />
            </Form.Group>
            <Form.Group
              controlId="formCheckoutPoneNumber"
              className="checkoutPhoneNumber"
            >
              <Form.Control
                type="text"
                placeholder="Phone number"
                // required
                name="mobileNo"
                onChange={handlePersonalDetailsChange}
                value={userData.mobileNo}
                ref={mobileNoRef}
                maxLength={10}
              />
            </Form.Group>
          </div>
          <Form.Text className="text-muted">
            {userDataError.mobileNoErr} {countryCodeErr}
          </Form.Text>
        </Form.Group>

        <Form.Group controlId="formCheckoutArriv">
          <Form.Label>Expected time of arrival </Form.Label>
          <Form.Control
            type="text"
            placeholder="HH:MM"
            // required
            name="expecedTimeArrival"
            onChange={chandleChangeExpectedTime}
            value={userData.expecedTimeArrival}
            ref={expectedTimeArrRef}
            maxLength={5}
          />
          <Form.Text className="text-muted">
            {userDataError.expecedTimeArrivalErr}
          </Form.Text>
        </Form.Group>
      </div>
      {/* </Form> */}
    </div>
  );
};

export default CheckoutUserForm;
