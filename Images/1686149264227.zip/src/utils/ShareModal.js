import React from "react";
import { GrFacebookOption } from "react-icons/gr";
import { GrTwitter } from "react-icons/gr";
import { GrLinkedinOption } from "react-icons/gr";
import { GrInstagram } from "react-icons/gr";
import { GrYoutube } from "react-icons/gr";
import { BsWhatsapp } from "react-icons/bs";
import { BsTelegram } from "react-icons/bs";
import { BiCheck } from "react-icons/bi";
import { Link } from "react-router-dom";
import { GrClose } from "react-icons/gr";
import {
  EmailIcon,
  FacebookIcon,
  InstapaperIcon,
  LinkedinIcon,
  TelegramIcon,
  TwitterIcon,
  WhatsappIcon,
  FacebookShareButton,
  TwitterShareButton,
  WhatsappShareButton,
  EmailShareButton,
  InstapaperShareButton,
  TelegramShareButton,
} from "react-share";
import { Button } from "react-bootstrap";
import "./ShareModal.css";
import { CopyToClipboard } from "react-copy-to-clipboard";

const ShareModal = ({
  setOpenSharePopup,
  openSharePopup,
  shareCode,
  setShareCode,
  onCopy,
  isCopied,
  setIsCopied,
  referral_code,
}) => {
  React.useEffect(() => {
    setTimeout(() => {
      // After 3 seconds set the isCopied value to false
      setIsCopied(false);
    }, 3000);
  }, []);

  const onChange = ({ target: { value } }) => {
    setShareCode(value);
    setIsCopied(true);
  };
  const ref = React.useRef(null);

  const handleClickOutside = (event) => {
    if (ref.current && !ref.current.contains(event.target)) {
      setOpenSharePopup(false);
    }
  };

  React.useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
    };
  }, []);

  return (
    <>
      {/* <div className={openSharePopup == true ?"show share-modal-backdrop": ""}> */}
      <div
        className={openSharePopup == true ? "sharePopup show" : "sharePopup"}
        // className={
        //   showBuyPointsPopup == true ? "  popupFadeIn" : "  popupFadeOut"
        // }
        ref={ref}
      >
        <div className="modalHeader">
          <p>Share </p>

          <Button
            className={"popclose onClickBtn"}
            onClick={() => setOpenSharePopup(!openSharePopup)}
          >
            <GrClose />
          </Button>
        </div>
        <div className="content">
          <p>Share this link via</p>
          <ul className="icons">
            <Link to="#">
              {/* <GrFacebookOption /> */}

              <FacebookShareButton
                url={
                  referral_code == shareCode
                    ? `http://wfrlee.demoyourprojects.com/sign-up?referral_code=${shareCode}`
                    : shareCode
                }
                // quote={title}
                className="Demo__some-network__share-button"
              >
                <FacebookIcon size={32} round />
              </FacebookShareButton>
            </Link>
            <Link to="#">
              {/* <GrTwitter /> */}
              <TwitterShareButton
                url={shareCode}
                className="Demo__some-network__share-button"
              >
                <TwitterIcon size={32} round />
              </TwitterShareButton>
            </Link>
            <Link  to="#">
              <EmailShareButton
                url={shareCode}
                className="Demo__some-network__share-button"
              >
                <EmailIcon size={32} round />
              </EmailShareButton>
            </Link>

            {/* <Link to="#">
            <GrInstagram />
            <InstapaperShareButton
              url={shareCode}
              className="Demo__some-network__share-button"
            >
              <InstapaperIcon size={32} round />
            </InstapaperShareButton>
          </Link> */}
            <Link to="#">
              {/* <BsWhatsapp /> */}
              <WhatsappShareButton
                url={shareCode}
                className="Demo__some-network__share-button"
              >
                <WhatsappIcon size={32} round />
              </WhatsappShareButton>
            </Link>
            <Link to="#">
              {/* <BsTelegram /> */}
              <TelegramShareButton
                url={shareCode}
                className="Demo__some-network__share-button"
              >
                <TelegramIcon size={32} round />
              </TelegramShareButton>
            </Link>
          </ul>
          <p>Or copy link</p>
          <div className="field copyToClipboardArea">
            <input
              type="text"
              readonly
              value={shareCode}
              onChange={onChange}
              // name="shareCode"
            />
            <CopyToClipboard text={shareCode} onCopy={() => onCopy(true)}>
              <Button className={"copyLinkBtn"}>Copy</Button>
            </CopyToClipboard>
          </div>
        </div>
      </div>
      {isCopied ? (
        <div className="copiedToClipboard">
          <div className="container">
            {" "}
            <div className="d-flex justify-content-between">
              <p>
                <BiCheck />
                Copied to Clipboard
              </p>
              <p className="clipbd-popcloses" onClick={() => onCopy(false)}>
                <GrClose />
              </p>
            </div>
          </div>
        </div>
      ) : null}
      {/* </div> */}
    </>
  );
};

export default ShareModal;
