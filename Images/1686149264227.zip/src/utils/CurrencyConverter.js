
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
/*
This custom hook has been created to fetch converted currency and save them in redux
*/

export const CurrencyConverterHook = () => {

  //const dispatch = useDispatch();
  // const selectCurrency = useSelector((state) => state.currency.currency);
  //console.log("selectCurrency111",selectCurrency)

 const currencyConverted = async(converted) => {

  try {

    const options = {
      method: 'GET',
      url: process.env.REACT_APP_RAPIDAPI_URL_FOR_CURRENCY,
      headers: {
        'X-RapidAPI-Key': process.env.REACT_APP_RAPIDAPI_KEY,
        'X-RapidAPI-Host': process.env.REACT_APP_RAPIDAPI_HOST_FOR_CURRENCY
      },
      params: {base: converted.prev, symbols: converted.current},
    };

    console.log("options-->",options)

    //When currency key is activated uncomment this --- start
    //let res = await axios(options);
   // return res; 
   //When currency key is activated uncomment this --- end
   return {
    status:200,
    data:{
      rates:{
        'INR':1,
        'AED':1
      }
    }
   }
      
  } catch (error) {
      
  }
    // const payload = value;
    // dispatch({ type: 'DISPUTE_VIEW_MODAL_ID', payload });
  };

  
  return { currencyConverted };
};